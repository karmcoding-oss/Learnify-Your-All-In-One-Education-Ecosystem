import { useState, useLayoutEffect } from 'react';

interface ElementRect {
    top: number;
    left: number;
    width: number;
    height: number;
}

const useElementPosition = (selector: string | null): ElementRect | null => {
    const [rect, setRect] = useState<ElementRect | null>(null);

    useLayoutEffect(() => {
        if (!selector) {
            setRect(null);
            return;
        }

        const element = document.querySelector(selector);

        const updateRect = () => {
            if (element) {
                const newRect = element.getBoundingClientRect();
                setRect({
                    top: newRect.top,
                    left: newRect.left,
                    width: newRect.width,
                    height: newRect.height,
                });
            } else {
                setRect(null);
            }
        };

        updateRect();

        const handleResize = () => {
            // A short timeout can prevent layout thrashing on rapid resize
            setTimeout(updateRect, 50);
        };
        
        window.addEventListener('resize', handleResize);
        
        // Also observe mutations in case the element appears/disappears dynamically
        const observer = new MutationObserver(updateRect);
        observer.observe(document.body, { childList: true, subtree: true });

        return () => {
            window.removeEventListener('resize', handleResize);
            observer.disconnect();
        };
    }, [selector]);

    return rect;
};

export default useElementPosition;
