import type { Dispatch, SetStateAction } from 'react';

export interface Lesson {
    id: string;
    title: string;
    content: string;
    mastery: number; // 0-100
    userNotes?: string;
    uploadedFiles?: { name: string; type: string }[];
}

export interface Course {
    id: string;
    title: string;
    description: string;
    lessons: Lesson[];
}

export interface Assignment {
    id: string;
    title: string;
    description: string;
    courseId: string;
    dueDate: string | null; // YYYY-MM-DD
    timeSpent: number; // in seconds
    roughWork: string;
    editorContent: string;
    calendarEventId?: string;
    isCompleted: boolean;
}

export interface Achievement {
    id:string;
    title: string;
    description: string;
    icon: '🏆' | '🔥' | '⭐' | '🎯' | '🧠' | '🦋' | '🤝' | '📚' | '🎓' | '📝' | '📁' | '🤔' | '🌊' | '⏰' | '🧘' | '😌';
}

export interface FriendRequest {
    id: string;
    from: string; // user email
    to: string; // user email
    status: 'pending' | 'accepted' | 'declined';
}

export type NotificationType = 
    | 'FRIEND_REQUEST' 
    | 'FRIEND_ACCEPT' 
    | 'NEW_MESSAGE' 
    | 'CALENDAR_REMINDER' 
    | 'BREAK_REMINDER'
    | 'LEVEL_UP'
    | 'ACHIEVEMENT_UNLOCKED'
    | 'STREAK_MILESTONE'
    | 'COURSE_COMPLETE';

export interface Notification {
    id: string;
    type: NotificationType;
    message: string;
    from?: string; // user email
    relatedId?: string; // e.g., friend request ID or event ID
    isRead: boolean;
    timestamp: number;
}

export interface ChatMessage {
    id: string;
    sender: string; // user email
    text: string;
    timestamp: number;
}

export interface CalendarEvent {
    id: string;
    title: string;
    description: string;
    date: string; // YYYY-MM-DD
    time?: string; // HH:MM
    courseId?: string;
    location?: string;
    assignmentId?: string;
}

export interface MoodLog {
    date: string; // YYYY-MM-DD
    mood: number; // 1-5
    note?: string;
}

export interface JournalEntry {
    id: string;
    date: string;
    prompt: string;
    entry: string;
}

export interface StudyBreakSettings {
    enabled: boolean;
    interval: number; // in minutes
}

export interface AccessibilitySettings {
    fontSize: 'small' | 'medium' | 'large';
    highContrast: boolean;
    reduceMotion: boolean;
}

// Fix: Add DragonState type export.
export type DragonState = 'hidden' | 'idle' | 'celebrating' | 'flying' | 'calm';

export interface UserData {
    name: string;
    username: string;
    level: number;
    xp: number;
    streak: number;
    lastLessonCompletedDate: string | null;
    unlockedAchievements: string[];
    age?: number;
    schoolingLevel?: string;
    interests?: string[];
    friends: string[]; // array of user emails
    friendRequests: FriendRequest[]; // incoming requests
    notifications: Notification[];
    chats: Record<string, ChatMessage[]>; // Key is a unique identifier for the chat
    events: CalendarEvent[];
    assignments: Assignment[];
    moodLog: MoodLog[];
    journalEntries: JournalEntry[];
    breathingSessionsCompleted: number;
    studyBreakSettings: StudyBreakSettings;
    isSidebarOpen: boolean;
    accessibility: AccessibilitySettings;
    hasCompletedTutorial: boolean;
}

export enum View {
    DASHBOARD = 'DASHBOARD',
    COURSE = 'COURSE',
    LESSON = 'LESSON',
    ASSIGNMENT = 'ASSIGNMENT',
    CALENDAR = 'CALENDAR',
    ACHIEVEMENTS = 'ACHIEVEMENTS',
    MENTAL_HEALTH = 'MENTAL_HEALTH',
    PROFILE = 'PROFILE',
    SETTINGS = 'SETTINGS',
    RESEARCH = 'RESEARCH',
    COMMUNITY = 'COMMUNITY',
    SEARCH_RESULTS = 'SEARCH_RESULTS',
    CREDITS = 'CREDITS',
}

export interface ViewState {
    view: View;
    courseId: string | null;
    lessonId: string | null;
    assignmentId?: string | null;
}

export interface UserAccount {
    email: string;
    pass: string;
    courses: Course[];
    userData: UserData;
}

export type SearchResult =
    | { type: 'course'; data: Course }
    | { type: 'lesson'; data: Lesson; course: Course }
    | { type: 'assignment'; data: Assignment; course?: Course }
    | { type: 'event'; data: CalendarEvent; course?: Course };

export interface LevelUpInfo {
    oldLevel: number;
    newLevel: number;
}

export interface AppContextType {
    // App State
    courses: Course[];
    userData: UserData;
    viewState: ViewState;
    isDarkMode: boolean;
    isNotificationPanelOpen: boolean;

    // State Updaters
    updateLessonMastery: (courseId: string, lessonId: string, newMastery: number) => void;
    updateLessonResources: (courseId: string, lessonId: string, resources: { content?: string, notes?: string; files?: { name: string; type: string; }[] }) => void;
    completeLesson: (courseId: string, lessonId: string) => void;
    navigate: (view: View, courseId?: string | null, lessonId?: string | null, assignmentId?: string | null) => void;
    setIsDarkMode: Dispatch<SetStateAction<boolean>>;
    unlockAchievement: (achievementId: string) => void;
    toggleSidebar: () => void;
    updateUserProfile: (details: { name: string; age: number; schoolingLevel: string; interests: string }) => void;
    updateAccessibilitySettings: (settings: Partial<AccessibilitySettings>) => void;
    addXp: (amount: number, reason: string) => void;
    completeAssignment: (assignmentId: string) => void;
    toggleNotificationPanel: () => void;
    markNotificationAsRead: (notificationId: string) => void;
    markAllNotificationsAsRead: () => void;
    clearAllReadNotifications: () => void;


    // Search
    searchQuery: string;
    setSearchQuery: (query: string) => void;
    searchResults: SearchResult[];

    // Course Management
    addCourse: (course: { title: string; description: string }) => void;
    updateCourse: (courseId: string, course: { title: string; description: string }) => void;
    deleteCourse: (courseId: string) => void;
    
    // Lesson Management
    addLesson: (courseId: string, lesson: { title: string }) => void;
    updateLesson: (courseId: string, lessonId: string, lesson: { title: string }) => void;
    deleteLesson: (courseId: string, lessonId: string) => void;

    // Assignment Management
    addAssignment: (assignment: Omit<Assignment, 'id' | 'timeSpent' | 'roughWork' | 'editorContent' | 'calendarEventId' | 'isCompleted'>) => void;
    updateAssignment: (assignmentId: string, assignment: Partial<Omit<Assignment, 'id' | 'timeSpent'>>) => void;
    deleteAssignment: (assignmentId: string) => void;
    logTimeForAssignment: (assignmentId: string, seconds: number) => void;

    // Auth & Onboarding
    currentUser: string | null; // email
    login: (identifier: string, pass: string) => boolean;
    signup: (email: string, pass: string) => boolean;
    logout: () => void;
    completeOnboarding: (details: { name: string; age: number; schoolingLevel: string; interests: string; username: string; }) => Promise<boolean>;
    completeTutorial: () => void;

    // Social Features
    allUsersData: Record<string, UserAccount>;
    getPeerSuggestions: () => UserAccount[];
    sendFriendRequest: (recipientEmail: string) => void;
    handleFriendRequest: (request: FriendRequest, accepted: boolean) => void;
    sendMessage: (recipientEmail: string, text: string) => void;
    clearNotification: (notificationId: string) => void;

    // Calendar Management
    addEvent: (event: Omit<CalendarEvent, 'id'>) => CalendarEvent;
    updateEvent: (eventId: string, event: Omit<CalendarEvent, 'id' | 'assignmentId'>) => void;
    deleteEvent: (eventId: string) => void;

    // Mental Health
    addMoodLog: (log: Omit<MoodLog, 'date'>) => void;
    addJournalEntry: (entry: Omit<JournalEntry, 'id' | 'date'>) => void;
    updateStudyBreakSettings: (settings: StudyBreakSettings) => void;
    incrementBreathingSessions: () => void;
}

export interface Flashcard {
    question: string;
    answer: string;
}

export type QuestionType = 'multiple-choice' | 'true-false' | 'fill-in-the-blank';
export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export interface MultipleChoiceQuestion {
    type: 'multiple-choice';
    question: string;
    options: string[];
    correctAnswer: string;
}

export interface TrueFalseQuestion {
    type: 'true-false';
    question: string;
    correctAnswer: boolean;
}

export interface FillInTheBlankQuestion {
    type: 'fill-in-the-blank';
    question: string; // e.g., "The powerhouse of the cell is the ___."
    correctAnswer: string;
}

export type PracticeQuestion = MultipleChoiceQuestion | TrueFalseQuestion | FillInTheBlankQuestion;

export interface TestResult {
    question: PracticeQuestion;
    userAnswer: string | boolean;
    isCorrect: boolean;
    explanation?: string;
}


export interface Student {
    id: string;
    name: string;
    avatarInitials: string;
    course: string;
    online: boolean;
}

// --- New types for structured research ---
export interface ResearchSource {
    uri: string;
    title: string;
    credibility?: number; // Score from 1-100
}

export interface ResearchSection {
    heading: string;
    content: string;
}

export interface ResearchDocument {
    title: string;
    summary: string;
    sections: ResearchSection[];
    sources: ResearchSource[];
}