import React from 'react';
import { HiEnvelope } from 'react-icons/hi2';
import { SiGithub, SiSololearn } from 'react-icons/si';

const CreditsView: React.FC = () => {
    return (
        <div className="animate-slide-in max-w-2xl mx-auto text-center py-8">
            <div className="liquid-glass rounded-2xl p-8 sm:p-12">
                <SiSololearn className="w-16 h-16 text-blue-600 dark:text-sky-400 mx-auto" />
                <h1 className="text-4xl font-extrabold text-brand-gradient tracking-tight mt-4">Learnify</h1>
                <p className="mt-4 text-lg text-slate-600 dark:text-slate-300">
                    Made by a Student, for Students.
                </p>
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                    Crafted with passion during the 48-hour Student Hackpad hackathon.
                </p>
                
                <div className="w-full h-px bg-slate-200 dark:bg-slate-700/50 my-8"></div>

                <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Connect with the Developer</h2>
                
                <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-6">
                    <a 
                        href="https://github.com/karmcoding-oss" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center space-x-3 text-slate-600 dark:text-slate-300 hover:text-brand dark:hover:text-brand transition-colors group"
                    >
                        <SiGithub className="w-6 h-6" />
                        <span className="font-semibold group-hover:underline">karmcoding-oss</span>
                    </a>

                    <a 
                        href="mailto:karmcoding@gmail.com"
                        className="flex items-center space-x-3 text-slate-600 dark:text-slate-300 hover:text-brand dark:hover:text-brand transition-colors group"
                    >
                        <HiEnvelope className="w-6 h-6" />
                        <span className="font-semibold group-hover:underline">karmcoding@gmail.com</span>
                    </a>
                </div>
            </div>
        </div>
    );
};

export default CreditsView;
