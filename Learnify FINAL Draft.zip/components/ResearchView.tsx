import React from 'react';
import DeepResearch from './DeepResearch';
import { HiGlobeAlt as GlobeAltIcon } from 'react-icons/hi2';

const ResearchView: React.FC = () => {
    return (
        <div className="space-y-8 animate-slide-in">
             <div>
                <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center">
                    <GlobeAltIcon className="w-8 h-8 mr-3 text-brand" />
                    Deep Research
                </h2>
                <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">
                    Dive into any topic with up-to-date information powered by Google Search.
                </p>
            </div>
            <div className="liquid-glass rounded-2xl p-6">
                 <DeepResearch />
            </div>
        </div>
    );
};

export default ResearchView;