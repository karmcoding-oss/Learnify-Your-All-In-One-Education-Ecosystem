import React, { useState, useRef, useEffect } from 'react';
import { Course, Lesson } from '../types';
import { useAppContext } from '../hooks/useAppContext';
import { generateNotesFromContent } from '../services/geminiService';
import { HiDocumentText as DocumentTextIcon, HiArrowUpTray as ArrowUpTrayIcon, HiPaperClip as PaperClipIcon, HiBookOpen as BookOpenIcon, HiSparkles as SparklesIcon, HiClipboard as ClipboardIcon } from 'react-icons/hi2';

const LessonResources: React.FC<{ course: Course, lesson: Lesson }> = ({ course, lesson }) => {
    const { updateLessonResources } = useAppContext();
    const [activeSection, setActiveSection] = useState<'content' | 'notes' | 'files'>('content');
    
    const [content, setContent] = useState(lesson.content || '');
    const [notes, setNotes] = useState(lesson.userNotes || '');
    const [isGeneratingNotes, setIsGeneratingNotes] = useState(false);
    
    const fileInputRef = useRef<HTMLInputElement>(null);
    const debounceTimeout = useRef<number | null>(null);

    // Update local state if the lesson prop changes (e.g., navigating between lessons)
    useEffect(() => {
        setContent(lesson.content || '');
        setNotes(lesson.userNotes || '');
    }, [lesson]);

    const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const newContent = e.target.value;
        setContent(newContent);
        if (debounceTimeout.current) clearTimeout(debounceTimeout.current);
        debounceTimeout.current = window.setTimeout(() => {
            updateLessonResources(course.id, lesson.id, { content: newContent });
        }, 500); // Debounce save by 500ms
    };

    const handleSaveNotes = () => {
        updateLessonResources(course.id, lesson.id, { notes });
    };

    const handleGenerateNotes = async () => {
        if (!content.trim()) {
            alert("Please add some lesson content first to generate notes from.");
            return;
        }
        if (notes.trim() && !window.confirm("This will overwrite your existing notes. Are you sure you want to continue?")) {
            return;
        }

        setIsGeneratingNotes(true);
        try {
            const generated = await generateNotesFromContent(content);
            setNotes(generated);
            // Also save it immediately
            updateLessonResources(course.id, lesson.id, { notes: generated });
        } catch (error: any) {
            alert(error.message);
        } finally {
            setIsGeneratingNotes(false);
        }
    };

    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const newFile = { name: file.name, type: file.type };
            const updatedFiles = [...(lesson.uploadedFiles || []), newFile];
            updateLessonResources(course.id, lesson.id, { files: updatedFiles });
        }
    };

    const triggerFileUpload = () => {
        fileInputRef.current?.click();
    };

    const SectionButton: React.FC<{ sectionId: 'content' | 'notes' | 'files', label: string, icon: React.ReactNode }> = ({ sectionId, label, icon }) => {
        const isActive = activeSection === sectionId;
        return (
            <button
                onClick={() => setActiveSection(sectionId)}
                className={`flex-1 flex items-center justify-center space-x-2 p-2 rounded-t-lg transition-colors duration-200 border-b-2 ${
                    isActive
                        ? 'border-brand text-brand'
                        : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
            >
                {icon}
                <span className="font-medium">{label}</span>
            </button>
        );
    };

    return (
        <div className="animate-slide-in">
            <div className="border-b border-slate-200 dark:border-slate-700 mb-6 flex">
                <SectionButton sectionId="content" label="Lesson Content" icon={<BookOpenIcon className="w-5 h-5"/>} />
                <SectionButton sectionId="notes" label="My Notes" icon={<DocumentTextIcon className="w-5 h-5"/>} />
                <SectionButton sectionId="files" label="Uploaded Files" icon={<ArrowUpTrayIcon className="w-5 h-5"/>} />
            </div>

            <div>
                {activeSection === 'content' && (
                     <div>
                        <textarea
                            value={content}
                            onChange={handleContentChange}
                            placeholder="Add your lesson content here. This will be used to generate flashcards, tests, and for the AI tutor."
                            className="w-full h-96 p-4 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand transition-colors"
                        />
                        <p className="text-xs text-slate-400 dark:text-slate-500 mt-2 text-right">Content is saved automatically.</p>
                    </div>
                )}
                {activeSection === 'notes' && (
                    <div>
                         <div className="flex justify-between items-center mb-2">
                             <button
                                onClick={handleGenerateNotes}
                                disabled={isGeneratingNotes}
                                className="flex items-center space-x-2 text-sm font-semibold bg-brand-subtle text-brand-subtle px-3 py-1.5 rounded-md hover:opacity-80 disabled:opacity-50"
                            >
                                <SparklesIcon className="w-5 h-5" />
                                <span>{isGeneratingNotes ? 'Generating...' : 'Generate Notes'}</span>
                            </button>
                            <div className="flex items-center space-x-2">
                                <button onClick={() => navigator.clipboard.writeText(notes)} className="flex items-center space-x-1 text-sm text-slate-500 hover:text-brand">
                                    <ClipboardIcon className="w-4 h-4" /> 
                                    <span>Copy</span>
                                </button>
                                 <button
                                    onClick={handleSaveNotes}
                                    className="text-sm font-semibold bg-brand-gradient text-white px-4 py-1.5 rounded-md"
                                >
                                    Save Notes
                                </button>
                            </div>
                        </div>
                        <div className="relative">
                            <textarea
                                value={notes}
                                onChange={(e) => setNotes(e.target.value)}
                                placeholder="Add your personal notes here, or click 'Generate Notes' to have AI create them from your lesson content."
                                className="w-full h-80 p-4 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand transition-colors disabled:opacity-50"
                                disabled={isGeneratingNotes}
                            />
                            {isGeneratingNotes && (
                                <div className="absolute inset-0 bg-white/70 dark:bg-slate-900/70 flex items-center justify-center rounded-md">
                                    <SparklesIcon className="w-8 h-8 text-brand animate-pulse" />
                                </div>
                            )}
                        </div>
                    </div>
                )}
                {activeSection === 'files' && (
                     <div>
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileUpload}
                            className="hidden"
                            accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg"
                        />
                        <button
                            onClick={triggerFileUpload}
                            className="w-full bg-brand-subtle text-brand-subtle px-6 py-4 rounded-lg font-semibold hover:opacity-80 transition-colors flex items-center justify-center space-x-2 border-2 border-dashed border-brand/50"
                        >
                             <ArrowUpTrayIcon className="w-6 h-6"/>
                            <span>Upload File (PDF, DOCX, TXT, Images)</span>
                        </button>
                        <div className="mt-6">
                            <h4 className="font-bold text-lg mb-2">Uploaded Files:</h4>
                            {(!lesson.uploadedFiles || lesson.uploadedFiles.length === 0) ? (
                                <p className="text-slate-500 dark:text-slate-400">No files uploaded for this lesson yet.</p>
                            ) : (
                                <ul className="space-y-2">
                                    {lesson.uploadedFiles.map((file, index) => (
                                        <li key={index} className="flex items-center p-2 bg-slate-100 dark:bg-slate-700 rounded-md">
                                            <PaperClipIcon className="w-5 h-5 mr-3 text-slate-500"/>
                                            <span className="text-slate-800 dark:text-slate-200">{file.name}</span>
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default LessonResources;