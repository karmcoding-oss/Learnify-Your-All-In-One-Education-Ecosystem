import React, { useMemo, useRef, useEffect } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { Notification, NotificationType } from '../types';
import { 
    HiUserPlus, HiCheckCircle, HiChatBubbleLeftRight, HiCalendar, HiClock, HiSparkles, HiTrophy, HiFire, HiBookOpen, HiXCircle, HiXMark, HiBell
} from 'react-icons/hi2';
import XCircleIcon from './icons/XCircleIcon';

// FIX: Updated component to accept the full notification object to handle different notification states.
const NotificationIcon: React.FC<{ notification: Notification }> = ({ notification }) => {
    const iconClass = "w-6 h-6";
    switch (notification.type) {
        case 'FRIEND_REQUEST':
            // FIX: Correctly check the message for a declined request. This fixes the `arguments` error.
            // This is a bit of a hack since we don't have a dedicated type for declined requests.
            if (notification.message?.includes('declined')) {
                 return <XCircleIcon className={`${iconClass} text-red-600`} />;
            }
            return <HiUserPlus className={`${iconClass} text-blue-500`} />;
        case 'FRIEND_ACCEPT':
            return <HiCheckCircle className={`${iconClass} text-green-500`} />;
        case 'NEW_MESSAGE':
            return <HiChatBubbleLeftRight className={`${iconClass} text-purple-500`} />;
        case 'CALENDAR_REMINDER':
            return <HiCalendar className={`${iconClass} text-red-500`} />;
        case 'BREAK_REMINDER':
            return <HiClock className={`${iconClass} text-cyan-500`} />;
        case 'LEVEL_UP':
            return <HiSparkles className={`${iconClass} text-yellow-500`} />;
        case 'ACHIEVEMENT_UNLOCKED':
            return <HiTrophy className={`${iconClass} text-amber-500`} />;
        case 'STREAK_MILESTONE':
            return <HiFire className={`${iconClass} text-orange-500`} />;
        case 'COURSE_COMPLETE':
            return <HiBookOpen className={`${iconClass} text-indigo-500`} />;
        default:
            // FIX: Return HiBell icon, which was previously undefined.
            return <HiBell className={`${iconClass} text-slate-500`} />;
    }
};

const NotificationItem: React.FC<{ notification: Notification }> = ({ notification }) => {
    const { clearNotification, markNotificationAsRead, allUsersData } = useAppContext();
    const sender = notification.from ? allUsersData[notification.from] : null;

    return (
        <div 
            onMouseEnter={() => !notification.isRead && markNotificationAsRead(notification.id)}
            className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/50"
        >
            <div className="flex-shrink-0 mt-1 relative">
                {/* FIX: Pass the full notification object to the icon component. */}
                <NotificationIcon notification={notification} />
                {!notification.isRead && (
                    <span className="absolute -top-1 -right-1 block h-2 w-2 rounded-full bg-brand"></span>
                )}
            </div>
            <div className="flex-grow">
                <p className="text-sm">{notification.message}</p>
                 {sender && <p className="text-xs text-slate-500 dark:text-slate-400">from @{sender.userData.username}</p>}
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                    {new Date(notification.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
            </div>
            <button 
                onClick={(e) => { e.stopPropagation(); clearNotification(notification.id); }}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                aria-label="Clear notification"
            >
                <HiXMark className="w-4 h-4" />
            </button>
        </div>
    );
};

const NotificationPanel: React.FC = () => {
    const { isNotificationPanelOpen, toggleNotificationPanel, userData, markAllNotificationsAsRead, clearAllReadNotifications } = useAppContext();
    const panelRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (isNotificationPanelOpen && panelRef.current && !panelRef.current.contains(event.target as Node)) {
                // Also check if the click was on the bell icon itself
                const bellButton = document.querySelector('[aria-label="Toggle notifications"]');
                if (!bellButton || !bellButton.contains(event.target as Node)) {
                    toggleNotificationPanel();
                }
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [isNotificationPanelOpen, toggleNotificationPanel]);

    const groupedNotifications = useMemo(() => {
        const groups: { today: Notification[], yesterday: Notification[], earlier: Notification[] } = {
            today: [], yesterday: [], earlier: []
        };
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);

        [...userData.notifications].sort((a,b) => b.timestamp - a.timestamp).forEach(notif => {
            const notifDate = new Date(notif.timestamp);
            notifDate.setHours(0, 0, 0, 0);

            if (notifDate.getTime() === today.getTime()) {
                groups.today.push(notif);
            } else if (notifDate.getTime() === yesterday.getTime()) {
                groups.yesterday.push(notif);
            } else {
                groups.earlier.push(notif);
            }
        });
        return groups;
    }, [userData.notifications]);

    if (!isNotificationPanelOpen) {
        return null;
    }

    const hasNotifications = userData.notifications.length > 0;
    const hasUnread = userData.notifications.some(n => !n.isRead);

    return (
        <div 
            ref={panelRef}
            className="absolute top-20 right-4 w-full max-w-sm z-40 animate-slide-down-fade"
        >
            <div className="liquid-glass rounded-2xl shadow-2xl">
                <div className="flex justify-between items-center p-4 border-b border-white/20 dark:border-slate-700/50">
                    <h3 className="font-bold text-lg">Notifications</h3>
                    <div className="flex space-x-2">
                         {hasUnread && (
                            <button onClick={markAllNotificationsAsRead} className="text-xs font-semibold text-brand hover:underline">
                                Mark all as read
                            </button>
                        )}
                        <button onClick={clearAllReadNotifications} className="text-xs font-semibold text-brand hover:underline">
                            Clear Read
                        </button>
                    </div>
                </div>
                <div className="max-h-[60vh] overflow-y-auto p-2">
                    {hasNotifications ? (
                        <>
                            {groupedNotifications.today.length > 0 && (
                                <div className="mb-2">
                                    <h4 className="font-semibold text-sm px-3 py-1 text-slate-500 dark:text-slate-400">Today</h4>
                                    {groupedNotifications.today.map(n => <NotificationItem key={n.id} notification={n} />)}
                                </div>
                            )}
                            {groupedNotifications.yesterday.length > 0 && (
                                <div className="mb-2">
                                    <h4 className="font-semibold text-sm px-3 py-1 text-slate-500 dark:text-slate-400">Yesterday</h4>
                                    {groupedNotifications.yesterday.map(n => <NotificationItem key={n.id} notification={n} />)}
                                </div>
                            )}
                             {groupedNotifications.earlier.length > 0 && (
                                <div>
                                    <h4 className="font-semibold text-sm px-3 py-1 text-slate-500 dark:text-slate-400">Earlier</h4>
                                    {groupedNotifications.earlier.map(n => <NotificationItem key={n.id} notification={n} />)}
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="text-center py-12">
                            <p className="font-semibold">All caught up!</p>
                            <p className="text-sm text-slate-500 dark:text-slate-400">You have no new notifications.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default NotificationPanel;