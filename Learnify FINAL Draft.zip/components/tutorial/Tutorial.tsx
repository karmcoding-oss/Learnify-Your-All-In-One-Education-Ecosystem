import React, { useState, useEffect } from 'react';
import useElementPosition from '../../hooks/useElementPosition';
import { HiXMark } from 'react-icons/hi2';

interface TutorialProps {
    onComplete: () => void;
}

interface TutorialStep {
    target?: string;
    title: string;
    content: string;
    placement?: 'top' | 'bottom' | 'left' | 'right' | 'center';
}

const tutorialSteps: TutorialStep[] = [
    {
        placement: 'center',
        title: 'Welcome to Learnify!',
        content: "Let's take a quick tour of the main features to get you started on your learning journey.",
    },
    {
        target: '[data-tutorial-id="sidebar"]',
        title: 'Your Navigation Hub',
        content: 'The sidebar is your main navigation. Access your dashboard, courses, research tools, and settings from here.',
        placement: 'right',
    },
    {
        target: '[data-tutorial-id="main-content"]',
        title: 'The Main Stage',
        content: 'This is where all the action happens! Your dashboard, courses, and lessons will all appear in this main content area.',
        placement: 'top',
    },
    {
        target: '[data-tutorial-id="create-course-button"]',
        title: 'Create & Learn',
        content: 'Start by creating your first course. This is where you can add lessons, generate flashcards, and take practice tests.',
        placement: 'bottom',
    },
    {
        target: '[data-tutorial-id="header-gamification"]',
        title: 'Track Your Progress',
        content: 'Stay motivated by leveling up! Earn XP for completing lessons and maintain your daily study streak.',
        placement: 'bottom',
    },
    {
        target: '[data-tutorial-id="profile-button"]',
        title: 'Your Profile & Settings',
        content: 'Click here to view your profile, see your stats, and configure your app settings.',
        placement: 'bottom',
    },
    {
        placement: 'center',
        title: "You're All Set!",
        content: 'That\'s the grand tour. Dive in, explore, and happy learning!',
    },
];


const Tutorial: React.FC<TutorialProps> = ({ onComplete }) => {
    const [currentStep, setCurrentStep] = useState(0);
    const step = tutorialSteps[currentStep];
    const elementRect = useElementPosition(step?.target || null);

    const [tooltipStyle, setTooltipStyle] = useState<React.CSSProperties>({});

    useEffect(() => {
        const calculatePosition = () => {
            const placement = step?.placement || 'bottom';
            const margin = 16; // 1rem

            if (placement === 'center' || !elementRect) {
                setTooltipStyle({
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)',
                });
                return;
            }
            
            let newStyle: React.CSSProperties = {};
            const tooltipWidth = 320; 
            const tooltipHeight = 200; // Estimated height

            switch(placement) {
                case 'top':
                    newStyle = { top: elementRect.top - margin, left: elementRect.left + elementRect.width / 2, transform: `translate(-50%, -100%)` };
                    break;
                case 'bottom':
                     newStyle = { top: elementRect.top + elementRect.height + margin, left: elementRect.left + elementRect.width / 2, transform: `translate(-50%, 0)` };
                    break;
                case 'left':
                     newStyle = { top: elementRect.top + elementRect.height / 2, left: elementRect.left - margin, transform: `translate(-100%, -50%)` };
                    break;
                case 'right':
                     newStyle = { top: elementRect.top + elementRect.height / 2, left: elementRect.left + elementRect.width + margin, transform: `translate(0, -50%)` };
                    break;
            }

            // Boundary checks
            if (newStyle.top as number < margin) newStyle.top = margin;
            if (newStyle.left as number < margin) newStyle.left = margin;
            if ((newStyle.left as number) + tooltipWidth > window.innerWidth) newStyle.left = window.innerWidth - tooltipWidth - margin;
            if ((newStyle.top as number) + tooltipHeight > window.innerHeight) newStyle.top = window.innerHeight - tooltipHeight - margin;


            setTooltipStyle(newStyle);
        }
        
        // Timeout to allow element to be found and rect to be calculated
        const timeoutId = setTimeout(calculatePosition, 50);
        return () => clearTimeout(timeoutId);

    }, [currentStep, elementRect, step]);

    const handleNext = () => {
        if (currentStep < tutorialSteps.length - 1) {
            setCurrentStep(s => s + 1);
        } else {
            onComplete();
        }
    };
    
    const handleBack = () => {
        if (currentStep > 0) {
            setCurrentStep(s => s - 1);
        }
    };

    const isCentered = step.placement === 'center' || !elementRect;
    
    return (
        <div className="fixed inset-0 z-[1000]">
            {/* Overlay */}
            <div className="fixed inset-0 bg-slate-900/30 dark:bg-slate-900/50" onClick={onComplete}></div>
            
            {/* Highlight Box */}
            {!isCentered && elementRect && (
                <div 
                    className="tutorial-highlight-box"
                    style={{
                        top: elementRect.top - 8,
                        left: elementRect.left - 8,
                        width: elementRect.width + 16,
                        height: elementRect.height + 16,
                    }}
                />
            )}
            
            {/* Tooltip */}
            <div className="tutorial-tooltip" style={tooltipStyle}>
                <div className="liquid-glass p-6 rounded-2xl">
                     <button onClick={onComplete} className="absolute top-3 right-3 p-1 rounded-full hover:bg-black/10 dark:hover:bg-white/10">
                        <HiXMark className="w-5 h-5" />
                    </button>
                    <h3 className="font-bold text-lg mb-2">{step.title}</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-300">{step.content}</p>
                    <div className="flex items-center justify-between mt-6">
                        {/* Progress Dots */}
                        <div className="flex space-x-2">
                             {tutorialSteps.map((_, index) => (
                                <div key={index} className={`w-2 h-2 rounded-full transition-colors ${currentStep === index ? 'bg-brand' : 'bg-slate-300 dark:bg-slate-600'}`}></div>
                            ))}
                        </div>
                        {/* Navigation */}
                        <div className="flex items-center space-x-2">
                             {currentStep > 0 && (
                                <button onClick={handleBack} className="text-sm font-semibold px-4 py-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800">
                                    Back
                                </button>
                            )}
                            <button onClick={handleNext} className="bg-brand-gradient text-white text-sm font-semibold px-4 py-2 rounded-md">
                                {currentStep === tutorialSteps.length - 1 ? 'Finish' : 'Next'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Tutorial;
