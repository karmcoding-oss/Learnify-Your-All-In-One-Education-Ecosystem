import React, { useState, useEffect, useCallback } from 'react';
import { Course, Lesson, Flashcard } from '../types';
import { generateFlashcards } from '../services/geminiService';
import { useAppContext } from '../hooks/useAppContext';
import { HiSparkles as SparklesIcon, HiCheck as CheckIcon } from 'react-icons/hi2';

const Flashcards: React.FC<{ course: Course; lesson: Lesson }> = ({ course, lesson }) => {
    const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isFlipped, setIsFlipped] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [knownCards, setKnownCards] = useState<boolean[]>([]);
    
    const { updateLessonMastery, unlockAchievement, addXp } = useAppContext();

    const handleGenerate = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const generatedCards = await generateFlashcards(lesson.content);
            setFlashcards(generatedCards);
            setKnownCards(new Array(generatedCards.length).fill(false));
            setCurrentIndex(0);
            unlockAchievement('first-flashcards');
        } catch (err) {
            setError("Failed to generate flashcards. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [lesson.content, unlockAchievement]);

    useEffect(() => {
        if(knownCards.length > 0) {
            const knownCount = knownCards.filter(Boolean).length;
            const progress = (knownCount / knownCards.length) * 50; // Max 50% mastery from flashcards
            updateLessonMastery(course.id, lesson.id, lesson.mastery + progress);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [knownCards, course.id, lesson.id]);


    const handleNext = () => {
        setIsFlipped(false);
        if (currentIndex < flashcards.length - 1) {
            setCurrentIndex(currentIndex + 1);
        }
    };
    
    const handlePrev = () => {
        setIsFlipped(false);
        if (currentIndex > 0) {
            setCurrentIndex(currentIndex - 1);
        }
    };

    const toggleKnown = () => {
        const isAlreadyKnown = knownCards[currentIndex];
        setKnownCards(prev => {
            const newKnown = [...prev];
            newKnown[currentIndex] = !newKnown[currentIndex];
            return newKnown;
        });
        // Only award XP the first time it's marked as known
        if (!isAlreadyKnown) {
            addXp(2, 'Flashcard Known');
        }
    };

    if (isLoading) {
        return <div className="text-center p-8">Generating flashcards with AI... <SparklesIcon className="inline-block w-5 h-5 animate-pulse" /></div>;
    }

    if (error) {
        return <div className="text-center p-8 text-red-500">{error}</div>;
    }

    if (flashcards.length === 0) {
        return (
            <div className="text-center p-8 animate-slide-in">
                <h3 className="text-xl font-bold mb-4">Generate Flashcards</h3>
                <p className="text-slate-500 dark:text-slate-400 mb-6">Create a set of flashcards from the lesson content to test your knowledge.</p>
                <button onClick={handleGenerate} className="bg-brand-gradient text-white px-6 py-2 rounded-lg font-semibold transition-colors">
                    <SparklesIcon className="inline-block w-5 h-5 mr-2" /> Generate
                </button>
            </div>
        );
    }
    
    const currentCard = flashcards[currentIndex];
    
    return (
        <div className="flex flex-col items-center animate-slide-in">
            <div className="w-full max-w-lg h-64 perspective-1000">
                <div 
                    className={`relative w-full h-full transition-transform duration-700 transform-style-3d ${isFlipped ? 'rotate-y-180' : ''}`}
                    onClick={() => setIsFlipped(!isFlipped)}
                >
                    <div className="absolute w-full h-full backface-hidden flex items-center justify-center p-6 liquid-glass rounded-2xl cursor-pointer">
                        <p className="text-2xl font-semibold text-center">{currentCard.question}</p>
                    </div>
                    <div className="absolute w-full h-full backface-hidden rotate-y-180 flex items-center justify-center p-6 bg-brand-gradient text-white rounded-2xl shadow-lg cursor-pointer">
                        <p className="text-lg text-center">{currentCard.answer}</p>
                    </div>
                </div>
            </div>
            
            <div className="flex items-center justify-between w-full max-w-lg mt-6">
                <button onClick={handlePrev} disabled={currentIndex === 0} className="px-4 py-2 rounded-md disabled:opacity-50 text-slate-700 dark:text-slate-200 bg-slate-200 dark:bg-slate-600">Prev</button>
                <span className="font-semibold">{currentIndex + 1} / {flashcards.length}</span>
                <button onClick={handleNext} disabled={currentIndex === flashcards.length - 1} className="px-4 py-2 rounded-md disabled:opacity-50 text-slate-700 dark:text-slate-200 bg-slate-200 dark:bg-slate-600">Next</button>
            </div>

            <button
                onClick={toggleKnown}
                className={`mt-6 px-6 py-2 rounded-lg font-semibold transition-colors flex items-center space-x-2 ${knownCards[currentIndex] ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' : 'bg-slate-100 dark:bg-slate-700'}`}
            >
                <CheckIcon className="w-5 h-5" />
                <span>{knownCards[currentIndex] ? 'Marked as Known' : 'Mark as Known'}</span>
            </button>
        </div>
    );
};

export default Flashcards;