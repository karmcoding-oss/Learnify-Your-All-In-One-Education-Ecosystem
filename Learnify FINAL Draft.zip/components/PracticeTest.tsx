import React, { useState, useCallback, useEffect } from 'react';
import { Course, Lesson, PracticeQuestion, TestResult, QuestionType, Difficulty } from '../types';
import { generatePracticeTest, getAnswerExplanation } from '../services/geminiService';
import { useAppContext } from '../hooks/useAppContext';
import { HiSparkles as SparklesIcon, HiCheck as CheckIcon, HiXMark as XMarkIcon } from 'react-icons/hi2';
import Confetti from './gamification/Confetti';

// Helper function to shuffle an array (Fisher-Yates algorithm)
const shuffleArray = <T,>(array: T[]): T[] => {
    if(!array) return [];
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
};

const easeOutQuint = (t: number) => 1 + --t * t * t * t * t;

const useCountUp = (end: number, duration = 1500) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        let start = 0;
        const startTime = Date.now();

        const animateCount = () => {
            const now = Date.now();
            const progress = Math.min(1, (now - startTime) / duration);
            const easedProgress = easeOutQuint(progress);
            
            setCount(Math.floor(easedProgress * (end - start) + start));

            if (progress < 1) {
                requestAnimationFrame(animateCount);
            }
        };

        requestAnimationFrame(animateCount);
    }, [end, duration]);

    return count;
};

interface TestSettings {
    count: number;
    types: { [key in QuestionType]: boolean };
    difficulty: Difficulty;
}

const PracticeTest: React.FC<{ course: Course; lesson: Lesson }> = ({ course, lesson }) => {
    const [view, setView] = useState<'settings' | 'testing' | 'results'>('settings');
    const [settings, setSettings] = useState<TestSettings>({
        count: 5,
        types: {
            'multiple-choice': true,
            'true-false': true,
            'fill-in-the-blank': false,
        },
        difficulty: 'Medium',
    });
    
    const [questions, setQuestions] = useState<PracticeQuestion[]>([]);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [userAnswers, setUserAnswers] = useState<TestResult[]>([]);
    const [currentAnswer, setCurrentAnswer] = useState<string | boolean>('');
    const [isAnswered, setIsAnswered] = useState(false);
    
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [showConfetti, setShowConfetti] = useState(false);
    const [reviewMode, setReviewMode] = useState(false);
    
    const { updateLessonMastery, completeLesson, unlockAchievement, addXp } = useAppContext();
    
    const handleGenerate = useCallback(async () => {
        const selectedTypes = Object.entries(settings.types)
            .filter(([, isSelected]) => isSelected)
            .map(([type]) => type as QuestionType);

        if (selectedTypes.length === 0) {
            alert("Please select at least one question type.");
            return;
        }
        
        setIsLoading(true);
        setError(null);
        try {
            const generatedQuestions = await generatePracticeTest(lesson.content, {
                count: settings.count,
                types: selectedTypes,
                difficulty: settings.difficulty,
            });
            
            if (generatedQuestions.length === 0) {
                setError("Sorry, I couldn't generate a test with these settings. Try adjusting the content or settings.");
                setIsLoading(false);
                return;
            }

            const shuffledQuestions = generatedQuestions.map(q =>
                q.type === 'multiple-choice' ? { ...q, options: shuffleArray(q.options) } : q
            );
            
            setQuestions(shuffledQuestions);
            setCurrentQuestionIndex(0);
            setUserAnswers([]);
            setCurrentAnswer('');
            setIsAnswered(false);
            setShowConfetti(false);
            setReviewMode(false);
            setView('testing');
            unlockAchievement('first-test');
        } catch (err) {
            setError("Failed to generate a practice test. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, [lesson.content, settings, unlockAchievement]);

    const handleSubmitAnswer = () => {
        if (isAnswered) return;
        setIsAnswered(true);
    };

    const handleNextQuestion = () => {
        const question = questions[currentQuestionIndex];
        let isCorrect = false;
        
        switch (question.type) {
            case 'multiple-choice':
            case 'true-false':
                isCorrect = currentAnswer === question.correctAnswer;
                break;
            case 'fill-in-the-blank':
                isCorrect = typeof currentAnswer === 'string' &&
                            currentAnswer.trim().toLowerCase() === question.correctAnswer.trim().toLowerCase();
                break;
        }

        setUserAnswers(prev => [...prev, { question, userAnswer: currentAnswer, isCorrect }]);
        
        if (currentQuestionIndex < questions.length - 1) {
            setCurrentQuestionIndex(prev => prev + 1);
            setCurrentAnswer('');
            setIsAnswered(false);
        } else {
            const finalScore = (userAnswers.filter(a => a.isCorrect).length + (isCorrect ? 1 : 0)) / questions.length;
            const finalPercent = finalScore * 100;

            let xpEarned = 5;
            let reason = 'Test Completed';
            if (finalPercent >= 90) { xpEarned = 20; reason = 'Excellent Score!'; }
            else if (finalPercent >= 80) { xpEarned = 15; reason = 'Great Score!'; }
            else if (finalPercent >= 70) { xpEarned = 10; reason = 'Good Score!'; }
            addXp(xpEarned, reason);

            updateLessonMastery(course.id, lesson.id, lesson.mastery + (finalPercent / 2));
            if(finalPercent >= 80) completeLesson(course.id, lesson.id);
            if (finalPercent === 100) unlockAchievement('test-ace');
            if (finalPercent >= 80) setShowConfetti(true);
            
            setView('results');
        }
    };
    
    const resetTest = () => {
        setView('settings');
        setError(null);
    }
    
    const renderSettings = () => (
        <div className="flex flex-col items-center animate-slide-in-up">
            <div className="text-center">
                <h3 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">Practice Test Setup</h3>
                <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">Customize the test to fit your study needs.</p>
            </div>
    
            <div className="w-full max-w-2xl liquid-glass rounded-2xl p-8 mt-8 space-y-8">
                {/* Number of Questions */}
                <div>
                    <label className="font-bold text-lg text-slate-800 dark:text-slate-100">Number of Questions: <span className="text-brand-gradient font-extrabold">{settings.count}</span></label>
                    <input 
                        type="range" 
                        min="5" 
                        max="15" 
                        step="5" 
                        value={settings.count} 
                        onChange={e => setSettings(s => ({...s, count: parseInt(e.target.value)}))}
                        className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer dark:bg-slate-700 mt-2 accent-blue-600 dark:accent-sky-400" 
                    />
                </div>
    
                {/* Question Types */}
                <div>
                    <label className="font-bold text-lg text-slate-800 dark:text-slate-100">Question Types</label>
                    <div className="flex flex-wrap gap-3 mt-3">
                        {Object.keys(settings.types).map(key => (
                            <button 
                                key={key} 
                                onClick={() => setSettings(s => ({...s, types: {...s.types, [key]: !s.types[key]}}))}
                                className={`px-4 py-2 text-sm font-semibold rounded-lg border-2 transition-all duration-200 transform hover:scale-105 ${
                                    settings.types[key as QuestionType] 
                                    ? 'bg-brand-gradient text-white border-transparent shadow-lg' 
                                    : 'bg-white/50 dark:bg-slate-800/50 border-slate-300 dark:border-slate-600'
                                }`}
                            >
                                {key.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </button>
                        ))}
                    </div>
                </div>
                
                {/* Difficulty */}
                <div>
                    <label className="font-bold text-lg text-slate-800 dark:text-slate-100">Difficulty</label>
                    <div className="grid grid-cols-3 gap-3 mt-3">
                        {(['Easy', 'Medium', 'Hard'] as Difficulty[]).map(d => (
                             <button 
                                key={d} 
                                onClick={() => setSettings(s => ({...s, difficulty: d}))}
                                className={`py-3 text-sm font-bold rounded-lg transition-all duration-200 transform hover:scale-105 ${
                                    settings.difficulty === d 
                                    ? 'bg-brand-gradient text-white shadow-lg' 
                                    : 'bg-white/50 dark:bg-slate-800/50'
                                }`}
                            >
                                {d}
                            </button>
                        ))}
                    </div>
                </div>
                
                {/* Start Button */}
                <div className="pt-4">
                    <button 
                        onClick={handleGenerate} 
                        disabled={isLoading} 
                        className="w-full bg-brand-gradient text-white px-6 py-4 rounded-xl font-bold text-lg btn-animated disabled:opacity-50 flex items-center justify-center space-x-2"
                    >
                        <SparklesIcon className="w-6 h-6" />
                        <span>{isLoading ? 'Generating...' : 'Start Test'}</span>
                    </button>
                    {error && <p className="text-red-500 text-center mt-4">{error}</p>}
                </div>
            </div>
        </div>
    );
    
    const renderTesting = () => {
        if (isLoading) return <div className="text-center p-8">Generating test... <SparklesIcon className="inline-block w-5 h-5 animate-pulse" /></div>;
        if (!questions.length) return <div className="text-center p-8 text-red-500">Could not load questions.</div>;
        
        const question = questions[currentQuestionIndex];
        
        const renderQuestionBody = () => {
            switch (question.type) {
                case 'multiple-choice':
                    return (
                        <div className="space-y-3">
                            {question.options.map((option, index) => {
                                const isCorrect = option === question.correctAnswer;
                                let buttonClass = "w-full text-left p-4 rounded-lg border-2 transition-all duration-200 ";
                                if(isAnswered) {
                                    if(isCorrect) buttonClass += "bg-green-100 border-green-500 dark:bg-green-900/50";
                                    else if(currentAnswer === option) buttonClass += "bg-red-100 border-red-500 dark:bg-red-900/50";
                                    else buttonClass += "bg-slate-100 border-transparent dark:bg-slate-700 opacity-60";
                                } else {
                                    buttonClass += `bg-slate-100 dark:bg-slate-700 ${currentAnswer === option ? 'border-brand' : 'border-transparent'}`;
                                }
                                return <button key={index} onClick={() => setCurrentAnswer(option)} disabled={isAnswered} className={buttonClass}>{option}</button>;
                            })}
                        </div>
                    );
                case 'true-false':
                     return (
                        <div className="flex space-x-4">
                            {[true, false].map(option => {
                                 const isCorrect = option === question.correctAnswer;
                                 let buttonClass = "flex-1 p-4 rounded-lg border-2 text-lg font-bold transition-all ";
                                 if (isAnswered) {
                                     if(isCorrect) buttonClass += "bg-green-100 border-green-500 dark:bg-green-900/50";
                                     else if(currentAnswer === option) buttonClass += "bg-red-100 border-red-500 dark:bg-red-900/50";
                                     else buttonClass += "bg-slate-100 border-transparent dark:bg-slate-700 opacity-60";
                                 } else {
                                     buttonClass += `bg-slate-100 dark:bg-slate-700 ${currentAnswer === option ? 'border-brand' : 'border-transparent'}`;
                                 }
                                 return <button key={String(option)} onClick={() => setCurrentAnswer(option)} disabled={isAnswered} className={buttonClass}>{String(option)}</button>;
                            })}
                        </div>
                    );
                case 'fill-in-the-blank':
                    const parts = question.question.split('___');
                    return (
                        <div className="flex items-center text-lg">
                            {parts[0]}
                            <input type="text" value={typeof currentAnswer === 'string' ? currentAnswer : ''} onChange={e => setCurrentAnswer(e.target.value)} disabled={isAnswered}
                                className="mx-2 p-1 border-b-2 bg-transparent focus:outline-none focus:border-brand" />
                            {parts[1]}
                            {isAnswered && (
                                <span className={`ml-4 font-bold ${currentAnswer?.toString().toLowerCase() === question.correctAnswer.toLowerCase() ? 'text-green-600' : 'text-red-600'}`}>
                                    Correct: {question.correctAnswer}
                                </span>
                            )}
                        </div>
                    );
            }
        };

        return (
            <div className="animate-slide-in-up">
                <div className="mb-4">
                    <div className="flex justify-between items-center text-sm font-semibold text-slate-500 dark:text-slate-400">
                        <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
                        <span>Score: {userAnswers.filter(a => a.isCorrect).length}</span>
                    </div>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2 mt-1">
                        <div className="bg-brand h-2 rounded-full transition-all" style={{width: `${((currentQuestionIndex + 1) / questions.length) * 100}%`}}></div>
                    </div>
                </div>
                <p className="text-lg font-semibold mb-6">{question.question}</p>
                {renderQuestionBody()}
                <div className="text-center mt-6">
                    {!isAnswered ? (
                        <button onClick={handleSubmitAnswer} disabled={!currentAnswer} className="bg-brand text-white px-8 py-2 rounded-lg font-semibold btn-animated disabled:opacity-50">Submit Answer</button>
                    ) : (
                        <button onClick={handleNextQuestion} className="bg-brand-gradient text-white px-8 py-2 rounded-lg font-semibold btn-animated">
                           {currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Finish Test'}
                        </button>
                    )}
                </div>
            </div>
        );
    };
    
    const renderResults = () => {
        const score = userAnswers.filter(a => a.isCorrect).length;
        const finalPercent = Math.round((score / questions.length) * 100);
        const animatedScore = useCountUp(finalPercent);
        
        return (
            <div className="animate-slide-in-up">
                {reviewMode ? <ReviewView results={userAnswers} onExit={() => setReviewMode(false)} /> : (
                    <div className="relative text-center p-8">
                        {showConfetti && <Confetti />}
                        <h3 className="text-2xl font-bold mb-4">Test Complete!</h3>
                        <p className="text-4xl font-bold mb-2 text-brand-gradient">{animatedScore}%</p>
                        <p className="text-slate-500 dark:text-slate-400 mb-6">You answered {score} out of {questions.length} questions correctly.</p>
                        <div className="flex justify-center space-x-4">
                            <button onClick={resetTest} className="bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 px-6 py-2 rounded-lg font-semibold">
                                New Test
                            </button>
                            <button onClick={() => setReviewMode(true)} className="bg-brand-gradient text-white px-6 py-2 rounded-lg font-semibold btn-animated">
                                Review Answers
                            </button>
                        </div>
                    </div>
                )}
            </div>
        );
    };

    switch (view) {
        case 'settings': return renderSettings();
        case 'testing': return renderTesting();
        case 'results': return renderResults();
        default: return renderSettings();
    }
};

const ReviewView: React.FC<{results: TestResult[], onExit: () => void}> = ({ results, onExit }) => {
    const [explanations, setExplanations] = useState<Record<number, string>>({});
    const [loadingExplanation, setLoadingExplanation] = useState<number | null>(null);

    const fetchExplanation = async (index: number) => {
        if (explanations[index]) return;
        setLoadingExplanation(index);
        try {
            const result = results[index];
            const explanation = await getAnswerExplanation(result.question, result.userAnswer);
            setExplanations(prev => ({...prev, [index]: explanation}));
        } catch (error) {
            setExplanations(prev => ({...prev, [index]: "Could not load explanation."}));
        } finally {
            setLoadingExplanation(null);
        }
    }

    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-2xl font-bold">Review Your Answers</h3>
                <button onClick={onExit} className="font-semibold text-brand hover:underline">Back to Score</button>
            </div>
            <div className="space-y-4">
                {results.map((result, index) => (
                    <div key={index} className={`p-4 rounded-lg ${result.isCorrect ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20'}`}>
                        <p className="font-semibold">{index + 1}. {result.question.question}</p>
                        <p className={`text-sm mt-2 ${result.isCorrect ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
                            Your answer: <span className="font-bold">{String(result.userAnswer)}</span>
                        </p>
                        {!result.isCorrect && (
                            <p className="text-sm mt-1 text-green-700 dark:text-green-300">
                                Correct answer: <span className="font-bold">{String(result.question.correctAnswer)}</span>
                            </p>
                        )}
                        <div className="mt-2">
                             <button onClick={() => fetchExplanation(index)} disabled={loadingExplanation === index} className="text-xs font-semibold text-brand hover:underline disabled:opacity-50">
                                {loadingExplanation === index ? "Thinking..." : (explanations[index] ? "Hide Explanation" : "Explain Answer")}
                             </button>
                             {explanations[index] && (
                                 <p className="mt-2 text-sm p-2 bg-slate-100 dark:bg-slate-800/50 rounded-md">{explanations[index]}</p>
                             )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default PracticeTest;
