import React from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { View } from '../types';
import { HiFire as FireIcon, HiTrophy as TrophyIcon, HiCheck as CheckIcon, HiPencil as PencilIcon } from 'react-icons/hi2';

const ProfileView: React.FC = () => {
    const { userData, courses, navigate } = useAppContext();

    const totalLessons = courses.reduce((acc, course) => acc + course.lessons.length, 0);
    const completedLessons = courses.reduce((acc, course) => acc + course.lessons.filter(l => l.mastery === 100).length, 0);

    const StatCard: React.FC<{ icon: React.ReactNode, value: string | number, label: string }> = ({ icon, value, label }) => (
        <div className="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-lg flex items-center space-x-4">
            <div className="text-2xl text-brand">{icon}</div>
            <div>
                <p className="text-2xl font-bold">{value}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400">{label}</p>
            </div>
        </div>
    );

    return (
        <div className="space-y-8 animate-slide-in max-w-4xl mx-auto">
            <div className="flex items-center justify-between">
                <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                    My Profile
                </h2>
                <button 
                    onClick={() => navigate(View.SETTINGS)}
                    className="flex items-center space-x-2 text-sm font-semibold text-brand hover:underline"
                >
                    <PencilIcon className="w-4 h-4" />
                    <span>Edit Profile</span>
                </button>
            </div>

            <div className="liquid-glass rounded-2xl p-8 text-center">
                <div className="w-24 h-24 rounded-full bg-brand-gradient flex items-center justify-center font-bold text-white text-4xl mx-auto">
                    {userData.name.charAt(0).toUpperCase()}
                </div>
                <h3 className="mt-4 text-2xl font-bold">{userData.name}</h3>
                <p className="text-slate-500 dark:text-slate-400">@{userData.username}</p>
                <p className="text-slate-500 dark:text-slate-400 mt-2">{userData.schoolingLevel} Student</p>
                {userData.interests && userData.interests.length > 0 && (
                     <div className="mt-4 flex flex-wrap justify-center gap-2">
                        {userData.interests.map(interest => (
                            <span key={interest} className="px-3 py-1 text-xs font-medium bg-brand-subtle text-brand-subtle rounded-full">
                                {interest}
                            </span>
                        ))}
                    </div>
                )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard icon={<FireIcon />} value={userData.streak} label="Day Streak" />
                <StatCard icon={<TrophyIcon />} value={`${userData.unlockedAchievements.length}`} label="Achievements" />
                <StatCard icon={<CheckIcon />} value={`${completedLessons} / ${totalLessons}`} label="Lessons Mastered" />
            </div>

        </div>
    );
};

export default ProfileView;