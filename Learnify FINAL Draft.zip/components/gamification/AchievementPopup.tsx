import React, { useEffect, useState } from 'react';
import { Achievement } from '../../types';
import { HiXMark as XMarkIcon } from 'react-icons/hi2';

interface AchievementPopupProps {
    achievement: Achievement;
    onClose: () => void;
}

const PARTICLE_COUNT = 12;

const Particle: React.FC<{ index: number; total: number }> = ({ index, total }) => {
    const angle = (360 / total) * index;
    const distance = 80; // pixels
    const style = {
        '--angle': `${angle}deg`,
        '--distance': `${distance}px`,
        animationDelay: `${Math.random() * 0.2}s`,
    } as React.CSSProperties;

    return <div className="absolute top-1/2 left-1/2 w-2 h-2 rounded-full bg-yellow-400 animate-particle-burst" style={style}></div>;
};


const AchievementPopup: React.FC<AchievementPopupProps> = ({ achievement, onClose }) => {
    const [isClosing, setIsClosing] = useState(false);

    useEffect(() => {
        const timer = setTimeout(() => {
            handleClose();
        }, 4000); // Auto-close after 4 seconds

        return () => clearTimeout(timer);
    }, []);

    const handleClose = () => {
        setIsClosing(true);
        setTimeout(onClose, 300); // Wait for closing animation
    };

    return (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div
                className={`relative liquid-glass rounded-5xl w-full max-w-sm text-center p-8 border border-white/20 shadow-2xl animate-achievement-pop-in ${isClosing ? 'animate-modal-out' : ''}`}
                role="alert"
                aria-live="assertive"
            >
                 <button onClick={handleClose} className="absolute top-4 right-4 p-2 text-slate-600 dark:text-white/70 hover:text-slate-800 dark:hover:text-white/90">
                    <XMarkIcon className="w-6 h-6" />
                </button>
                
                <div className="relative w-32 h-32 mx-auto mb-6 flex items-center justify-center">
                    {/* Particles */}
                    {Array.from({ length: PARTICLE_COUNT }).map((_, i) => (
                        <Particle key={i} index={i} total={PARTICLE_COUNT} />
                    ))}

                    {/* Flare */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/80 via-white/40 to-transparent animate-achievement-flare rounded-full"></div>

                    {/* Icon */}
                    <div className="text-6xl bg-white/30 dark:bg-slate-900/40 rounded-full w-28 h-28 flex items-center justify-center animate-achievement-icon-in shadow-inner">
                        {achievement.icon}
                    </div>
                </div>

                <h3 className="text-sm font-semibold uppercase tracking-widest text-primary-700 dark:text-primary-300">Achievement Unlocked!</h3>
                <p className="text-3xl font-bold mt-2 text-slate-900 dark:text-white">{achievement.title}</p>
                <p className="mt-2 text-slate-600 dark:text-slate-300">{achievement.description}</p>
            </div>
        </div>
    );
};

export default AchievementPopup;