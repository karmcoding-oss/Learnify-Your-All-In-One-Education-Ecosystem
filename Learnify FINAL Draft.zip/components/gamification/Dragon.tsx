import React from 'react';
import { DragonState } from '../../types';

interface DragonProps {
    state: DragonState;
}

const Dragon: React.FC<DragonProps> = ({ state }) => {
    if (state === 'hidden') {
        return null;
    }
    
    let containerClass = "fixed bottom-0 right-0 z-40 pointer-events-none w-48 h-48 sm:w-56 sm:h-56 transition-transform duration-500";
    let svgClass = "w-full h-full drop-shadow-lg";
    let idleAnimations = {
        wing: '',
        tail: '',
        eye: ''
    };

    switch (state) {
        case 'idle':
            svgClass += " animate-dragon-idle-float";
            idleAnimations.wing = "animate-dragon-wing-flap";
            idleAnimations.tail = "animate-dragon-tail-flick";
            idleAnimations.eye = "animate-dragon-blink";
            break;
        case 'celebrating':
            svgClass += " animate-dragon-celebrate";
            break;
        case 'flying':
            containerClass = "fixed top-0 left-0 z-40 pointer-events-none w-48 h-48 sm:w-56 sm:h-56";
            svgClass += " animate-dragon-fly-across opacity-0";
            idleAnimations.wing = "animate-dragon-wing-flap"; // Flap wings while flying
            break;
        case 'calm':
            svgClass += " animate-dragon-calm-breathe";
            idleAnimations.wing = "animate-dragon-wing-flap";
             idleAnimations.eye = "animate-dragon-blink";
            break;
    }

    return (
        <div className={containerClass}>
            <svg viewBox="0 0 200 200" className={svgClass}>
                <g transform="translate(0, 10)">
                    {/* Tail */}
                    <path
                        className={`origin-bottom-left ${idleAnimations.tail}`}
                        d="M102.3,139.7c0,0-13.9-2.2-13.9-15.5c0,0-0.4-12.2,13.9-14.4c1.1,5.2,1.5,10.6,1.2,15.9C103.2,131.5,102.8,135.6,102.3,139.7z"
                        fill="#2563eb"
                    />
                    {/* Left Leg */}
                    <path d="M120.3,134.4c0,0-2.2,10.7-10.7,10.7c-8.5,0-10.7-10.7-10.7-10.7s2.2-3.6,10.7-3.6S120.3,134.4,120.3,134.4z" fill="#3b82f6" />
                    {/* Right Leg */}
                    <path d="M99.5,134.4c0,0-2.2,10.7-10.7,10.7c-8.5,0-10.7-10.7-10.7-10.7s2.2-3.6,10.7-3.6S99.5,134.4,99.5,134.4z" fill="#3b82f6" />
                    
                    {/* Left Wing */}
                    <path
                        className={`origin-bottom-right ${idleAnimations.wing}`}
                        d="M113.8,103.3c0,0,29.9-12.2,40.1,1.1c10.2,13.3-13.3,31.4-13.3,31.4S115.6,112.5,113.8,103.3z"
                        fill="#93c5fd"
                    />
                    
                    {/* Body */}
                    <path d="M130.6,113.9c0,0-15.8-31.4-31.4-31.4s-31.4,31.4-31.4,31.4s-4.7,32.5,31.4,32.5S130.6,113.9,130.6,113.9z" fill="#60a5fa" />
                    <path d="M115,137.9c0,0-6.7,9.6-15.8,9.6s-15.8-9.6-15.8-9.6s-1.8-21.7,15.8-21.7S115,137.9,115,137.9z" fill="#dbeafe" />

                    {/* Right Wing */}
                     <path
                        className={`origin-bottom-left ${idleAnimations.wing}`}
                        style={{ animationDelay: '0.1s' }}
                        d="M85.3,103.3c0,0-29.9-12.2-40.1,1.1c-10.2,13.3,13.3,31.4,13.3,31.4S83.5,112.5,85.3,103.3z"
                        fill="#93c5fd"
                    />

                    {/* Head */}
                    <path d="M127.3,86.9c0,0-12.2-28.8-28.1-28.8s-28.1,28.8-28.1,28.8s-4.3,30.3,28.1,30.3S127.3,86.9,127.3,86.9z" fill="#60a5fa" />
                    
                    {/* Eyes */}
                    <g>
                        <path d="M111.6,80.1c0,0-0.7,6.3-5,6.3s-5-6.3-5-6.3s1.1-1.8,5-1.8S111.6,80.1,111.6,80.1z" fill="#FFFFFF" />
                        <path className={idleAnimations.eye} d="M111.2,80.3c0,0-0.4,5.2-4.5,5.2s-4.5-5.2-4.5-5.2s1-1.5,4.5-1.5S111.2,80.3,111.2,80.3z" fill="#22c55e" />
                         <circle cx="106.7" cy="81.5" r="1.5" fill="#000000"/>

                        <path d="M96.7,80.1c0,0-0.7,6.3-5,6.3s-5-6.3-5-6.3s1.1-1.8,5-1.8S96.7,80.1,96.7,80.1z" fill="#FFFFFF" />
                        <path className={idleAnimations.eye} style={{ animationDelay: '0.05s' }} d="M96.3,80.3c0,0-0.4,5.2-4.5,5.2s-4.5-5.2-4.5-5.2s1-1.5,4.5-1.5S96.3,80.3,96.3,80.3z" fill="#22c55e" />
                        <circle cx="91.8" cy="81.5" r="1.5" fill="#000000"/>
                    </g>
                    
                    {/* Horns */}
                    <path d="M115,62.1c0,0,10.7,2.2,13.3-6c2.6-8.2-6.3-13.3-6.3-13.3S115,55.4,115,62.1z" fill="#93c5fd" />
                    <path d="M84.1,62.1c0,0-10.7,2.2-13.3-6c-2.6-8.2,6.3-13.3,6.3-13.3S84.1,55.4,84.1,62.1z" fill="#93c5fd" />
                </g>
            </svg>
        </div>
    );
};

export default React.memo(Dragon);