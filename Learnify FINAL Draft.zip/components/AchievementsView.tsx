import React from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { mockAchievements } from '../data';
import AchievementCard from './achievements/AchievementCard';
import { HiTrophy as TrophyIcon } from 'react-icons/hi2';

const AchievementsView: React.FC = () => {
    const { userData } = useAppContext();

    const unlocked = mockAchievements.filter(ach => userData.unlockedAchievements.includes(ach.id));
    const locked = mockAchievements.filter(ach => !userData.unlockedAchievements.includes(ach.id));

    return (
        <div className="space-y-8">
            <div>
                <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center">
                    <TrophyIcon className="w-8 h-8 mr-3 text-yellow-500" />
                    Achievements
                </h2>
                <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">
                    Track your progress and unlock all the badges!
                </p>
            </div>
            
            <div className="liquid-glass p-6 rounded-2xl space-y-8">
                <section>
                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">Unlocked ({unlocked.length})</h3>
                    {unlocked.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {unlocked.map((ach, index) => (
                                <AchievementCard key={ach.id} achievement={ach} isLocked={false} index={index} />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-12 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg">
                            <p className="text-slate-500 dark:text-slate-400">You haven't unlocked any achievements yet. Keep learning!</p>
                        </div>
                    )}
                </section>

                <section>
                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">Locked ({locked.length})</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {locked.map((ach, index) => (
                            <AchievementCard key={ach.id} achievement={ach} isLocked={true} index={index} />
                        ))}
                    </div>
                </section>
            </div>
        </div>
    );
};

export default AchievementsView;