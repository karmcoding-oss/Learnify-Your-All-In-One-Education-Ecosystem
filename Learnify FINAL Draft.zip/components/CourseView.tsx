import React, { useState, useEffect } from 'react';
import { Course, Lesson, View } from '../types';
import { useAppContext } from '../hooks/useAppContext';
import { HiCheck as CheckIcon, HiPlus as PlusIcon, HiPencil as PencilIcon, HiTrash as TrashIcon, HiClipboardDocumentList } from 'react-icons/hi2';
import CourseModal from './modals/CourseModal';
import LessonModal from './modals/LessonModal';
import AssignmentModal from './modals/AssignmentModal';
import CheckCircleIcon from './icons/CheckCircleIcon';

const MasteryRing: React.FC<{ mastery: number }> = ({ mastery }) => {
    const radius = 30;
    const stroke = 4;
    const normalizedRadius = radius - stroke * 2;
    const circumference = normalizedRadius * 2 * Math.PI;
    const strokeDashoffset = circumference - (mastery / 100) * circumference;

    return (
        <div className="relative w-16 h-16">
            <svg height="100%" width="100%" viewBox={`0 0 ${radius*2} ${radius*2}`}>
                <circle
                    stroke="currentColor"
                    className="text-slate-200 dark:text-slate-700"
                    fill="transparent"
                    strokeWidth={stroke}
                    r={normalizedRadius}
                    cx={radius}
                    cy={radius}
                />
                <circle
                    stroke="url(#mastery-gradient)"
                    className={mastery === 100 ? "text-green-500" : ""}
                    fill="transparent"
                    strokeWidth={stroke}
                    strokeDasharray={`${circumference} ${circumference}`}
                    style={{ strokeDashoffset, transition: 'stroke-dashoffset 0.5s var(--ease-premium)' }}
                    strokeLinecap="round"
                    transform={`rotate(-90 ${radius} ${radius})`}
                    r={normalizedRadius}
                    cx={radius}
                    cy={radius}
                />
                 <defs>
                    <linearGradient id="mastery-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" style={{stopColor: 'var(--brand-primary-light)'}} />
                      <stop offset="100%" style={{stopColor: '#60a5fa'}} />
                    </linearGradient>
                </defs>
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
                {mastery === 100 ? (
                    <CheckIcon className="w-6 h-6 text-green-500" />
                ) : (
                    <span className="text-sm font-bold text-slate-700 dark:text-slate-200">{mastery}%</span>
                )}
            </div>
        </div>
    );
};


const LessonItem: React.FC<{ courseId: string, lesson: Lesson, index: number }> = ({ courseId, lesson, index }) => {
    const { navigate, deleteLesson } = useAppContext();
    const [isDeleting, setIsDeleting] = useState(false);

    const handleDelete = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (window.confirm(`Are you sure you want to delete the lesson "${lesson.title}"?`)) {
            setIsDeleting(true);
        }
    };

    useEffect(() => {
        if (isDeleting) {
            const timer = setTimeout(() => {
                deleteLesson(courseId, lesson.id);
            }, 400); // Animation duration
            return () => clearTimeout(timer);
        }
    }, [isDeleting, courseId, lesson.id, deleteLesson]);


    return (
        <li
            onClick={() => !isDeleting && navigate(View.LESSON, courseId, lesson.id)}
            style={{ animationDelay: `${index * 80}ms` }}
            className={`flex items-center justify-between p-4 liquid-glass interactive-glass rounded-lg cursor-pointer ${isDeleting ? 'animate-slide-out-fade' : 'animate-slide-in-up'}`}
        >
            <div className="flex-1">
                <p className="text-lg font-semibold text-slate-800 dark:text-slate-100">{lesson.title}</p>
            </div>
             <div className="flex items-center space-x-2">
                <MasteryRing mastery={lesson.mastery} />
                 <button 
                    onClick={handleDelete}
                    className="p-2 rounded-full text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 transition-transform hover:scale-110"
                    aria-label={`Delete ${lesson.title}`}
                 >
                    <TrashIcon className="w-5 h-5"/>
                </button>
            </div>
        </li>
    );
};

const CourseView: React.FC<{ course: Course }> = ({ course }) => {
    const [isCourseModalOpen, setIsCourseModalOpen] = useState(false);
    const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
    const [isAssignmentModalOpen, setIsAssignmentModalOpen] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const { deleteCourse, userData, navigate } = useAppContext();

    const courseAssignments = userData.assignments.filter(a => a.courseId === course.id);

    const totalLessons = course.lessons.length;
    const completedLessons = course.lessons.filter(l => l.mastery === 100).length;
    const overallProgress = totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0;
    
    const handleDeleteCourse = () => {
        if (window.confirm(`Are you sure you want to delete the course "${course.title}"? This will also delete all its assignments. This action cannot be undone.`)) {
            setIsDeleting(true);
        }
    };

     useEffect(() => {
        if (isDeleting) {
            const timer = setTimeout(() => {
                deleteCourse(course.id);
            }, 300); // Animation duration of modal-out
            return () => clearTimeout(timer);
        }
    }, [isDeleting, course.id, deleteCourse]);


    return (
        <div className={`space-y-8 ${isDeleting ? 'animate-modal-out' : ''}`}>
            <div>
                <div className="flex justify-between items-start">
                    <div>
                        <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">{course.title}</h2>
                        <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">{course.description}</p>
                    </div>
                    <div className="flex space-x-2">
                         <button onClick={() => setIsCourseModalOpen(true)} className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-transform hover:scale-110"><PencilIcon className="w-5 h-5"/></button>
                         <button onClick={handleDeleteCourse} className="p-2 rounded-full text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 transition-transform hover:scale-110"><TrashIcon className="w-5 h-5"/></button>
                    </div>
                </div>
                 <div className="mt-4">
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 progress-bar-container">
                        <div className="bg-brand-gradient h-2.5 rounded-full transition-all duration-500 ease-out" style={{ width: `${overallProgress}%` }}></div>
                    </div>
                    <p className="text-right text-sm mt-1 text-slate-500 dark:text-slate-400">{Math.round(overallProgress)}% Complete</p>
                </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <section>
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Lessons</h3>
                        <button
                            onClick={() => setIsLessonModalOpen(true)}
                            className="flex items-center space-x-2 bg-brand-gradient text-white px-4 py-2 rounded-lg font-semibold btn-animated"
                        >
                            <PlusIcon className="w-5 h-5" />
                            <span>Add Lesson</span>
                        </button>
                    </div>

                    <ul className="space-y-4">
                        {course.lessons.map((lesson, index) => (
                            <LessonItem key={lesson.id} courseId={course.id} lesson={lesson} index={index} />
                        ))}
                    </ul>
                     {course.lessons.length === 0 && (
                        <div className="text-center py-12 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg animate-slide-in-up">
                            <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">No lessons yet!</h3>
                            <p className="mt-1 text-slate-500 dark:text-slate-400">Click "Add Lesson" to start building your course.</p>
                        </div>
                    )}
                </section>

                <section>
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Assignments</h3>
                        <button
                            onClick={() => setIsAssignmentModalOpen(true)}
                            className="flex items-center space-x-2 bg-brand-gradient text-white px-4 py-2 rounded-lg font-semibold btn-animated"
                        >
                            <PlusIcon className="w-5 h-5" />
                            <span>Add Assignment</span>
                        </button>
                    </div>
                     <ul className="space-y-4">
                        {courseAssignments.map((assignment, index) => (
                             <li 
                                key={assignment.id} 
                                onClick={() => navigate(View.ASSIGNMENT, null, null, assignment.id)}
                                className={`flex items-center justify-between p-4 liquid-glass rounded-lg cursor-pointer animate-slide-in-up ${assignment.isCompleted ? 'opacity-60' : 'interactive-glass'}`}
                                style={{ animationDelay: `${index * 80}ms` }}
                            >
                                <p className={`font-semibold ${assignment.isCompleted ? 'line-through text-slate-500 dark:text-slate-400' : ''}`}>{assignment.title}</p>
                                <div className="flex items-center space-x-3">
                                    {assignment.isCompleted && <CheckCircleIcon className="w-5 h-5 text-green-500" />}
                                    {assignment.dueDate && <p className="text-sm text-slate-500 dark:text-slate-400">Due: {new Date(assignment.dueDate + 'T00:00:00').toLocaleDateString()}</p>}
                                </div>
                            </li>
                        ))}
                    </ul>
                     {courseAssignments.length === 0 && (
                        <div className="text-center py-12 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg animate-slide-in-up">
                            <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">No assignments yet!</h3>
                            <p className="mt-1 text-slate-500 dark:text-slate-400">Click "Add Assignment" to create one.</p>
                        </div>
                    )}
                </section>
            </div>
            
            <CourseModal isOpen={isCourseModalOpen} onClose={() => setIsCourseModalOpen(false)} course={course} />
            <LessonModal isOpen={isLessonModalOpen} onClose={() => setIsLessonModalOpen(false)} courseId={course.id} />
            <AssignmentModal isOpen={isAssignmentModalOpen} onClose={() => setIsAssignmentModalOpen(false)} courseId={course.id} />
        </div>
    );
};

export default CourseView;