import React, { useState, useMemo } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { CalendarEvent } from '../types';
import EventModal from './modals/EventModal';
import { HiPlus as PlusIcon, HiChevronLeft as ChevronLeftIcon, HiChevronRight as ChevronRightIcon, HiPencil as PencilIcon, HiTrash as TrashIcon, HiMapPin as MapPinIcon, HiClipboardDocumentList } from 'react-icons/hi2';

const CalendarView: React.FC = () => {
    const { userData, deleteEvent, courses } = useAppContext();
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState<Date>(new Date());
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingEvent, setEditingEvent] = useState<CalendarEvent | undefined>(undefined);

    const firstDayOfMonth = useMemo(() => new Date(currentDate.getFullYear(), currentDate.getMonth(), 1), [currentDate]);
    const lastDayOfMonth = useMemo(() => new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0), [currentDate]);

    const daysInMonth = useMemo(() => {
        const days = [];
        // Days from previous month
        const startingDay = firstDayOfMonth.getDay();
        for (let i = 0; i < startingDay; i++) {
            const date = new Date(firstDayOfMonth);
            date.setDate(date.getDate() - (startingDay - i));
            days.push({ date, isCurrentMonth: false });
        }
        // Days in current month
        for (let i = 1; i <= lastDayOfMonth.getDate(); i++) {
            days.push({ date: new Date(currentDate.getFullYear(), currentDate.getMonth(), i), isCurrentMonth: true });
        }
        // Days from next month
        const endingDay = lastDayOfMonth.getDay();
        for (let i = 1; i < 7 - endingDay; i++) {
            const date = new Date(lastDayOfMonth);
            date.setDate(date.getDate() + i);
            days.push({ date, isCurrentMonth: false });
        }
        return days;
    }, [firstDayOfMonth, lastDayOfMonth, currentDate]);
    
    const eventsByDate = useMemo(() => {
        return userData.events.reduce((acc, event) => {
            (acc[event.date] = acc[event.date] || []).push(event);
            return acc;
        }, {} as Record<string, CalendarEvent[]>);
    }, [userData.events]);

    const handlePrevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    const handleNextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    const handleToday = () => {
      const today = new Date();
      setCurrentDate(today);
      setSelectedDate(today);
    }

    const openAddModal = () => {
        setEditingEvent(undefined);
        setIsModalOpen(true);
    };
    
    const openEditModal = (event: CalendarEvent) => {
        setEditingEvent(event);
        setIsModalOpen(true);
    };

    const handleDeleteEvent = (eventId: string) => {
        if (window.confirm("Are you sure you want to delete this event? This may also remove the due date from an associated assignment.")) {
            deleteEvent(eventId);
        }
    }

    const formatDateKey = (date: Date) => date.toISOString().split('T')[0];
    const todayKey = formatDateKey(new Date());

    const selectedDateEvents = eventsByDate[formatDateKey(selectedDate)] || [];
    
    return (
        <div>
            <div className="flex flex-col md:flex-row items-center justify-between mb-6">
                <div className="flex items-center space-x-2">
                    <button onClick={handlePrevMonth} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><ChevronLeftIcon className="w-6 h-6"/></button>
                    <h2 className="text-2xl font-bold text-center w-48">{currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}</h2>
                    <button onClick={handleNextMonth} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><ChevronRightIcon className="w-6 h-6"/></button>
                    <button onClick={handleToday} className="px-3 py-1 text-sm font-semibold border rounded-md dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">Today</button>
                </div>
                <button onClick={openAddModal} className="mt-4 md:mt-0 flex items-center space-x-2 bg-brand-gradient text-white px-4 py-2 rounded-lg font-semibold btn-animated">
                    <PlusIcon className="w-5 h-5" />
                    <span>Add Event</span>
                </button>
            </div>

            <div className="liquid-glass rounded-2xl p-4">
                <div className="grid grid-cols-7 gap-1 text-center font-semibold text-slate-500 dark:text-slate-400 mb-2">
                    {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => <div key={day}>{day}</div>)}
                </div>
                <div className="grid grid-cols-7 gap-1">
                    {daysInMonth.map(({ date, isCurrentMonth }, index) => {
                        const dateKey = formatDateKey(date);
                        const dayEvents = eventsByDate[dateKey] || [];
                        const isToday = dateKey === todayKey;
                        const isSelected = dateKey === formatDateKey(selectedDate);
                        return (
                            <div 
                                key={index} 
                                onClick={() => setSelectedDate(date)}
                                className={`h-24 p-2 border border-transparent rounded-lg cursor-pointer transition-all duration-200 ease-in-out ${isCurrentMonth ? 'dark:hover:bg-white/10 hover:bg-black/5' : ''} ${isSelected ? '!border-brand bg-brand-subtle' : ''}`}
                            >
                                <span className={`flex items-center justify-center text-sm font-semibold w-7 h-7 rounded-full transition-colors ${isCurrentMonth ? 'text-slate-800 dark:text-slate-200' : 'text-slate-400 dark:text-slate-600'} ${isToday ? 'bg-brand-gradient !text-white' : ''}`}>
                                    {date.getDate()}
                                </span>
                                <div className="flex space-x-1 mt-1">
                                    {dayEvents.slice(0, 3).map(e => <div key={e.id} className="w-2 h-2 rounded-full bg-brand" title={e.title}></div>)}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            <div className="mt-8">
                 <h3 className="text-2xl font-bold mb-4">Events for {selectedDate.toLocaleDateString('default', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</h3>
                 <div className="space-y-3">
                     {selectedDateEvents.length > 0 ? selectedDateEvents.map((event, index) => {
                         const course = courses.find(c => c.id === event.courseId);
                         return (
                            <div key={event.id} className="liquid-glass rounded-lg p-4 flex items-center justify-between animate-slide-in-up" style={{ animationDelay: `${index * 80}ms`}}>
                                <div className="flex items-center space-x-4">
                                    <div className="text-center font-bold text-brand border-r pr-4 dark:border-slate-600">
                                        <p className="text-sm">{event.time ? event.time : 'All Day'}</p>
                                    </div>
                                    <div>
                                        <p className="font-bold flex items-center">{event.assignmentId && <HiClipboardDocumentList className="w-4 h-4 mr-2 text-slate-500" />} {event.title}</p>
                                        <p className="text-sm text-slate-500 dark:text-slate-400">{event.description}</p>
                                        {event.location && (
                                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center">
                                                <MapPinIcon className="w-3 h-3 mr-1.5" />
                                                {event.location}
                                            </p>
                                        )}
                                        {course && <p className="text-xs mt-1 px-2 py-0.5 bg-brand-subtle text-brand-subtle rounded-full inline-block">{course.title}</p>}
                                    </div>
                                </div>
                                <div className="flex space-x-2">
                                    <button onClick={() => openEditModal(event)} disabled={!!event.assignmentId} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-transform hover:scale-110 disabled:opacity-50 disabled:cursor-not-allowed"><PencilIcon className="w-5 h-5"/></button>
                                    <button onClick={() => handleDeleteEvent(event.id)} className="p-2 rounded-full text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 transition-transform hover:scale-110"><TrashIcon className="w-5 h-5"/></button>
                                </div>
                            </div>
                         );
                     }) : (
                        <p className="text-slate-500 dark:text-slate-400 animate-slide-in-up">No events scheduled for this day.</p>
                     )}
                 </div>
            </div>

            <EventModal 
                isOpen={isModalOpen} 
                onClose={() => setIsModalOpen(false)} 
                event={editingEvent}
                initialDate={formatDateKey(selectedDate)}
            />
        </div>
    );
};

export default CalendarView;