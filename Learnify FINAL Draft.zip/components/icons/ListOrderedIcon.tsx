import React from 'react';

const ListOrderedIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M7,13V11H21V13H7M7,19V17H21V19H7M7,7V5H21V7H7M3,8H4.5V9H2V6H5V7H3V8M2,16H5V17H3V18H4.5V19H2V16M2,11H4.25L2,13.25V14H5V12H2.75L5,9.75V9H2V11Z" /></svg>
);

export default ListOrderedIcon;