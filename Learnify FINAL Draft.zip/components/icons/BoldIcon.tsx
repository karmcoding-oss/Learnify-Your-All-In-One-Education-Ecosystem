import React from 'react';

const BoldIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}><path d="M15.5,15.5H10V18.5H15.5A2.5,2.5,0,0,0,18,16A2.5,2.5,0,0,0,15.5,13.5V15.5M15,5.5H10V12.5H15A2.5,2.5,0,0,0,17.5,10A2.5,2.5,0,0,0,15,7.5V5.5M7.5,4H15A4,4,0,0,1,19,8A4,4,0,0,1,15,12H10V13H15.5A4.5,4.5,0,0,1,20,17.5A4.5,4.5,0,0,1,15.5,22H7.5V4Z" /></svg>
);

export default BoldIcon;