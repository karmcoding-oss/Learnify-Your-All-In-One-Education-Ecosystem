import React, { useState, useMemo } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import Dragon from '../gamification/Dragon';
import { DragonState } from '../../types';

const moodOptions = [
    { mood: 1, emoji: '😔', label: 'Awful', color: 'bg-red-500' },
    { mood: 2, emoji: '😕', label: 'Bad', color: 'bg-orange-500' },
    { mood: 3, emoji: '😐', label: 'Okay', color: 'bg-yellow-500' },
    { mood: 4, emoji: '🙂', label: 'Good', color: 'bg-green-500' },
    { mood: 5, emoji: '😁', label: 'Great', color: 'bg-teal-500' },
];

const MoodChart: React.FC = () => {
    const { userData } = useAppContext();

    const chartData = useMemo(() => {
        const today = new Date();
        const data = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(today.getDate() - i);
            const dateString = date.toISOString().split('T')[0];
            const dayLog = userData.moodLog.find(log => log.date === dateString);
            data.push({
                day: date.toLocaleDateString('en-US', { weekday: 'short' }),
                mood: dayLog?.mood || 0,
            });
        }
        return data;
    }, [userData.moodLog]);

    return (
        <div className="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-lg">
            <h4 className="font-bold text-lg mb-4 text-center">Your Week in Moods</h4>
            <div className="flex justify-around items-end h-48">
                {chartData.map((data, index) => (
                    <div key={index} className="flex flex-col items-center w-1/7">
                        <div className="w-8 flex-grow flex items-end">
                             {data.mood > 0 && (
                                <div
                                    className={`w-full rounded-t-md ${moodOptions[data.mood - 1].color} transition-all duration-500`}
                                    style={{ height: `${(data.mood / 5) * 100}%` }}
                                    title={`${moodOptions[data.mood - 1].label}`}
                                ></div>
                            )}
                        </div>
                        <span className="text-xs mt-2 text-slate-500 dark:text-slate-400">{data.day}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};


const MoodTracker: React.FC<{ isDashboard?: boolean }> = ({ isDashboard = false }) => {
    const { userData, addMoodLog } = useAppContext();
    const today = new Date().toISOString().split('T')[0];
    const todaysLog = userData.moodLog.find(log => log.date === today);

    const [selectedMood, setSelectedMood] = useState<number | null>(todaysLog?.mood || null);
    const [note, setNote] = useState(todaysLog?.note || '');
    const [isSaved, setIsSaved] = useState(false);
    const [dragonState, setDragonState] = useState<DragonState>('hidden');

    const handleSave = () => {
        if (selectedMood) {
            addMoodLog({ mood: selectedMood, note });
            setIsSaved(true);
            setDragonState('celebrating');
            setTimeout(() => setIsSaved(false), 2000);
            setTimeout(() => setDragonState('hidden'), 3000);
        }
    };

    const moodStreak = useMemo(() => {
        let streak = 0;
        const today = new Date();
        const sortedLogs = [...userData.moodLog].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        
        const todayLogged = sortedLogs.some(log => log.date === today.toISOString().split('T')[0]);
        if(!todayLogged) return 0;

        let currentDate = today;
        for (const log of sortedLogs) {
             const logDate = new Date(log.date + 'T00:00:00'); // Avoid timezone issues
             const diffDays = Math.round((currentDate.getTime() - logDate.getTime()) / (1000 * 60 * 60 * 24));
             if (diffDays === 0) {
                 streak++;
                 currentDate.setDate(currentDate.getDate() - 1);
             } else if (diffDays > 1) {
                 break;
             }
        }
        return streak;
    }, [userData.moodLog]);

    if (isDashboard) {
        return (
            <div>
                 <div className="flex flex-col md:flex-row gap-6">
                    <div className="flex-1">
                        <h3 className="text-xl font-bold mb-4">Mood Dashboard</h3>
                        <MoodChart />
                    </div>
                    <div className="md:w-1/3 space-y-4">
                        <div className="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-lg text-center">
                            <p className="text-slate-500 dark:text-slate-400">Logging Streak</p>
                            <p className="text-4xl font-bold text-brand">{moodStreak} Days</p>
                        </div>
                         <div className="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-lg">
                             <h4 className="font-bold mb-2">Recent Notes</h4>
                             <ul className="space-y-2 text-sm max-h-32 overflow-y-auto">
                                {userData.moodLog.filter(l => l.note).slice(0, 5).map(log => (
                                    <li key={log.date} className="text-slate-600 dark:text-slate-300">
                                        <span className="font-semibold">{new Date(log.date + 'T00:00:00').toLocaleDateString()}:</span> {log.note}
                                    </li>
                                ))}
                             </ul>
                        </div>
                    </div>
                </div>
            </div>
        );
    }


    return (
        <div className="flex flex-col items-center">
            <Dragon state={dragonState} />
            <h3 className="text-2xl font-bold mb-2">How are you feeling today?</h3>
            <p className="text-slate-500 dark:text-slate-400 mb-6">Logging your mood helps you understand your emotional patterns.</p>
            
            <div className="flex justify-center space-x-2 sm:space-x-4 mb-6">
                {moodOptions.map(({ mood, emoji, label }) => (
                    <button
                        key={mood}
                        onClick={() => setSelectedMood(mood)}
                        className={`flex flex-col items-center p-2 sm:p-4 rounded-lg border-2 transition-all transform hover:scale-110 ${selectedMood === mood ? 'border-brand bg-brand-subtle' : 'border-transparent'}`}
                        title={label}
                    >
                        <span className="text-4xl sm:text-5xl">{emoji}</span>
                        <span className="text-xs mt-2 text-slate-600 dark:text-slate-300">{label}</span>
                    </button>
                ))}
            </div>

            <div className="w-full max-w-lg mb-6">
                 <label htmlFor="mood-note" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Add a note (optional)</label>
                 <textarea
                    id="mood-note"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                    placeholder="What's on your mind?"
                    rows={3}
                 />
            </div>
            
            <button
                onClick={handleSave}
                disabled={!selectedMood || isSaved}
                className="bg-brand-gradient text-white px-8 py-3 rounded-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
                {isSaved ? 'Saved!' : 'Save Today\'s Mood'}
            </button>
        </div>
    );
};

export default MoodTracker;