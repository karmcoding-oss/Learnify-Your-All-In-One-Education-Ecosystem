import React, { useState } from 'react';
import { getMentalHealthResources } from '../../services/geminiService';
import { HiSparkles as SparklesIcon } from 'react-icons/hi2';

const ExtraResources: React.FC = () => {
    const [feeling, setFeeling] = useState('');
    const [resources, setResources] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGetResources = async () => {
        if (!feeling.trim()) {
            setError('Please describe how you are feeling.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setResources(null);

        try {
            const result = await getMentalHealthResources(feeling);
            setResources(result);
        } catch (err: any) {
            setError(err.message || "Failed to fetch resources.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="animate-slide-in">
            <h3 className="text-2xl font-bold mb-2">Find Extra Resources</h3>
            <p className="text-slate-500 dark:text-slate-400 mb-6">
                Describe what you're feeling, and we'll find some helpful information and activities for you.
            </p>

            <div className="flex flex-col sm:flex-row gap-2 mb-6">
                <textarea
                    value={feeling}
                    onChange={(e) => setFeeling(e.target.value)}
                    placeholder="e.g., I'm feeling stressed about my upcoming exams..."
                    className="flex-1 p-3 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand transition-colors"
                    rows={2}
                    disabled={isLoading}
                />
                <button
                    onClick={handleGetResources}
                    disabled={isLoading}
                    className="bg-brand-gradient text-white px-6 py-2 rounded-lg font-semibold disabled:opacity-50 flex items-center justify-center space-x-2"
                >
                    <SparklesIcon className="w-5 h-5"/>
                    <span>{isLoading ? 'Finding...' : 'Get Resources'}</span>
                </button>
            </div>
            
            {error && <p className="text-red-500 text-center">{error}</p>}
            
            {isLoading && (
                 <div className="flex justify-center items-center h-40">
                    <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-brand rounded-full animate-pulse"></div>
                        <div className="w-3 h-3 bg-brand rounded-full animate-pulse delay-75"></div>
                        <div className="w-3 h-3 bg-brand rounded-full animate-pulse delay-150"></div>
                    </div>
                </div>
            )}
            
            {resources && (
                <div className="bg-slate-50 dark:bg-slate-700/50 p-6 rounded-lg">
                    <p className="whitespace-pre-wrap text-slate-700 dark:text-slate-200">{resources}</p>
                </div>
            )}
        </div>
    );
};

export default ExtraResources;