import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { StudyBreakSettings } from '../../types';
import Modal from '../modals/Modal';

const affirmations = [
    "I am capable of achieving my goals.",
    "I am worthy of rest and relaxation.",
    "I choose to focus on progress, not perfection.",
    "Every challenge is an opportunity to grow.",
    "I am proud of how far I have come.",
    "I am in control of my thoughts and feelings.",
    "I radiate positivity and attract good things.",
];

const journalPrompts = [
    "What is one thing you are grateful for today?",
    "Describe a small victory you had recently.",
    "What is something you are looking forward to?",
    "Write down a compliment you can give yourself.",
    "What's one thing that made you smile today?",
];

const StudyBreakManager = () => {
    const { userData, updateStudyBreakSettings } = useAppContext();
    const [settings, setSettings] = useState<StudyBreakSettings>(userData.studyBreakSettings || { enabled: false, interval: 30 });
    const [saved, setSaved] = useState(false);

    const handleToggle = () => {
        setSettings(prev => ({ ...prev, enabled: !prev.enabled }));
    };

    const handleIntervalChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setSettings(prev => ({ ...prev, interval: parseInt(e.target.value) }));
    };
    
    const handleSave = () => {
        updateStudyBreakSettings(settings);
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
    }

    return (
        <div className="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-lg">
            <h4 className="font-bold text-lg mb-2">Study Break Reminders</h4>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Get notified to take a break during long study sessions in a lesson.</p>
            <div className="flex items-center space-x-4">
                <div className="flex items-center">
                    <label htmlFor="break-toggle" className="mr-2 font-medium">Enable Reminders</label>
                    <button
                        id="break-toggle"
                        onClick={handleToggle}
                        className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${settings.enabled ? 'bg-brand-gradient' : 'bg-slate-300 dark:bg-slate-600'}`}
                    >
                        <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${settings.enabled ? 'translate-x-6' : 'translate-x-1'}`} />
                    </button>
                </div>
                <select 
                    value={settings.interval}
                    onChange={handleIntervalChange}
                    disabled={!settings.enabled}
                    className="p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 disabled:opacity-50"
                >
                    <option value={30}>Every 30 mins</option>
                    <option value={45}>Every 45 mins</option>
                    <option value={60}>Every 60 mins</option>
                </select>
            </div>
             <div className="text-right mt-4">
                <button onClick={handleSave} className="bg-brand-gradient text-white px-4 py-2 rounded-lg font-semibold text-sm">
                    {saved ? 'Saved!' : 'Save Settings'}
                </button>
            </div>
        </div>
    );
};

const WellbeingActivities: React.FC = () => {
    const { addJournalEntry } = useAppContext();
    const [currentAffirmation, setCurrentAffirmation] = useState('');
    const [isJournalOpen, setIsJournalOpen] = useState(false);
    const [journalPrompt, setJournalPrompt] = useState('');
    const [journalEntry, setJournalEntry] = useState('');

    useEffect(() => {
        setCurrentAffirmation(affirmations[Math.floor(Math.random() * affirmations.length)]);
    }, []);

    const openJournal = () => {
        setJournalPrompt(journalPrompts[Math.floor(Math.random() * journalPrompts.length)]);
        setJournalEntry('');
        setIsJournalOpen(true);
    };

    const handleSaveJournal = () => {
        if(journalEntry.trim()){
            addJournalEntry({ prompt: journalPrompt, entry: journalEntry });
        }
        setIsJournalOpen(false);
    }

    return (
        <div className="space-y-6">
            <h3 className="text-2xl font-bold">Activities & Tools</h3>
            <StudyBreakManager />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-slate-50 dark:bg-slate-700/50 p-6 rounded-lg text-center flex flex-col items-center justify-center">
                    <h4 className="font-bold text-lg mb-2">Positive Affirmation</h4>
                    <p className="text-brand-subtle italic">"{currentAffirmation}"</p>
                </div>

                <div className="bg-slate-50 dark:bg-slate-700/50 p-6 rounded-lg text-center flex flex-col items-center justify-center">
                    <h4 className="font-bold text-lg mb-2">Quick Reflection</h4>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Take 60 seconds to reflect on your day.</p>
                    <button onClick={openJournal} className="bg-brand-subtle text-brand-subtle px-4 py-2 rounded-lg font-semibold text-sm">
                        Open Journal
                    </button>
                </div>
            </div>
            
             <Modal isOpen={isJournalOpen} onClose={() => setIsJournalOpen(false)} title="Quick Journal">
                <p className="font-semibold mb-4">{journalPrompt}</p>
                 <textarea
                    value={journalEntry}
                    onChange={(e) => setJournalEntry(e.target.value)}
                    className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                    rows={5}
                    placeholder="Write your thoughts..."
                 />
                 <div className="text-right mt-4">
                    <button onClick={handleSaveJournal} className="bg-brand-gradient text-white px-6 py-2 rounded-lg font-semibold">
                        Save Entry
                    </button>
                 </div>
            </Modal>
        </div>
    );
};

export default WellbeingActivities;