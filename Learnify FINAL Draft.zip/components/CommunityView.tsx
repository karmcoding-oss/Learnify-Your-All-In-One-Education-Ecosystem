import React from 'react';
import StudentConnect from './dashboard/StudentConnect';
import { HiUsers as UsersIcon } from 'react-icons/hi2';

const CommunityView: React.FC = () => {
    return (
        <div className="space-y-8 animate-slide-in">
            <div>
                <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center">
                    <UsersIcon className="w-8 h-8 mr-3 text-brand" />
                    Community
                </h2>
                <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">
                    Connect with your peers, make friends, and study together.
                </p>
            </div>
            <StudentConnect />
        </div>
    );
};

export default CommunityView;