import React, { useState } from 'react';
import { getAIAssistanceForAssignment } from '../../services/geminiService';
import { HiSparkles } from 'react-icons/hi2';

interface AIAssistantProps {
    assignmentContext: string;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ assignmentContext }) => {
    const [prompt, setPrompt] = useState('');
    const [response, setResponse] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim() || isLoading) return;

        setIsLoading(true);
        setError('');
        setResponse('');
        try {
            const result = await getAIAssistanceForAssignment(prompt, assignmentContext);
            setResponse(result);
        } catch (err: any) {
            setError(err.message || 'An error occurred.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const quickPrompts = [
        "Summarize the text above.",
        "Check for grammar and spelling mistakes.",
        "Suggest 3 alternative titles.",
        "Expand on the main points.",
    ];

    return (
        <div className="h-full flex flex-col">
            <h3 className="text-xl font-bold mb-4 flex items-center"><HiSparkles className="w-6 h-6 mr-2 text-brand" /> AI Assistant</h3>
            
            <div className="flex-1 overflow-y-auto pr-2 space-y-4">
                {isLoading && (
                    <div className="text-center p-8">
                         <HiSparkles className="w-8 h-8 text-brand animate-pulse mx-auto" />
                        <p>Thinking...</p>
                    </div>
                )}
                {error && <p className="text-red-500">{error}</p>}
                {response && <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-lg prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: response.replace(/\n/g, '<br />') }} />}
                {!isLoading && !response && (
                    <div className="text-center p-4">
                        <p className="text-slate-500 dark:text-slate-400">Use your assignment content as context. Ask the AI to summarize, edit, or generate ideas!</p>
                        <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
                            {quickPrompts.map(p => (
                                <button key={p} onClick={() => setPrompt(p)} className="p-2 bg-slate-100 dark:bg-slate-700 rounded-md hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors text-left">
                                    {p}
                                </button>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            <form onSubmit={handleSubmit} className="mt-4">
                <textarea
                    value={prompt}
                    onChange={e => setPrompt(e.target.value)}
                    placeholder="Ask for help... (e.g., 'Help me write an introduction')"
                    className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                    rows={2}
                />
                <button type="submit" disabled={isLoading} className="w-full mt-2 bg-brand-gradient text-white py-2 rounded-lg font-semibold disabled:opacity-50">
                    {isLoading ? 'Generating...' : 'Ask AI'}
                </button>
            </form>
        </div>
    );
};

export default AIAssistant;