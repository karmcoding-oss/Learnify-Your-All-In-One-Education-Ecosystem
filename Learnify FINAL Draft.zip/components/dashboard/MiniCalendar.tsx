import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { View } from '../../types';
import { HiCalendarDays as CalendarIcon } from 'react-icons/hi2';

const MiniCalendar: React.FC = () => {
    const { userData, navigate } = useAppContext();

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const nextSevenDays = Array.from({ length: 7 }).map((_, i) => {
        const date = new Date(today);
        date.setDate(today.getDate() + i);
        return date;
    });

    const formatDateKey = (date: Date) => date.toISOString().split('T')[0];
    const todayKey = formatDateKey(new Date());

    return (
        <div 
            onClick={() => navigate(View.CALENDAR)} 
            className="liquid-glass interactive-glass rounded-2xl p-6 cursor-pointer"
        >
            <div className="flex justify-between items-center mb-4">
                 <h3 className="text-xl font-bold flex items-center">
                    <CalendarIcon className="w-6 h-6 mr-2 text-brand" /> This Week
                </h3>
                <span className="text-xs font-semibold text-brand hover:underline">View All</span>
            </div>
            
            <div className="space-y-4 max-h-64 overflow-y-auto pr-2">
                {nextSevenDays.map((date, index) => {
                    const dateKey = formatDateKey(date);
                    const events = userData.events.filter(e => e.date === dateKey);
                    const isToday = dateKey === todayKey;

                    return (
                        <div key={index} className="flex space-x-3">
                            <div className="flex-shrink-0 text-center">
                                <p className={`text-xs font-semibold uppercase ${isToday ? 'text-brand' : 'text-slate-400 dark:text-slate-500'}`}>{date.toLocaleDateString('en-US', { weekday: 'short' })}</p>
                                <p className={`text-xl font-bold ${isToday ? 'text-brand' : 'text-slate-700 dark:text-slate-200'}`}>{date.getDate()}</p>
                            </div>
                            <div className={`w-full border-l-2 pl-3 transition-colors ${isToday ? 'border-brand' : 'border-slate-200 dark:border-slate-700'}`}>
                                {events.length > 0 ? (
                                    <ul className="space-y-1">
                                        {events.map(event => (
                                            <li key={event.id} className="text-sm p-1.5 rounded-md bg-brand-subtle">
                                                <p className="font-semibold text-brand-subtle truncate">{event.title}</p>
                                                <div className="flex items-center justify-between text-xs text-brand">
                                                    <span>{event.time}</span>
                                                    <span className="truncate">{event.location}</span>
                                                </div>
                                            </li>
                                        ))}
                                    </ul>
                                ) : (
                                    <p className="text-sm text-slate-400 dark:text-slate-500 pt-1">No events.</p>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default MiniCalendar;