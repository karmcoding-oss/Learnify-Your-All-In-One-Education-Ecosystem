import React from 'react';
import { HiHeart as HeartIcon } from 'react-icons/hi2';
import { useAppContext } from '../../hooks/useAppContext';
import { View } from '../../types';

const moodEmojis = ['N/A', '😔', '😕', '😐', '🙂', '😁'];
const moodLabels = ['N/A', 'Awful', 'Bad', 'Okay', 'Good', 'Great'];

const MentalHealthWidget: React.FC = () => {
    const { userData, navigate } = useAppContext();
    const today = new Date().toISOString().split('T')[0];
    const todaysLog = userData.moodLog.find(log => log.date === today);

    return (
        <div 
            onClick={() => navigate(View.MENTAL_HEALTH)}
            className="liquid-glass interactive-glass rounded-2xl p-6 cursor-pointer"
        >
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold flex items-center">
                    <HeartIcon className="w-6 h-6 mr-2 text-pink-500" /> Mental Wellbeing
                </h3>
                <span className="text-xs font-semibold text-brand hover:underline">Explore</span>
            </div>
            
            <div className="text-center">
                {todaysLog ? (
                    <>
                        <p className="text-sm text-slate-500 dark:text-slate-400">Today you're feeling:</p>
                        <div className="text-5xl my-2">{moodEmojis[todaysLog.mood]}</div>
                        <p className="font-semibold">{moodLabels[todaysLog.mood]}</p>
                    </>
                ) : (
                     <>
                        <p className="text-sm text-slate-500 dark:text-slate-400">How are you feeling today?</p>
                        <div className="text-5xl my-2 text-slate-300 dark:text-slate-600">?</div>
                        <p className="font-semibold text-slate-600 dark:text-slate-300">Log Your Mood</p>
                    </>
                )}
            </div>
        </div>
    );
};

export default MentalHealthWidget;