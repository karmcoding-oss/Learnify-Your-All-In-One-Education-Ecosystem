import React, { useState, useMemo } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { View } from '../../types';
import { HiPlus, HiClipboardDocumentList } from 'react-icons/hi2';
import AssignmentModal from '../modals/AssignmentModal';

const AssignmentsWidget: React.FC = () => {
    const { userData, courses, navigate } = useAppContext();
    const [isModalOpen, setIsModalOpen] = useState(false);

    const sortedAssignments = useMemo(() => {
        return [...userData.assignments]
            .filter(a => !a.isCompleted)
            .sort((a, b) => {
                if (!a.dueDate) return 1;
                if (!b.dueDate) return -1;
                return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
            });
    }, [userData.assignments]);

    const getPriority = (dueDate: string | null): { label: string; color: string } => {
        if (!dueDate) return { label: 'No Date', color: 'bg-slate-400' };
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const due = new Date(dueDate);
        const diffTime = due.getTime() - today.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays < 0) return { label: 'Overdue', color: 'bg-red-600' };
        if (diffDays <= 3) return { label: 'High', color: 'bg-red-500' };
        if (diffDays <= 7) return { label: 'Medium', color: 'bg-orange-500' };
        return { label: 'Low', color: 'bg-green-500' };
    };

    const maxTimeSpent = useMemo(() => {
        const activeAssignments = userData.assignments.filter(a => !a.isCompleted);
        if (activeAssignments.length === 0) return 3600;
        const max = Math.max(...activeAssignments.map(a => a.timeSpent), 0);
        // Use the max value, but ensure it's at least 1 hour (3600s) for a reasonable scale initially.
        return Math.max(max, 3600);
    }, [userData.assignments]);

    const formatTime = (seconds: number) => {
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        return `${h}h ${m}m`;
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center">
                    <HiClipboardDocumentList className="w-6 h-6 mr-2" />
                    Assignments & Projects
                </h3>
                <button
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center space-x-2 bg-brand-gradient text-white px-4 py-2 rounded-lg font-semibold btn-animated"
                >
                    <HiPlus className="w-5 h-5" />
                    <span className="hidden sm:inline">Add Assignment</span>
                </button>
            </div>
            {sortedAssignments.length > 0 ? (
                <div className="liquid-glass rounded-2xl p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                        {sortedAssignments.map((assignment) => {
                            const course = courses.find(c => c.id === assignment.courseId);
                            const priority = getPriority(assignment.dueDate);
                            const timePercentage = (assignment.timeSpent / maxTimeSpent) * 100;

                            return (
                                <div 
                                    key={assignment.id} 
                                    onClick={() => navigate(View.ASSIGNMENT, null, null, assignment.id)}
                                    className="group cursor-pointer"
                                >
                                    <div className="flex justify-between items-center">
                                        <div>
                                            <p className="font-bold group-hover:text-brand transition-colors">{assignment.title}</p>
                                            <p className="text-xs text-slate-500 dark:text-slate-400">{course?.title || 'No Course'}</p>
                                        </div>
                                        <div className="flex items-center space-x-2">
                                            {assignment.dueDate && <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{new Date(assignment.dueDate + 'T00:00:00').toLocaleDateString()}</p>}
                                            <div className={`w-3 h-3 rounded-full ${priority.color}`} title={priority.label}></div>
                                        </div>
                                    </div>
                                    <div className="mt-2">
                                        <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 relative progress-bar-container">
                                            <div className="bg-brand-gradient h-2.5 rounded-full transition-all duration-500 ease-out" style={{ width: `${timePercentage}%` }}></div>
                                        </div>
                                        <p className="text-right text-xs mt-1 text-slate-500 dark:text-slate-400">Time Spent: {formatTime(assignment.timeSpent)}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            ) : (
                <div className="text-center py-12 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg">
                    <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200">No Active Assignments</h3>
                    <p className="mt-1 text-slate-500 dark:text-slate-400">Click "Add Assignment" to get started, or check your courses for completed work.</p>
                </div>
            )}
            <AssignmentModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
        </div>
    );
};

export default AssignmentsWidget;