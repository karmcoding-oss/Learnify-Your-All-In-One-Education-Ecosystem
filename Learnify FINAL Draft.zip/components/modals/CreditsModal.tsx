import React, { useState, useEffect } from 'react';
import { HiXMark } from 'react-icons/hi2';

interface CreditsModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const CreditsModal: React.FC<CreditsModalProps> = ({ isOpen, onClose }) => {
    const [isClosing, setIsClosing] = useState(false);

    useEffect(() => {
        if (!isOpen) {
            setIsClosing(false);
        }
    }, [isOpen]);

    const handleClose = () => {
        setIsClosing(true);
        setTimeout(onClose, 250); // Match animation-out duration
    };

    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={handleClose}
            aria-modal="true"
            role="dialog"
        >
            <div 
                className={`liquid-glass rounded-2xl w-full max-w-md transform ${isClosing ? 'animate-modal-out' : 'animate-modal-in'}`}
                onClick={e => e.stopPropagation()}
            >
                <div className="flex items-center justify-between p-4 border-b border-white/20 dark:border-slate-700/50">
                    <h2 className="text-xl font-bold">Credits</h2>
                    <button onClick={handleClose} className="p-1 rounded-full hover:bg-black/10 dark:hover:bg-white/10">
                        <HiXMark className="w-6 h-6 text-slate-500" />
                    </button>
                </div>
                <div className="p-6 space-y-4">
                    <p className="text-slate-700 dark:text-slate-300">
                        This application was designed and developed by a passionate frontend engineer, bringing together a fluid user experience with the power of Google's Gemini API.
                    </p>
                    <p className="font-semibold text-brand-gradient">
                        A major thank you to the Student Hackpad organizers for creating this opportunity to build, learn, and innovate.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default CreditsModal;
