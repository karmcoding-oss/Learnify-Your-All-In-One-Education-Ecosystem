import React, { useState, useEffect } from 'react';
import { CalendarEvent } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';
import Modal from './Modal';

interface EventModalProps {
    isOpen: boolean;
    onClose: () => void;
    event?: CalendarEvent;
    initialDate?: string;
}

const EventModal: React.FC<EventModalProps> = ({ isOpen, onClose, event, initialDate }) => {
    const { courses, addEvent, updateEvent } = useAppContext();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [courseId, setCourseId] = useState('');
    const [location, setLocation] = useState('');

    useEffect(() => {
        if (isOpen) {
            if (event) {
                setTitle(event.title);
                setDescription(event.description);
                setDate(event.date);
                setTime(event.time || '');
                setCourseId(event.courseId || '');
                setLocation(event.location || '');
            } else {
                setTitle('');
                setDescription('');
                setDate(initialDate || new Date().toISOString().split('T')[0]);
                setTime('');
                setCourseId('');
                setLocation('');
            }
        }
    }, [event, isOpen, initialDate]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim() || !date) return;

        const eventData = { title, description, date, time, courseId: courseId || undefined, location: location || undefined };

        if (event) {
            updateEvent(event.id, eventData);
        } else {
            addEvent(eventData);
        }
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={event ? 'Edit Event' : 'Add New Event'}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="event-title" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Title</label>
                    <input
                        type="text" id="event-title" value={title} onChange={e => setTitle(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        placeholder="e.g., Midterm Exam" required
                    />
                </div>
                <div>
                    <label htmlFor="event-desc" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Description</label>
                    <textarea
                        id="event-desc" value={description} onChange={e => setDescription(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        placeholder="(Optional) e.g., Chapters 4-7" rows={2}
                    />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="event-date" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Date</label>
                        <input
                            type="date" id="event-date" value={date} onChange={e => setDate(e.target.value)}
                            className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand" required
                        />
                    </div>
                     <div>
                        <label htmlFor="event-time" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Time</label>
                        <input
                            type="time" id="event-time" value={time} onChange={e => setTime(e.target.value)}
                            className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        />
                    </div>
                </div>
                 <div>
                    <label htmlFor="event-location" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Location</label>
                    <input
                        type="text" id="event-location" value={location} onChange={e => setLocation(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        placeholder="(Optional) e.g., Library Room 3B"
                    />
                </div>
                 <div>
                    <label htmlFor="event-course" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Associate with Course</label>
                    <select
                        id="event-course" value={courseId} onChange={e => setCourseId(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                    >
                        <option value="">No Associated Course</option>
                        {courses.map(course => (
                            <option key={course.id} value={course.id}>{course.title}</option>
                        ))}
                    </select>
                </div>
                <div className="flex justify-end pt-4">
                    <button type="submit" className="bg-brand-gradient text-white px-6 py-2 rounded-lg font-semibold">
                        {event ? 'Save Changes' : 'Add Event'}
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default EventModal;