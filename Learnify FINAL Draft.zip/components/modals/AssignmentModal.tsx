import React, { useState, useEffect } from 'react';
import { Assignment } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';
import Modal from './Modal';

interface AssignmentModalProps {
    isOpen: boolean;
    onClose: () => void;
    assignment?: Assignment;
    courseId?: string; // Pre-select course if adding from course view
}

const AssignmentModal: React.FC<AssignmentModalProps> = ({ isOpen, onClose, assignment, courseId: preselectedCourseId }) => {
    const { courses, addAssignment, updateAssignment } = useAppContext();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [courseId, setCourseId] = useState(preselectedCourseId || '');
    const [dueDate, setDueDate] = useState('');

    useEffect(() => {
        if (isOpen) {
            if (assignment) {
                setTitle(assignment.title);
                setDescription(assignment.description);
                setCourseId(assignment.courseId);
                setDueDate(assignment.dueDate || '');
            } else {
                setTitle('');
                setDescription('');
                setCourseId(preselectedCourseId || (courses.length > 0 ? courses[0].id : ''));
                setDueDate('');
            }
        }
    }, [assignment, isOpen, preselectedCourseId, courses]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim() || !courseId) return;

        const assignmentData = {
            title,
            description,
            courseId,
            dueDate: dueDate || null,
        };

        if (assignment) {
            updateAssignment(assignment.id, assignmentData);
        } else {
            addAssignment(assignmentData);
        }
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={assignment ? 'Edit Assignment' : 'Create New Assignment'}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="assign-title" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Title</label>
                    <input
                        type="text" id="assign-title" value={title} onChange={e => setTitle(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        placeholder="e.g., Research Paper on Black Holes" required
                    />
                </div>
                <div>
                    <label htmlFor="assign-course" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Course</label>
                    <select
                        id="assign-course" value={courseId} onChange={e => setCourseId(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand" required
                    >
                        <option value="" disabled>Select a course...</option>
                        {courses.map(course => (
                            <option key={course.id} value={course.id}>{course.title}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label htmlFor="assign-desc" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Description (Optional)</label>
                    <textarea
                        id="assign-desc" value={description} onChange={e => setDescription(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        rows={2}
                    />
                </div>
                 <div>
                    <label htmlFor="assign-due" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Due Date (Optional)</label>
                    <input
                        type="date" id="assign-due" value={dueDate} onChange={e => setDueDate(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                    />
                </div>
                <div className="flex justify-end pt-4">
                    <button type="submit" className="bg-brand-gradient text-white px-6 py-2 rounded-lg font-semibold">
                        {assignment ? 'Save Changes' : 'Create Assignment'}
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default AssignmentModal;