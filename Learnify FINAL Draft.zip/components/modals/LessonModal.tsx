import React, { useState, useEffect } from 'react';
import { Lesson } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';
import Modal from './Modal';

interface LessonModalProps {
    isOpen: boolean;
    onClose: () => void;
    courseId: string;
    lesson?: Lesson;
}

const LessonModal: React.FC<LessonModalProps> = ({ isOpen, onClose, courseId, lesson }) => {
    const { addLesson, updateLesson } = useAppContext();
    const [title, setTitle] = useState('');

    useEffect(() => {
        if (lesson) {
            setTitle(lesson.title);
        } else {
            setTitle('');
        }
    }, [lesson, isOpen]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim()) return;

        if (lesson) {
            updateLesson(courseId, lesson.id, { title });
        } else {
            addLesson(courseId, { title });
        }
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={lesson ? 'Edit Lesson' : 'Create New Lesson'}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="lesson-title" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Lesson Title</label>
                    <input
                        type="text"
                        id="lesson-title"
                        value={title}
                        onChange={e => setTitle(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        placeholder="e.g., The Big Bang Theory"
                        required
                    />
                </div>
                <div className="flex justify-end pt-4">
                    <button type="submit" className="bg-brand-gradient text-white px-6 py-2 rounded-lg font-semibold">
                        {lesson ? 'Save Changes' : 'Create Lesson'}
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default LessonModal;