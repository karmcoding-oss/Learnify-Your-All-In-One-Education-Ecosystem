import React, { useState, useEffect } from 'react';
import { Course, Lesson, View } from '../types';
import AITutor from './AITutor';
import Flashcards from './Flashcards';
import PracticeTest from './PracticeTest';
import LessonResources from './LessonResources';
import { HiSparkles as SparklesIcon, HiPencil as PencilIcon, HiTrash as TrashIcon } from 'react-icons/hi2';
import { useAppContext } from '../hooks/useAppContext';
import LessonModal from './modals/LessonModal';

type Tab = 'lesson' | 'tutor' | 'flashcards' | 'test';

const LessonView: React.FC<{ course: Course, lesson: Lesson }> = ({ course, lesson }) => {
    const [activeTab, setActiveTab] = useState<Tab>('lesson');
    const { deleteLesson } = useAppContext();
    const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    const handleDeleteLesson = () => {
        if (window.confirm(`Are you sure you want to delete the lesson "${lesson.title}"?`)) {
            setIsDeleting(true);
        }
    };
    
    useEffect(() => {
        if (isDeleting) {
            const timer = setTimeout(() => {
                deleteLesson(course.id, lesson.id);
            }, 300); // Animation duration
            return () => clearTimeout(timer);
        }
    }, [isDeleting, course.id, lesson.id, deleteLesson]);

    const renderTabContent = () => {
        switch (activeTab) {
            case 'tutor':
                return <AITutor lesson={lesson} />;
            case 'flashcards':
                return <Flashcards course={course} lesson={lesson} />;
            case 'test':
                return <PracticeTest course={course} lesson={lesson} />;
            case 'lesson':
            default:
                return <LessonResources course={course} lesson={lesson} />;
        }
    };
    
    const TabButton: React.FC<{ tabId: Tab, label: string, icon?: React.ReactNode }> = ({ tabId, label, icon }) => {
        const isActive = activeTab === tabId;
        return (
            <button
                onClick={() => setActiveTab(tabId)}
                className={`flex items-center justify-center sm:justify-start space-x-2 px-3 py-2 text-sm sm:text-base font-medium rounded-md transition-all duration-200 ${
                    isActive
                        ? 'bg-brand-gradient text-white shadow-md'
                        : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
            >
                {icon}
                <span className="hidden sm:inline">{label}</span>
            </button>
        );
    }

    return (
        <div className={`animate-slide-in ${isDeleting ? 'animate-modal-out' : ''}`}>
            <div className="flex justify-between items-start mb-4">
                <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">{lesson.title}</h2>
                 <div className="flex space-x-2">
                    <button onClick={() => setIsLessonModalOpen(true)} className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"><PencilIcon className="w-5 h-5"/></button>
                    <button onClick={handleDeleteLesson} className="p-2 rounded-full text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50"><TrashIcon className="w-5 h-5"/></button>
                </div>
            </div>
            
            <div className="flex flex-col lg:flex-row gap-6">
                <div className="lg:w-1/4">
                     <div className="sticky top-20">
                        <div className="flex flex-row sm:flex-wrap lg:flex-col gap-2 p-2 bg-slate-100/50 dark:bg-slate-800/50 rounded-lg">
                           <TabButton tabId="lesson" label="Lesson Resources" />
                           <TabButton tabId="tutor" label="AI Tutor" icon={<SparklesIcon className="w-5 h-5"/>} />
                           <TabButton tabId="flashcards" label="Flashcards" icon={<SparklesIcon className="w-5 h-5"/>} />
                           <TabButton tabId="test" label="Practice Test" icon={<SparklesIcon className="w-5 h-5"/>} />
                        </div>
                    </div>
                </div>

                <div className="lg:w-3/4 liquid-glass p-6 rounded-2xl min-h-[60vh]">
                    {renderTabContent()}
                </div>
            </div>
             <LessonModal isOpen={isLessonModalOpen} onClose={() => setIsLessonModalOpen(false)} courseId={course.id} lesson={lesson} />
        </div>
    );
};

export default LessonView;