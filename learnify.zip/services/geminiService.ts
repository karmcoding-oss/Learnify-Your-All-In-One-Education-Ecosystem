import { GoogleGenAI, GenerateContentResponse, Type, Content } from "@google/genai";
import { Flashcard, PracticeQuestion, ResearchDocument, QuestionType, Difficulty } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// --- AI TUTOR CHAT ---
export const sendMessageToTutor = async (
  message: string,
  history: Content[],
  lessonContent: string,
  filters: { recency?: string; credibility?: string; sourceType?: string }
): Promise<GenerateContentResponse> => {
    try {
        const model = 'gemini-2.5-flash';

        let filterInstructions = '';
        if (filters.recency && filters.recency !== 'any') {
            filterInstructions += ` Please prioritize information from the ${filters.recency}.`;
        }
        if (filters.credibility && filters.credibility !== 'any') {
            filterInstructions += ` Please prioritize sources with ${filters.credibility} credibility, such as academic journals, reputable news organizations, or educational institutions.`;
        }
        if (filters.sourceType && filters.sourceType !== 'any') {
             filterInstructions += ` Please prioritize sources that are of the type '${filters.sourceType}'.`;
        }

        const systemInstruction = `You are a helpful and encouraging AI Tutor. Your goal is to help a student understand a specific lesson. 
        The lesson content is: "${lessonContent}". 
        Base your answers on this content. If a question goes beyond the scope of the lesson content, use your web search tool to find the most accurate and up-to-date information. 
        ${filterInstructions}
        When you use web search, you MUST provide the source URLs from your search results.`;
        
        const contents = [...history, { role: 'user', parts: [{ text: message }] }];

        const response = await ai.models.generateContent({
            model,
            contents,
            config: {
                systemInstruction,
                tools: [{ googleSearch: {} }],
            },
        });
        return response;
    } catch (error) {
        console.error("Error sending message to tutor:", error);
        throw new Error("Sorry, I'm having trouble connecting to the AI Tutor. Please check your connection and try again.");
    }
};

// --- DASHBOARD RESEARCH ---
// Fix: Added missing getResearch function to fix import error in DashboardResearch.tsx.
export const getResearch = async (topic: string): Promise<GenerateContentResponse> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Provide a concise, up-to-date summary on the topic: "${topic}".`,
            config: {
                tools: [{ googleSearch: {} }],
            },
        });
        return response;
    } catch (error) {
        console.error("Error fetching research:", error);
        throw new Error("Failed to generate research. The topic may be too broad or there was a connection issue.");
    }
};

// --- DEEP RESEARCH ---
export const generateResearchDocument = async (topic: string): Promise<ResearchDocument> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Generate a comprehensive research document on the topic: "${topic}".
Use your web search tool to find trustworthy, up-to-date information.

IMPORTANT: Your entire response MUST be a single, valid JSON object that adheres to the following structure. Do not include any text, markdown formatting, or "\`\`\`json" markers before or after the JSON object.

The JSON object should have these keys:
- "title": A string for the document title.
- "summary": A string containing a brief summary of the topic.
- "sections": An array of objects, where each object has:
    - "heading": A string for the section heading.
    - "content": A string for the detailed content of the section.
- "sources": An array of objects based on your search results. For each source, include:
    - "uri": The string URI of the source.
    - "title": The string title of the source.
    - "credibility": An estimated credibility score from 1 to 100 (as a number), based on your assessment of the source's authority and reliability.`,
            config: {
                tools: [{ googleSearch: {} }],
            },
        });
        
        let jsonStr = response.text.trim();
        // Defensively remove markdown code block fences if the model includes them
        if (jsonStr.startsWith('```json')) {
            jsonStr = jsonStr.substring(7, jsonStr.length - 3).trim();
        }
        
        const document: ResearchDocument = JSON.parse(jsonStr);
        return document;

    } catch (error) {
        console.error("Error fetching research document:", error);
        throw new Error("Failed to generate research document. The topic may be too complex or there was a connection issue.");
    }
};

// --- NOTE GENERATION ---
export const generateNotesFromContent = async (lessonContent: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Based on the following lesson content, summarize and organize it into a structured set of study notes.
            Use markdown for formatting, including headings, bold text for key terms, and bullet points for lists.
            The notes should be clear, concise, and optimized for learning.

            Lesson Content: "${lessonContent}"`,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating notes:", error);
        throw new Error("Sorry, I'm having trouble generating notes right now. Please check the lesson content and try again.");
    }
};


// --- FLASHCARD GENERATION ---
export const generateFlashcards = async (lessonContent: string): Promise<Flashcard[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Based on the following lesson content, generate 5-10 key flashcards. Each flashcard should have a 'question' and a concise 'answer'.
            Lesson Content: "${lessonContent}"`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            question: { type: Type.STRING },
                            answer: { type: Type.STRING },
                        },
                        required: ["question", "answer"],
                    },
                },
            },
        });

        const jsonStr = response.text.trim();
        const flashcards: Flashcard[] = JSON.parse(jsonStr);
        return flashcards;
    } catch (error) {
        console.error("Error generating flashcards:", error);
        throw error;
    }
};

// --- PRACTICE TEST GENERATION ---
export interface PracticeTestSettings {
    count: number;
    types: QuestionType[];
    difficulty: Difficulty;
}

export const generatePracticeTest = async (lessonContent: string, settings: PracticeTestSettings): Promise<PracticeQuestion[]> => {
    try {
        const typeInstructions = settings.types.join(', ');
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Based on the following lesson content, generate a ${settings.count}-question practice test with a difficulty level of '${settings.difficulty}'.
            The test should include a mix of the following question types: ${typeInstructions}.
            The response must be a JSON array of question objects adhering to the provided schema. Each object must have a "type", "question", and "correctAnswer" property.
            - For "multiple-choice" questions, also include an "options" array of 4 strings.
            - For "true-false" questions, "correctAnswer" must be the string "true" or "false".
            - For "fill-in-the-blank" questions, the "question" text must include "___" as a placeholder.
            Lesson Content: "${lessonContent}"`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            type: { 
                                type: Type.STRING,
                                enum: ['multiple-choice', 'true-false', 'fill-in-the-blank'],
                                description: 'The type of question.'
                            },
                            question: { 
                                type: Type.STRING,
                                description: 'The question text. For fill-in-the-blank, use ___ for the blank.'
                            },
                            options: {
                                type: Type.ARRAY,
                                items: { type: Type.STRING },
                                description: 'An array of 4 options for multiple-choice questions.'
                            },
                            correctAnswer: { 
                                type: Type.STRING,
                                description: 'The correct answer. For true/false, should be "true" or "false".'
                            },
                        },
                        required: ["type", "question", "correctAnswer"],
                    },
                },
            },
        });
        const jsonStr = response.text.trim();
        const rawQuestions = JSON.parse(jsonStr);

        // Process and validate the questions from the API
        const questions: PracticeQuestion[] = rawQuestions.map((q: any) => {
            switch (q.type) {
                case 'multiple-choice':
                    if (!q.options || q.options.length < 2) return null;
                    return { ...q, options: q.options.slice(0, 4) };
                case 'true-false':
                    return { ...q, correctAnswer: q.correctAnswer.toLowerCase() === 'true' };
                case 'fill-in-the-blank':
                    if (!q.question.includes('___')) return null;
                    return q;
                default:
                    return null;
            }
        }).filter(Boolean);

        return questions;

    } catch (error) {
        console.error("Error generating practice test:", error);
        throw error;
    }
};

export const getAnswerExplanation = async (question: PracticeQuestion, userAnswer: any): Promise<string> => {
     try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `A student was asked the following question:
            "${question.question}"

            The correct answer is: "${question.correctAnswer}"
            The student answered: "${userAnswer}"

            Please provide a brief, helpful explanation (2-3 sentences) for why the student's answer is incorrect and why the correct answer is right. 
            If the student's answer was correct, just briefly explain the concept.
            Address the student directly (e.g., "Your answer was close, but...").`,
        });
        return response.text;
    } catch (error) {
        console.error("Error getting explanation:", error);
        throw new Error("Could not get an explanation at this time.");
    }
}


// --- ASSIGNMENT AI ASSISTANT ---
export const getAIAssistanceForAssignment = async (prompt: string, context: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `You are an AI writing assistant helping a student with their assignment.
            Current assignment content: "${context}"
            
            The student's request is: "${prompt}"

            Provide a helpful response based on the request. For example, if they ask for ideas, provide a bulleted list. If they ask to summarize, provide a concise summary. If they ask to edit, provide the edited text with changes highlighted or explained.`,
        });
        return response.text;
    } catch (error) {
        console.error("Error getting AI assistance:", error);
        throw new Error("Sorry, the AI assistant is unavailable right now.");
    }
};


// --- MENTAL HEALTH RESOURCES ---
export const getMentalHealthResources = async (feeling: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `You are a caring and supportive mental health assistant. Your role is to provide helpful, general resources. You are NOT a medical professional.
            Based on the user's statement about how they are feeling: "${feeling}", provide a list of 3-5 helpful resources.

            **IMPORTANT:** Your response MUST begin with this exact disclaimer in bold markdown: **"The following are general suggestions and not a substitute for professional medical advice. If you are in crisis, please contact a local emergency service or a mental health hotline."**

            After the disclaimer, list the resources. For each resource, use markdown to format it with:
            - A title in bold (e.g., **"Try a Grounding Exercise"**).
            - A short, helpful description.

            Do not add any conversational text before the disclaimer or after the list of resources.`,
        });
        return response.text;
    } catch (error) {
        console.error("Error fetching mental health resources:", error);
        throw new Error("Sorry, I'm having trouble finding resources right now. Please check your connection and try again.");
    }
};