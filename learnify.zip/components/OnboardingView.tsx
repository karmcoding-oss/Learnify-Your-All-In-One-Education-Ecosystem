import React, { useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { HiSparkles as SparklesIcon } from 'react-icons/hi2';

const OnboardingView: React.FC = () => {
    const { completeOnboarding, userData } = useAppContext();
    
    const [name, setName] = useState(userData.name || '');
    const [username, setUsername] = useState('');
    const [age, setAge] = useState('');
    const [schoolingLevel, setSchoolingLevel] = useState('');
    const [interests, setInterests] = useState('');
    const [error, setError] = useState('');
    const [usernameError, setUsernameError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setUsernameError('');

        const ageNum = parseInt(age, 10);
        const usernameRegex = /^[a-zA-Z0-9_]{3,15}$/;

        if (!name.trim() || !age.trim() || !schoolingLevel || !username.trim()) {
            setError('Please fill out all required fields.');
            return;
        }
        if (isNaN(ageNum) || ageNum <= 5 || ageNum > 100) {
            setError('Please enter a valid age.');
            return;
        }
        if (!usernameRegex.test(username)) {
            setUsernameError('Username must be 3-15 characters and can only contain letters, numbers, and underscores.');
            return;
        }

        const success = await completeOnboarding({ name, age: ageNum, schoolingLevel, interests, username });
        if (!success) {
            setUsernameError('This username is already taken. Please choose another one.');
        }
    };
    
    const schoolingOptions = [
        "Middle School",
        "High School",
        "Undergraduate",
        "Graduate",
        "Post-graduate",
        "Professional",
        "Self-taught",
    ];

    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4 animate-slide-in">
            <div className="text-center mb-8">
                <h1 className="text-4xl font-bold text-white drop-shadow-md">Welcome to Learnify!</h1>
                <p className="text-white/80 mt-2 drop-shadow-sm">Let's set up your profile to personalize your experience.</p>
            </div>

            <div className="w-full max-w-lg liquid-glass rounded-2xl p-8">
                <form onSubmit={handleSubmit} className="space-y-4">
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Display Name</label>
                            <input
                                type="text" id="name" value={name} onChange={e => setName(e.target.value)}
                                className="w-full p-3 border rounded-md bg-white/70 dark:bg-slate-900/70 border-slate-300 dark:border-slate-600 focus:ring-brand focus:border-brand"
                                placeholder="Your Name" required
                            />
                        </div>
                        <div>
                            <label htmlFor="username" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Username</label>
                            <input
                                type="text" id="username" value={username} onChange={e => setUsername(e.target.value)}
                                className={`w-full p-3 border rounded-md bg-white/70 dark:bg-slate-900/70 border-slate-300 dark:border-slate-600 focus:ring-brand focus:border-brand ${usernameError ? 'border-red-500' : ''}`}
                                placeholder="your_username" required
                            />
                             {usernameError && <p className="text-red-500 text-xs mt-1">{usernameError}</p>}
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <div>
                            <label htmlFor="age" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Age</label>
                            <input
                                type="number" id="age" value={age} onChange={e => setAge(e.target.value)}
                                className="w-full p-3 border rounded-md bg-white/70 dark:bg-slate-900/70 border-slate-300 dark:border-slate-600 focus:ring-brand focus:border-brand"
                                placeholder="e.g., 18" required
                            />
                        </div>
                        <div>
                            <label htmlFor="schoolingLevel" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Schooling Level</label>
                            <select
                                id="schoolingLevel" value={schoolingLevel} onChange={e => setSchoolingLevel(e.target.value)}
                                className="w-full p-3 border rounded-md bg-white/70 dark:bg-slate-900/70 border-slate-300 dark:border-slate-600 focus:ring-brand focus:border-brand" required
                            >
                                <option value="" disabled>Select a level...</option>
                                {schoolingOptions.map(option => (
                                    <option key={option} value={option}>{option}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="interests" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                            Your Interests <span className="text-xs text-slate-400">(Optional)</span>
                        </label>
                        <textarea
                            id="interests" value={interests} onChange={e => setInterests(e.target.value)}
                            className="w-full p-3 border rounded-md bg-white/70 dark:bg-slate-900/70 border-slate-300 dark:border-slate-600 focus:ring-brand focus:border-brand"
                            placeholder="e.g., Space, AI, History, Music..." rows={3}
                        />
                         <p className="text-xs text-slate-400 mt-1">Separate interests with a comma.</p>
                    </div>

                    {error && <p className="text-red-500 text-sm text-center">{error}</p>}

                    <button type="submit" className="w-full bg-brand-gradient text-white py-3 mt-4 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2">
                        <span>Let's Go!</span>
                        <SparklesIcon className="w-5 h-5"/>
                    </button>
                </form>
            </div>
        </div>
    );
};

export default OnboardingView;