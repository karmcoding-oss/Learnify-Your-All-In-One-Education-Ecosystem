import React, { useState } from 'react';
import MoodTracker from './mental_health/MoodTracker';
import BreathingExercise from './mental_health/BreathingExercise';
import WellbeingActivities from './mental_health/WellbeingActivities';
import ExtraResources from './mental_health/ExtraResources';
import { HiHeart as HeartIcon, HiChartBar as ChartBarIcon, HiSparkles as SparklesIcon, HiLifebuoy as LifebuoyIcon } from 'react-icons/hi2';

type Tab = 'dashboard' | 'mood' | 'breathing' | 'activities' | 'resources';

const MentalHealthView: React.FC = () => {
    const [activeTab, setActiveTab] = useState<Tab>('dashboard');

    const renderContent = () => {
        switch (activeTab) {
            case 'mood':
                return <MoodTracker />;
            case 'breathing':
                return <BreathingExercise />;
            case 'activities':
                return <WellbeingActivities />;
            case 'resources':
                return <ExtraResources />;
            case 'dashboard':
            default:
                return <MoodTracker isDashboard={true} />;
        }
    };
    
    const TabButton: React.FC<{tabId: Tab, label: string, icon: React.ReactNode}> = ({ tabId, label, icon }) => (
         <button
            onClick={() => setActiveTab(tabId)}
            className={`flex-1 flex flex-col sm:flex-row items-center justify-center space-x-0 sm:space-x-2 p-3 text-sm font-medium rounded-lg transition-colors duration-200 ${
                activeTab === tabId
                    ? 'bg-brand-gradient text-white shadow-md'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
            }`}
        >
            {icon}
            <span>{label}</span>
        </button>
    );

    return (
        <div className="animate-slide-in space-y-8">
            <div>
                <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center">
                    <HeartIcon className="w-8 h-8 mr-3 text-pink-500" />
                    Mental Wellbeing Hub
                </h2>
                <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">
                    Take a moment to check in with yourself. Your mental health is a priority.
                </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 p-2 bg-slate-100/50 dark:bg-slate-800/50 rounded-lg">
                <TabButton tabId="dashboard" label="Dashboard" icon={<ChartBarIcon className="w-5 h-5 mb-1 sm:mb-0"/>} />
                <TabButton tabId="mood" label="Mood Logger" icon={<HeartIcon className="w-5 h-5 mb-1 sm:mb-0"/>} />
                <TabButton tabId="breathing" label="Breathing" icon={<SparklesIcon className="w-5 h-5 mb-1 sm:mb-0"/>} />
                <TabButton tabId="activities" label="Activities" icon={<SparklesIcon className="w-5 h-5 mb-1 sm:mb-0"/>} />
                <TabButton tabId="resources" label="Extra Resources" icon={<LifebuoyIcon className="w-5 h-5 mb-1 sm:mb-0"/>} />
            </div>

            <div className="liquid-glass p-4 sm:p-6 rounded-2xl min-h-[50vh]">
                {renderContent()}
            </div>
        </div>
    );
};

export default MentalHealthView;