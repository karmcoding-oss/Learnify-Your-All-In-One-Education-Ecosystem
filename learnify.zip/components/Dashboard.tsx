import React, { useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import CourseMastery from './dashboard/CourseMastery';
import MentalHealth from './dashboard/MentalHealth';
import Achievements from './dashboard/Achievements';
import CourseModal from './modals/CourseModal';
import { HiPlus as PlusIcon } from 'react-icons/hi2';
import NotificationsPanel from './dashboard/NotificationsPanel';
import MiniCalendar from './dashboard/MiniCalendar';
import AssignmentsWidget from './dashboard/AssignmentsWidget';
import WelcomeWidget from './dashboard/WelcomeWidget';

const Dashboard: React.FC = () => {
    const { userData, courses } = useAppContext();
    const [isModalOpen, setIsModalOpen] = useState(false);

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center gap-4">
                <div className="flex-grow">
                    <WelcomeWidget />
                </div>
                {courses.length > 0 && (
                     <button
                        onClick={() => setIsModalOpen(true)}
                        className="flex-shrink-0 self-center flex items-center space-x-2 bg-brand-gradient px-4 py-2 rounded-lg font-semibold shadow-lg btn-animated"
                    >
                        <PlusIcon className="w-5 h-5" />
                        <span className="hidden sm:inline">Create Course</span>
                    </button>
                )}
            </div>
            
            <NotificationsPanel />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left column */}
                <div className="lg:col-span-2 space-y-6">
                    {courses.length > 0 ? (
                        <div className="animate-slide-in-up" style={{ animationDelay: '100ms' }}>
                            <CourseMastery />
                        </div>
                    ) : (
                        <div className="text-center py-16 sm:py-24 px-6 rounded-2xl animate-slide-in-up liquid-glass flex flex-col items-center">
                            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">Your Dashboard is Ready!</h2>
                            <p className="mt-4 max-w-xl text-md sm:text-lg text-slate-600 dark:text-slate-400">
                                Create your first course to add lessons, generate flashcards, and track your mastery.
                            </p>
                            <button
                                onClick={() => setIsModalOpen(true)}
                                className="mt-8 flex items-center space-x-2 bg-brand-gradient px-6 py-3 rounded-lg font-semibold shadow-lg btn-animated"
                            >
                                <PlusIcon className="w-5 h-5" />
                                <span>Create First Course</span>
                            </button>
                        </div>
                    )}

                    <div className="w-full h-[1px] bg-gradient-to-r from-transparent via-slate-300 dark:via-slate-700 to-transparent"></div>
                    
                    <div className="animate-slide-in-up" style={{ animationDelay: '150ms' }}>
                        <AssignmentsWidget />
                    </div>

                </div>

                {/* Right column */}
                <div className="space-y-6">
                    <div className="animate-slide-in-up" style={{ animationDelay: '200ms' }}><Achievements /></div>
                    <div className="animate-slide-in-up" style={{ animationDelay: '300ms' }}><MiniCalendar /></div>
                    <div className="animate-slide-in-up" style={{ animationDelay: '400ms' }}><MentalHealth /></div>
                </div>
            </div>

            <CourseModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
        </div>
    );
};

export default Dashboard;