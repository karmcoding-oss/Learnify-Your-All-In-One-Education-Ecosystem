import React, { useState } from 'react';
import { generateResearchDocument } from '../services/geminiService';
import { HiSparkles as SparklesIcon, HiClipboard as ClipboardIcon } from 'react-icons/hi2';
import { useAppContext } from '../hooks/useAppContext';
import { ResearchDocument, ResearchSource } from '../types';

const SkeletonLoader: React.FC = () => (
    <div className="space-y-6 animate-pulse">
        <div className="h-8 bg-slate-200 dark:bg-slate-700 rounded-md w-3/4"></div>
        <div className="space-y-2">
            <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-md"></div>
            <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-md w-5/6"></div>
        </div>
        <div className="space-y-4">
            <div className="h-6 bg-slate-200 dark:bg-slate-700 rounded-md w-1/2"></div>
            <div className="space-y-2">
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-md"></div>
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-md"></div>
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-md w-4/5"></div>
            </div>
        </div>
        <div className="space-y-4">
            <div className="h-6 bg-slate-200 dark:bg-slate-700 rounded-md w-1/3"></div>
            <div className="space-y-2">
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-md"></div>
                <div className="h-4 bg-slate-200 dark:bg-slate-700 rounded-md w-2/3"></div>
            </div>
        </div>
    </div>
);

const CredibilityScore: React.FC<{ score: number }> = ({ score }) => {
    const getColor = () => {
        if (score > 80) return 'text-green-500';
        if (score > 60) return 'text-yellow-500';
        return 'text-red-500';
    };
    return (
        <div className={`flex items-center space-x-2 text-sm font-semibold ${getColor()}`}>
            <span>{score}/100</span>
        </div>
    );
};

const DeepResearch: React.FC = () => {
    const [topic, setTopic] = useState('');
    const [result, setResult] = useState<ResearchDocument | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [copySuccess, setCopySuccess] = useState('');
    const { unlockAchievement } = useAppContext();

    const handleResearch = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!topic.trim() || isLoading) return;

        setIsLoading(true);
        setError(null);
        setResult(null);

        try {
            const response = await generateResearchDocument(topic);
            setResult(response);
            unlockAchievement('deep-diver');
        } catch (err: any) {
            setError(err.message || "Failed to fetch research. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleCopyToClipboard = () => {
        if (!result) return;
        let textToCopy = `Title: ${result.title}\n\nSummary: ${result.summary}\n\n`;
        result.sections.forEach(section => {
            textToCopy += `## ${section.heading}\n${section.content}\n\n`;
        });
        textToCopy += `Sources:\n`;
        result.sources.forEach(source => {
            textToCopy += `- ${source.title}: ${source.uri} (Credibility: ${source.credibility}/100)\n`;
        });
        
        navigator.clipboard.writeText(textToCopy);
        setCopySuccess('Copied to clipboard!');
        setTimeout(() => setCopySuccess(''), 2000);
    };

    return (
        <div className="animate-slide-in">
            <h3 className="text-xl font-bold mb-4 flex items-center">
                <SparklesIcon className="w-6 h-6 mr-2 text-brand" /> AI Research Assistant
            </h3>
            <p className="text-slate-500 dark:text-slate-400 mb-4">
                Get a comprehensive, structured research document on any topic, complete with sources and credibility scores.
            </p>
            <form onSubmit={handleResearch} className="flex mb-6">
                <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Enter a research topic..."
                    className="flex-1 p-2 border rounded-l-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                    disabled={isLoading}
                />
                <button type="submit" disabled={isLoading} className="bg-brand-gradient text-white px-4 rounded-r-md disabled:opacity-50">
                    {isLoading ? 'Researching...' : 'Research'}
                </button>
            </form>

            {isLoading && <SkeletonLoader />}
            {error && <p className="text-red-500">{error}</p>}
            
            {result && (
                <div className="animate-slide-in-up">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">{result.title}</h2>
                         <button onClick={handleCopyToClipboard} className="flex items-center space-x-2 text-sm font-medium text-slate-500 hover:text-brand dark:text-slate-400 dark:hover:text-brand">
                            <ClipboardIcon className="w-5 h-5" />
                            <span>{copySuccess || 'Copy'}</span>
                        </button>
                    </div>

                    <div className="mb-6 p-4 bg-slate-50 dark:bg-slate-900/50 rounded-lg">
                        <h3 className="text-lg font-bold mb-2">Summary</h3>
                        <p className="text-slate-600 dark:text-slate-300">{result.summary}</p>
                    </div>

                    <div className="space-y-6">
                        {result.sections.map((section, index) => (
                            <div key={index}>
                                <h3 className="text-xl font-bold mb-2 border-b-2 border-brand pb-1">{section.heading}</h3>
                                <p className="text-slate-700 dark:text-slate-200 whitespace-pre-wrap">{section.content}</p>
                            </div>
                        ))}
                    </div>

                    <div className="mt-8">
                        <h3 className="text-xl font-bold mb-4">Sources</h3>
                        <ul className="space-y-3">
                            {result.sources.map((source, index) => (
                                <li key={index} className="flex flex-col sm:flex-row justify-between sm:items-center p-3 bg-slate-50 dark:bg-slate-900/50 rounded-lg">
                                    <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-brand hover:underline font-medium break-all">
                                        {source.title}
                                    </a>
                                    <div className="mt-2 sm:mt-0">
                                        <CredibilityScore score={source.credibility || 0} />
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DeepResearch;
