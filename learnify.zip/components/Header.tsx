import React, { useState, useEffect } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { View } from '../types';
import { HiSun as SunIcon, HiMoon as MoonIcon, HiFire as FireIcon, HiBell as BellIcon, HiBars3 as Bars3Icon } from 'react-icons/hi2';
import XPBar from './XPBar';

const Header: React.FC = () => {
    const { userData, isDarkMode, setIsDarkMode, toggleSidebar, navigate, isNotificationPanelOpen, toggleNotificationPanel } = useAppContext();
    const [animateStreak, setAnimateStreak] = useState(false);
    
    const unreadNotifications = userData.notifications.filter(n => !n.isRead).length;

    useEffect(() => {
        if (userData.streak > 0) {
            setAnimateStreak(true);
            const timer = setTimeout(() => setAnimateStreak(false), 500); // Duration of animation
            return () => clearTimeout(timer);
        }
    }, [userData.streak]);

    const toggleTheme = () => {
        setIsDarkMode(!isDarkMode);
    };

    return (
        <header className="liquid-glass !rounded-none sticky top-0 z-30 shadow-lg">
            <div className="mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center">
                       <button
                            onClick={toggleSidebar}
                            className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-100/10 dark:hover:bg-slate-800/50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 dark:focus:ring-offset-slate-900 transition-transform hover:scale-110"
                            aria-label="Toggle sidebar"
                        >
                            <Bars3Icon className="w-6 h-6" />
                        </button>
                    </div>
                    <div className="flex-grow flex justify-center px-2">
                        <div className="hidden sm:flex items-center">
                            <XPBar />
                        </div>
                    </div>
                    <div className="flex items-center space-x-2 sm:space-x-4">
                         <div className="flex items-center space-x-1 text-orange-500">
                            <FireIcon className="w-6 h-6" />
                            <span className={`font-bold text-lg ${animateStreak ? 'animate-streak-pop' : ''}`}>{userData.streak}</span>
                         </div>
                         <button 
                            onClick={toggleNotificationPanel}
                            className={`relative p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-100/10 dark:hover:bg-slate-800/50 transition-transform hover:scale-110 ${isNotificationPanelOpen ? 'bg-brand-subtle' : ''}`}
                            aria-label="Toggle notifications"
                         >
                            <BellIcon className="w-5 h-5"/>
                            {unreadNotifications > 0 && (
                                <span className="absolute top-1 right-1 flex h-3 w-3">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                    <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                                </span>
                            )}
                         </button>
                        <button
                            onClick={toggleTheme}
                            className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-100/10 dark:hover:bg-slate-800/50 transition-transform hover:scale-110"
                            aria-label="Toggle theme"
                        >
                            {isDarkMode ? <SunIcon className="w-5 h-5 text-yellow-400" /> : <MoonIcon className="w-5 h-5 text-slate-700" />}
                        </button>
                         <button onClick={() => navigate(View.PROFILE)} className="flex items-center space-x-2 p-1 rounded-lg hover:bg-slate-100/10 dark:hover:bg-slate-800/50 transition-transform hover:scale-105">
                             <div className="w-8 h-8 rounded-full bg-brand-gradient flex items-center justify-center font-bold text-white text-sm">
                                {userData.name.charAt(0).toUpperCase()}
                            </div>
                            <span className="hidden md:inline text-sm font-semibold">{userData.name}</span>
                        </button>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;