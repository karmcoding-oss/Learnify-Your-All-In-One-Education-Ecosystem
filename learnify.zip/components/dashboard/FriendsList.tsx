import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { HiChatBubbleLeftRight as ChatBubbleLeftRightIcon } from 'react-icons/hi2';

interface FriendsListProps {
    onStartChat: (friendEmail: string) => void;
}

const FriendsList: React.FC<FriendsListProps> = ({ onStartChat }) => {
    const { userData, allUsersData } = useAppContext();
    const friends = userData.friends.map(email => allUsersData[email]).filter(Boolean);

    if (friends.length === 0) {
        return <p className="text-sm text-center text-slate-500 dark:text-slate-400 py-8">Find and connect with peers in the "Suggestions" tab!</p>;
    }

    return (
        <ul className="space-y-3 max-h-64 overflow-y-auto pr-2">
            {friends.map((friend, index) => (
                <li key={friend.email} className="flex items-center justify-between p-2 rounded-lg animate-slide-in-up" style={{ animationDelay: `${index * 80}ms` }}>
                    <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-brand-gradient flex items-center justify-center">
                            <span className="font-bold text-white">{friend.userData.name.charAt(0).toUpperCase()}</span>
                        </div>
                        <div>
                            <p className="font-semibold text-slate-800 dark:text-slate-100">{friend.userData.name}</p>
                            <p className="text-xs text-slate-500 dark:text-slate-400">@{friend.userData.username}</p>
                        </div>
                    </div>
                    <button 
                        onClick={() => onStartChat(friend.email)}
                        className="p-2 rounded-full text-brand hover:bg-brand-subtle transition-transform hover:scale-110"
                        aria-label={`Chat with ${friend.userData.name}`}
                    >
                       <ChatBubbleLeftRightIcon className="w-5 h-5"/>
                    </button>
                </li>
            ))}
        </ul>
    );
};

export default FriendsList;