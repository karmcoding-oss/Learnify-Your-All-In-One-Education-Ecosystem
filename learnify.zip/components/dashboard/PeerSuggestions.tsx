import React, { useState, useMemo } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { HiUserPlus as UserPlusIcon } from 'react-icons/hi2';

const PeerSuggestions: React.FC = () => {
    const { getPeerSuggestions, sendFriendRequest, userData } = useAppContext();
    const [sentRequests, setSentRequests] = useState<string[]>([]);
    
    const suggestions = useMemo(getPeerSuggestions, [getPeerSuggestions]);

    const handleSendRequest = (recipientEmail: string) => {
        sendFriendRequest(recipientEmail);
        setSentRequests(prev => [...prev, recipientEmail]);
    };

    if (suggestions.length === 0) {
        return <p className="text-sm text-center text-slate-500 dark:text-slate-400 py-8">No new suggestions right now. Check back later!</p>;
    }

    return (
        <ul className="space-y-3 max-h-64 overflow-y-auto pr-2">
            {suggestions.map((user, index) => {
                const isRequestSent = sentRequests.includes(user.email);
                return (
                    <li key={user.email} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50 animate-slide-in-up" style={{ animationDelay: `${index * 80}ms` }}>
                        <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 rounded-full bg-brand-gradient flex items-center justify-center">
                                <span className="font-bold text-white">{user.userData.name.charAt(0).toUpperCase()}</span>
                            </div>
                            <div>
                                <p className="font-semibold text-slate-800 dark:text-slate-100">{user.userData.name}</p>
                                <p className="text-xs text-slate-500 dark:text-slate-400">@{user.userData.username}</p>
                            </div>
                        </div>
                        <button 
                            onClick={() => handleSendRequest(user.email)}
                            disabled={isRequestSent}
                            className={`flex items-center space-x-1.5 text-xs font-semibold px-3 py-1 rounded-full transition-colors ${
                                isRequestSent 
                                ? 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300' 
                                : 'bg-brand-subtle text-brand-subtle hover:bg-opacity-20'
                            }`}
                        >
                           <UserPlusIcon className="w-4 h-4"/>
                           <span>{isRequestSent ? 'Sent' : 'Connect'}</span>
                        </button>
                    </li>
                );
            })}
        </ul>
    );
};

export default PeerSuggestions;