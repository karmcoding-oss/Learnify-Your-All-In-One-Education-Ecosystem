import React, { useState } from 'react';
import { getResearch } from '../../services/geminiService';
import { HiBookOpen as BookOpenIcon } from 'react-icons/hi2';
import { useAppContext } from '../../hooks/useAppContext';

const DashboardResearch: React.FC = () => {
    const [topic, setTopic] = useState('');
    const [result, setResult] = useState<string | null>(null);
    const [citations, setCitations] = useState<{ uri: string, title: string }[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const { unlockAchievement } = useAppContext();

    const handleResearch = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!topic.trim() || isLoading) return;

        setIsLoading(true);
        setError(null);
        setResult(null);
        setCitations([]);

        try {
            const response = await getResearch(topic);
            setResult(response.text);
            unlockAchievement('deep-diver');
            
            const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
            const webCitations = groundingChunks
                .map(chunk => chunk.web)
                .filter(web => web?.uri && web.title)
                .map(web => ({ uri: web.uri as string, title: web.title as string }));
            
            setCitations(webCitations);

        } catch (err) {
            setError("Failed to fetch research. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 animate-slide-in">
            <h3 className="text-xl font-bold mb-2 flex items-center">
                <BookOpenIcon className="w-6 h-6 mr-2 text-primary-500" /> Deep Research
            </h3>
            <p className="text-slate-500 dark:text-slate-400 mb-4 text-sm">
                Get up-to-date, accurate information on any topic, complete with citations from the web.
            </p>
            <form onSubmit={handleResearch} className="flex mb-4">
                <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Enter a research topic..."
                    className="flex-1 p-2 border rounded-l-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-primary-500 focus:border-primary-500"
                    disabled={isLoading}
                />
                <button type="submit" disabled={isLoading} className="bg-primary-600 text-white px-4 rounded-r-md hover:bg-primary-700 disabled:bg-primary-300">
                    {isLoading ? '...' : 'Research'}
                </button>
            </form>

            <div className="min-h-[200px]">
                {isLoading && (
                     <div className="flex justify-center items-center h-40">
                        <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-primary-500 rounded-full animate-pulse"></div>
                            <div className="w-3 h-3 bg-primary-500 rounded-full animate-pulse delay-75"></div>
                            <div className="w-3 h-3 bg-primary-500 rounded-full animate-pulse delay-150"></div>
                        </div>
                    </div>
                )}
                {error && <p className="text-red-500">{error}</p>}
                
                {result && (
                    <div className="max-h-96 overflow-y-auto pr-2">
                        <div className="prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: result.replace(/\n/g, '<br />') }} />

                        {citations.length > 0 && (
                            <div className="mt-6">
                                <h4 className="font-bold text-md mb-2">Sources:</h4>
                                <ul className="list-disc pl-5 space-y-2">
                                    {citations.map((cite, index) => (
                                        <li key={index}>
                                            <a href={cite.uri} target="_blank" rel="noopener noreferrer" className="text-primary-600 dark:text-primary-400 hover:underline">
                                                {cite.title || cite.uri}
                                            </a>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                )}
             </div>
        </div>
    );
};

export default DashboardResearch;