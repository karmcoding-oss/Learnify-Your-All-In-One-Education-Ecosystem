import React, { useState } from 'react';
import { HiUsers as UsersIcon } from 'react-icons/hi2';
import PeerSuggestions from './PeerSuggestions';
import FriendsList from './FriendsList';
import ChatWindow from './ChatWindow';
import UserSearch from './UserSearch';

const StudentConnect: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'suggestions' | 'friends' | 'search'>('suggestions');
    const [chattingWith, setChattingWith] = useState<string | null>(null); // Store friend's email

    const TabButton: React.FC<{ tabId: 'suggestions' | 'friends' | 'search', label: string }> = ({ tabId, label }) => (
        <button
            onClick={() => setActiveTab(tabId)}
            className={`px-4 py-1 text-sm font-semibold rounded-full transition-colors ${
                activeTab === tabId
                    ? 'bg-brand-gradient text-white'
                    : 'bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600'
            }`}
        >
            {label}
        </button>
    );

    return (
        <div className="liquid-glass rounded-2xl p-6 animate-slide-in">
            <h3 className="text-xl font-bold mb-4 flex items-center">
                <UsersIcon className="w-6 h-6 mr-2 text-brand" /> Connect
            </h3>
            <div className="flex space-x-2 mb-4">
                <TabButton tabId="suggestions" label="Suggestions" />
                <TabButton tabId="friends" label="My Friends" />
                <TabButton tabId="search" label="Search" />
            </div>

            <div className="min-h-[200px]">
                {activeTab === 'suggestions' && <PeerSuggestions />}
                {activeTab === 'friends' && <FriendsList onStartChat={setChattingWith} />}
                {activeTab === 'search' && <UserSearch />}
            </div>

            {chattingWith && (
                <ChatWindow friendEmail={chattingWith} onClose={() => setChattingWith(null)} />
            )}
        </div>
    );
};

export default StudentConnect;