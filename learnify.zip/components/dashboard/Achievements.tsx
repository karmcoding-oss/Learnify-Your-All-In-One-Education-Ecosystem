import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { mockAchievements } from '../../data';
import { HiTrophy as TrophyIcon } from 'react-icons/hi2';
import { View } from '../../types';

const Achievements: React.FC = () => {
    const { userData, navigate } = useAppContext();
    const unlocked = mockAchievements.filter(ach => userData.unlockedAchievements.includes(ach.id));

    return (
        <div 
            onClick={() => navigate(View.ACHIEVEMENTS)}
            className="liquid-glass interactive-glass rounded-2xl p-6 cursor-pointer"
        >
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold flex items-center">
                    <TrophyIcon className="w-6 h-6 mr-2 text-yellow-500" /> Achievements
                </h3>
                 <span className="text-xs font-semibold text-brand hover:underline">View All</span>
            </div>
            <div className="grid grid-cols-4 gap-4">
                {unlocked.length > 0 ? (
                    unlocked.slice(0, 4).map(ach => (
                        <div key={ach.id} className="flex flex-col items-center text-center" title={`${ach.title}: ${ach.description}`}>
                            <div className="text-3xl bg-slate-100/50 dark:bg-slate-700/50 rounded-full w-12 h-12 flex items-center justify-center">
                                {ach.icon}
                            </div>
                            <p className="text-xs mt-1 text-slate-600 dark:text-slate-300 truncate">{ach.title}</p>
                        </div>
                    ))
                ) : (
                    <p className="col-span-4 text-sm text-slate-500 dark:text-slate-400">Complete lessons and tests to earn badges!</p>
                )}
            </div>
        </div>
    );
};

export default Achievements;