import React, { useState, useEffect, useRef } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { HiXMark as XMarkIcon, HiPaperAirplane as PaperAirplaneIcon } from 'react-icons/hi2';

interface ChatWindowProps {
    friendEmail: string;
    onClose: () => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ friendEmail, onClose }) => {
    const { currentUser, allUsersData, userData, sendMessage } = useAppContext();
    const [message, setMessage] = useState('');
    const friend = allUsersData[friendEmail];
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const chatKey = [currentUser, friendEmail].sort().join('--');
    const chatHistory = userData.chats[chatKey] || [];

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [chatHistory]);

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (message.trim()) {
            sendMessage(friendEmail, message.trim());
            setMessage('');
        }
    };

    if (!friend) return null;

    return (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={onClose}>
            <div className="liquid-glass w-full max-w-md h-[70vh] flex flex-col transform transition-all duration-300 ease-out rounded-2xl" onClick={e => e.stopPropagation()} style={{ animation: 'slide-in 0.3s ease-out forwards' }}>
                <div className="flex items-center justify-between p-4 border-b border-white/20 dark:border-slate-700/50">
                    <div className="flex items-center space-x-3">
                         <div className="w-8 h-8 rounded-full bg-brand-gradient flex items-center justify-center text-sm">
                            <span className="font-bold text-white">{friend.userData.name.charAt(0).toUpperCase()}</span>
                        </div>
                        <div>
                             <h2 className="text-lg font-bold leading-tight">{friend.userData.name}</h2>
                             <p className="text-xs text-slate-500 dark:text-slate-400">@{friend.userData.username}</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-black/10 dark:hover:bg-white/10">
                        <XMarkIcon className="w-6 h-6 text-slate-500" />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {chatHistory.map((msg) => (
                         <div key={msg.id} className={`flex ${msg.sender === currentUser ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xs md:max-w-sm p-3 rounded-lg ${msg.sender === currentUser ? 'bg-brand-gradient text-white' : 'bg-slate-200 dark:bg-slate-700'}`}>
                                <p className="text-sm" style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</p>
                            </div>
                        </div>
                    ))}
                    <div ref={messagesEndRef} />
                </div>
                
                <form onSubmit={handleSend} className="p-4 border-t border-white/20 dark:border-slate-700/50 flex items-center space-x-2">
                    <input
                        type="text"
                        value={message}
                        onChange={e => setMessage(e.target.value)}
                        placeholder="Type a message..."
                        className="flex-1 p-2 border rounded-lg bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        autoFocus
                    />
                    <button type="submit" className="bg-brand-gradient text-white p-2.5 rounded-lg disabled:opacity-50" disabled={!message.trim()}>
                        <PaperAirplaneIcon className="w-5 h-5"/>
                    </button>
                </form>
            </div>
        </div>
    );
};

export default ChatWindow;