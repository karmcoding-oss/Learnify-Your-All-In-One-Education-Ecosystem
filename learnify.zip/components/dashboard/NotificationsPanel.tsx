import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { Notification, FriendRequest } from '../../types';
import { HiCheck as CheckIcon, HiXMark as XMarkIcon } from 'react-icons/hi2';

const NotificationsPanel: React.FC = () => {
    const { userData, handleFriendRequest, clearNotification, allUsersData } = useAppContext();
    const { notifications, friendRequests } = userData;

    if (notifications.length === 0) {
        return null;
    }

    const handleAction = (notification: Notification, accepted: boolean) => {
        if (notification.type === 'FRIEND_REQUEST') {
            const request = friendRequests.find(r => r.id === notification.relatedId);
            if (request) {
                handleFriendRequest(request, accepted);
            }
        }
        clearNotification(notification.id);
    };

    return (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-4 animate-slide-in border border-slate-200 dark:border-slate-700">
            <h3 className="text-lg font-bold mb-3">Notifications</h3>
            <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
                {notifications.map(notif => {
                    const sender = notif.from ? allUsersData[notif.from] : null;
                    return (
                        <div key={notif.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
                             <div className="flex items-center space-x-3">
                                {sender && (
                                    <div className="w-8 h-8 rounded-full bg-primary-200 dark:bg-primary-800 flex items-center justify-center text-sm">
                                        <span className="font-bold text-primary-700 dark:text-primary-200">{sender.userData.name.charAt(0).toUpperCase()}</span>
                                    </div>
                                )}
                                <p className="text-sm text-slate-700 dark:text-slate-200">{notif.message}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                                {notif.type === 'FRIEND_REQUEST' ? (
                                    <>
                                        <button onClick={() => handleAction(notif, true)} className="p-1.5 rounded-full bg-green-100 hover:bg-green-200 text-green-600 dark:bg-green-900/50 dark:hover:bg-green-900">
                                            <CheckIcon className="w-4 h-4" />
                                        </button>
                                        <button onClick={() => handleAction(notif, false)} className="p-1.5 rounded-full bg-red-100 hover:bg-red-200 text-red-600 dark:bg-red-900/50 dark:hover:bg-red-900">
                                            <XMarkIcon className="w-4 h-4" />
                                        </button>
                                    </>
                                ) : (
                                    <button onClick={() => clearNotification(notif.id)} className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-500">
                                         <XMarkIcon className="w-4 h-4" />
                                    </button>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default NotificationsPanel;