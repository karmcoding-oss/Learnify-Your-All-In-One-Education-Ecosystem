import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import CourseCard from './CourseCard';

const CourseMastery: React.FC = () => {
    const { courses } = useAppContext();
    return (
        <div>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight mb-4">My Mastery</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 perspective-1000">
                {courses.map((course, index) => (
                    <div key={course.id} className="animate-slide-in-up" style={{ animationDelay: `${index * 100}ms` }}>
                        <CourseCard course={course} />
                    </div>
                ))}
            </div>
        </div>
    );
};

export default CourseMastery;