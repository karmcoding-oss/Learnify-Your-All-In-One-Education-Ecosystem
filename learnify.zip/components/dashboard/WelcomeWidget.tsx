import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';

const WelcomeWidget: React.FC = () => {
    const { userData } = useAppContext();

    return (
        <div className="relative p-6 rounded-2xl overflow-hidden liquid-glass bg-welcome-gradient animate-slide-in-up">
            <div className="relative z-10">
                <h2 className="text-3xl font-extrabold tracking-tight text-white dark:text-sky-900">
                    Welcome Back, {userData.name}!
                </h2>
            </div>
             <div className="waves-container">
                <svg className="w-[200%] h-full absolute bottom-0 left-0" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2880 120" preserveAspectRatio="none">
                    <path 
                        className="wave-path wave-path-1" 
                        d="M0,64 C480,0,960,128,1440,64 C1920,0,2400,128,2880,64 L2880,121 L0,121 Z"
                    />
                    <path 
                        className="wave-path wave-path-2" 
                        d="M0,80 C480,20,960,140,1440,80 C1920,20,2400,140,2880,80 L2880,121 L0,121 Z"
                    />
                    <path 
                        className="wave-path wave-path-3" 
                        d="M0,96 C480,40,960,152,1440,96 C1920,40,2400,152,2880,96 L2880,121 L0,121 Z"
                    />
                </svg>
            </div>
        </div>
    );
};

export default WelcomeWidget;