import React from 'react';
import { Course, View } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';

const CourseCard: React.FC<{ course: Course }> = ({ course }) => {
    const { navigate } = useAppContext();
    const totalLessons = course.lessons.length;

    const averageMastery = totalLessons > 0 
        ? Math.round(course.lessons.reduce((acc, lesson) => acc + lesson.mastery, 0) / totalLessons)
        : 0;

    return (
        <div
            onClick={() => navigate(View.COURSE, course.id)}
            className="liquid-glass interactive-glass rounded-2xl cursor-pointer"
        >
            <div className="p-6">
                <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100">{course.title}</h3>
                <p className="mt-2 text-slate-500 dark:text-slate-400 text-sm h-10">{course.description}</p>
                <div className="mt-4">
                    <div className="flex justify-between items-center mb-1 text-sm text-slate-600 dark:text-slate-300">
                        <span>Mastery</span>
                        <span className="font-semibold">{averageMastery}%</span>
                    </div>
                    <div className="w-full bg-black/10 dark:bg-white/10 rounded-full h-2.5 progress-bar-container">
                        <div
                            className="bg-brand-gradient h-2.5 rounded-full transition-all duration-500 ease-out"
                            style={{ width: `${averageMastery}%` }}
                        ></div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CourseCard;