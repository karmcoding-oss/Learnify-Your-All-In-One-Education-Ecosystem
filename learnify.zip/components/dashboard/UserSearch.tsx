import React, { useState, useMemo } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { UserAccount } from '../../types';
import { HiUserPlus as UserPlusIcon } from 'react-icons/hi2';

// Component to display a single user in search results
const UserSearchResult: React.FC<{ user: UserAccount, onConnect: (email: string) => void, isRequestSent: boolean }> = ({ user, onConnect, isRequestSent }) => {
    return (
        <li className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-700/50">
            <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-brand-gradient flex items-center justify-center">
                    <span className="font-bold text-white">{user.userData.name.charAt(0).toUpperCase()}</span>
                </div>
                <div>
                    <p className="font-semibold text-slate-800 dark:text-slate-100">{user.userData.name}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">@{user.userData.username}</p>
                </div>
            </div>
            <button
                onClick={() => onConnect(user.email)}
                disabled={isRequestSent}
                className={`flex items-center space-x-1.5 text-xs font-semibold px-3 py-1 rounded-full transition-colors ${
                    isRequestSent
                    ? 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300'
                    : 'bg-brand-subtle text-brand-subtle hover:bg-opacity-20'
                }`}
            >
               <UserPlusIcon className="w-4 h-4"/>
               <span>{isRequestSent ? 'Sent' : 'Connect'}</span>
            </button>
        </li>
    );
};


const UserSearch: React.FC = () => {
    const { allUsersData, currentUser, sendFriendRequest, userData } = useAppContext();
    const [query, setQuery] = useState('');
    const [sentRequests, setSentRequests] = useState<string[]>([]);

    const searchResults = useMemo(() => {
        if (!query.trim()) return [];
        const lowerCaseQuery = query.toLowerCase();
        
        // Find existing friend requests to avoid showing users with pending requests
        const pendingRequestEmails = new Set();
        userData.friendRequests.forEach(req => {
            pendingRequestEmails.add(req.from);
            pendingRequestEmails.add(req.to);
        });

        return Object.values(allUsersData).filter((user: UserAccount) => {
            // Exclude self, existing friends, and users with pending requests
            if (user.email === currentUser) return false;
            if (userData.friends.includes(user.email)) return false;
            if (pendingRequestEmails.has(user.email)) return false;


            const nameMatch = user.userData.name.toLowerCase().includes(lowerCaseQuery);
            const usernameMatch = user.userData.username?.toLowerCase().includes(lowerCaseQuery);
            return nameMatch || usernameMatch;
        });
    }, [query, allUsersData, currentUser, userData]);

    const handleSendRequest = (recipientEmail: string) => {
        sendFriendRequest(recipientEmail);
        setSentRequests(prev => [...prev, recipientEmail]);
    };

    return (
        <div>
            <input
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search by name or @username"
                className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand mb-4"
            />
            <ul className="space-y-3 max-h-64 overflow-y-auto pr-2">
                {searchResults.length > 0 ? (
                    searchResults.map(user => (
                        <UserSearchResult 
                            key={user.email} 
                            user={user} 
                            onConnect={handleSendRequest}
                            isRequestSent={sentRequests.includes(user.email)}
                        />
                    ))
                ) : (
                    query.trim() && <p className="text-sm text-center text-slate-500 dark:text-slate-400 py-8">No users found.</p>
                )}
            </ul>
        </div>
    );
};

export default UserSearch;