import React, { useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { View } from '../types';
import { 
    HiSparkles as SparklesIcon, 
    HiHome as HomeIcon, 
    HiBookOpen as BookOpenIcon, 
    HiTrophy as TrophyIcon, 
    HiCalendarDays as CalendarIcon, 
    HiGlobeAlt as GlobeAltIcon, 
    HiHeart as HeartIcon, 
    HiUsers as UsersIcon, 
    HiCog6Tooth as Cog6ToothIcon, 
    HiUserCircle as UserCircleIcon, 
    HiChevronDown as ChevronDownIcon,
    HiClipboardDocumentList as ClipboardDocumentListIcon,
    HiMagnifyingGlass as MagnifyingGlassIcon,
    HiArrowRightOnRectangle as LogoutIcon
} from 'react-icons/hi2';
import { SiSololearn } from 'react-icons/si';


const Sidebar: React.FC = () => {
    const { userData, viewState, navigate, courses, toggleSidebar, setSearchQuery, logout } = useAppContext();
    const isOpen = userData.isSidebarOpen;
    const [coursesOpen, setCoursesOpen] = useState(true);
    const [localQuery, setLocalQuery] = useState('');

    const handleSearchSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!localQuery.trim()) return;
        setSearchQuery(localQuery);
        navigate(View.SEARCH_RESULTS);
        if (window.innerWidth < 1024) {
             toggleSidebar();
        }
    };

    const NavItem: React.FC<{
        view: View;
        label: string;
        icon: React.ReactNode;
        courseId?: string;
        isSubItem?: boolean;
    }> = ({ view, label, icon, courseId, isSubItem = false }) => {
        const isActive = viewState.view === view && (!courseId || viewState.courseId === courseId);
        const itemClass = `flex items-center w-full text-left rounded-lg transition-all duration-200 ${
            isActive
                ? 'bg-brand-gradient text-white shadow-md'
                : 'text-slate-600 hover:bg-black/5 dark:text-slate-300 dark:hover:bg-white/10'
        } ${isSubItem ? 'py-2 pl-4 pr-3 text-sm' : 'p-3'}`;
        
        const handleClick = () => {
            navigate(view, courseId);
            // Close sidebar on navigation on mobile
            if (window.innerWidth < 1024) {
                toggleSidebar();
            }
        };

        return (
            <button onClick={handleClick} className={itemClass}>
                <div className="flex-shrink-0">{icon}</div>
                <span
                    className={`ml-4 whitespace-nowrap overflow-hidden transition-all duration-300 ${
                        isOpen ? 'opacity-100 max-w-full' : 'opacity-0 max-w-0'
                    }`}
                >
                    {label}
                </span>
            </button>
        );
    };

    return (
        <aside className={`fixed top-0 left-0 h-full z-50 liquid-glass !rounded-none flex flex-col transition-transform duration-300 ease-in-out lg:transition-all ${isOpen ? 'w-64 translate-x-0' : 'w-64 -translate-x-full lg:w-20 lg:translate-x-0'}`}>
            <div className={`flex items-center border-b border-white/20 dark:border-slate-700/50 transition-all duration-300 ${isOpen ? 'px-4' : 'px-0 justify-center'}`} style={{ height: '4rem' }}>
                <SiSololearn className="w-8 h-8 text-blue-600 dark:text-sky-400 flex-shrink-0" />
                <span className={`ml-3 text-2xl font-bold text-slate-800 dark:text-slate-100 whitespace-nowrap overflow-hidden transition-all duration-300 ${isOpen ? 'opacity-100 max-w-full' : 'opacity-0 max-w-0'}`}>
                    Learnify
                </span>
            </div>

            <div className="p-3 border-b border-white/20 dark:border-slate-700/50">
                {isOpen ? (
                    <form onSubmit={handleSearchSubmit} className="relative">
                        <input
                            type="text"
                            placeholder="Search..."
                            value={localQuery}
                            onChange={(e) => setLocalQuery(e.target.value)}
                            className="w-full bg-slate-100/50 dark:bg-slate-800/50 border-none rounded-md py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-brand placeholder-slate-500 dark:placeholder-slate-400"
                        />
                        <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    </form>
                ) : (
                    <button
                        onClick={toggleSidebar}
                        className="w-full flex justify-center p-3 text-slate-600 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/10 rounded-lg"
                        aria-label="Open search"
                    >
                        <MagnifyingGlassIcon className="w-6 h-6"/>
                    </button>
                )}
            </div>

            <nav className="flex-1 overflow-y-auto overflow-x-hidden p-3 space-y-1">
                <NavItem view={View.DASHBOARD} label="Dashboard" icon={<HomeIcon className="w-6 h-6"/>} />
                <NavItem view={View.RESEARCH} label="Research" icon={<GlobeAltIcon className="w-6 h-6"/>} />
                <NavItem view={View.CALENDAR} label="Calendar" icon={<CalendarIcon className="w-6 h-6"/>} />
                <NavItem view={View.ACHIEVEMENTS} label="Achievements" icon={<TrophyIcon className="w-6 h-6"/>} />

                <hr className="my-2 border-white/20 dark:border-slate-700/50" />
                
                <NavItem view={View.DASHBOARD} label="Assignments" icon={<ClipboardDocumentListIcon className="w-6 h-6"/>} />

                <button onClick={() => setCoursesOpen(!coursesOpen)} className="flex items-center justify-between w-full p-3 text-left text-slate-600 hover:bg-black/5 dark:text-slate-300 dark:hover:bg-white/10 rounded-lg">
                    <div className="flex items-center">
                        <BookOpenIcon className="w-6 h-6 flex-shrink-0"/>
                        <span className={`ml-4 whitespace-nowrap overflow-hidden transition-all duration-300 ${isOpen ? 'opacity-100 max-w-full' : 'opacity-0 max-w-0'}`}>
                            My Courses
                        </span>
                    </div>
                    {isOpen && <ChevronDownIcon className={`w-5 h-5 transition-transform duration-200 ${coursesOpen ? 'rotate-180' : ''}`} />}
                </button>

                 <div className={`overflow-hidden transition-all duration-300 ${coursesOpen && isOpen ? 'max-h-96' : 'max-h-0'}`}>
                    <div className="pl-6 space-y-1 py-1">
                        {courses.map(course => (
                            <NavItem
                                key={course.id}
                                view={View.COURSE}
                                label={course.title}
                                icon={<div className="w-2 h-2 bg-slate-400 rounded-full"></div>}
                                courseId={course.id}
                                isSubItem
                            />
                        ))}
                    </div>
                </div>
                
                <hr className="my-2 border-white/20 dark:border-slate-700/50" />
                
                <NavItem view={View.MENTAL_HEALTH} label="Wellbeing" icon={<HeartIcon className="w-6 h-6"/>} />
                <NavItem view={View.COMMUNITY} label="Community" icon={<UsersIcon className="w-6 h-6"/>} />

            </nav>

            <div className="p-3 border-t border-white/20 dark:border-slate-700/50">
                <NavItem view={View.PROFILE} label="Profile" icon={<UserCircleIcon className="w-6 h-6"/>} />
                <NavItem view={View.SETTINGS} label="Settings" icon={<Cog6ToothIcon className="w-6 h-6"/>} />
                 <button
                    onClick={logout}
                    className="flex items-center w-full text-left rounded-lg transition-all duration-200 text-slate-600 hover:bg-black/5 dark:text-slate-300 dark:hover:bg-white/10 p-3 mt-1"
                >
                    <div className="flex-shrink-0"><LogoutIcon className="w-6 h-6"/></div>
                    <span
                        className={`ml-4 whitespace-nowrap overflow-hidden transition-all duration-300 ${
                            isOpen ? 'opacity-100 max-w-full' : 'opacity-0 max-w-0'
                        }`}
                    >
                        Logout
                    </span>
                </button>
            </div>
        </aside>
    );
};

export default Sidebar;