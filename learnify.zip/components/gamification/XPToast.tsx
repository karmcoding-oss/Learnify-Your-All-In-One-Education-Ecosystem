import React, { useEffect, useState } from 'react';
import { HiSparkles } from 'react-icons/hi2';

interface XPToastProps {
    amount: number;
    reason: string;
    onDone: () => void;
}

const XPToast: React.FC<XPToastProps> = ({ amount, reason, onDone }) => {
    const [isExiting, setIsExiting] = useState(false);

    useEffect(() => {
        const exitTimer = setTimeout(() => {
            setIsExiting(true);
        }, 2500);

        const removeTimer = setTimeout(() => {
            onDone();
        }, 3000);

        return () => {
            clearTimeout(exitTimer);
            clearTimeout(removeTimer);
        };
    }, [onDone]);

    const animationClass = isExiting ? 'animate-modal-out' : 'animate-modal-in';

    return (
        <div 
            className={`fixed bottom-5 right-5 z-50 liquid-glass p-3 rounded-xl shadow-lg flex items-center space-x-3 transform ${animationClass}`}
            style={{ animationDuration: '0.4s' }}
        >
            <HiSparkles className="w-6 h-6 text-yellow-400" />
            <div>
                <p className="font-bold text-brand-gradient">+{amount} XP</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{reason}</p>
            </div>
        </div>
    );
};

export default XPToast;
