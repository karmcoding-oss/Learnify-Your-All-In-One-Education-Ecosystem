import React from 'react';

const ConfettiPiece: React.FC<{ index: number }> = ({ index }) => {
    const colors = ['#60a5fa', '#3b82f6', '#fbbf24', '#f97316', '#10b981'];
    const color = colors[Math.floor(Math.random() * colors.length)];
    const style = {
        left: `${Math.random() * 100}%`,
        backgroundColor: color,
        animationName: 'confetti-fall',
        animationDuration: `${2 + Math.random() * 2}s`,
        animationDelay: `${Math.random() * 3}s`,
        animationTimingFunction: 'linear',
        animationIterationCount: '1',
        animationFillMode: 'forwards',
    };
    return <div className="absolute top-0 w-3 h-3 opacity-0" style={style} />;
};

const Confetti: React.FC = () => {
    const numPieces = 100;
    return (
        <div className="absolute inset-0 overflow-hidden pointer-events-none z-50">
            {Array.from({ length: numPieces }).map((_, i) => (
                <ConfettiPiece key={i} index={i} />
            ))}
        </div>
    );
};

export default Confetti;