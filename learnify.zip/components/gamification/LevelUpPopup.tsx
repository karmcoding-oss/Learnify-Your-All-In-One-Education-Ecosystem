import React from 'react';
import { LevelUpInfo } from '../../types';
import Confetti from './Confetti';

interface LevelUpPopupProps {
    isOpen: boolean;
    onClose: () => void;
    levelUpInfo: LevelUpInfo;
}

const LevelUpPopup: React.FC<LevelUpPopupProps> = ({ isOpen, onClose, levelUpInfo }) => {
    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={onClose}
            aria-modal="true"
            role="dialog"
        >
            <Confetti />
             <div 
                className={`liquid-glass rounded-2xl w-full max-w-sm text-center p-8 transform animate-modal-in`}
                onClick={e => e.stopPropagation()}
            >
                <h2 className="text-2xl font-bold text-brand-gradient">LEVEL UP!</h2>
                <div className="my-6">
                    <span className="text-5xl font-extrabold text-slate-700 dark:text-slate-300">{levelUpInfo.oldLevel}</span>
                    <span className="text-3xl mx-4 font-bold text-slate-500 dark:text-slate-400">→</span>
                    <span className="text-7xl font-extrabold text-slate-900 dark:text-white">{levelUpInfo.newLevel}</span>
                </div>
                <p className="text-slate-600 dark:text-slate-400">Congratulations! You've reached a new level. Keep up the great work!</p>
                <button onClick={onClose} className="mt-6 bg-brand-gradient text-white px-8 py-2 rounded-lg font-semibold">
                    Continue
                </button>
            </div>
        </div>
    );
};

export default LevelUpPopup;
