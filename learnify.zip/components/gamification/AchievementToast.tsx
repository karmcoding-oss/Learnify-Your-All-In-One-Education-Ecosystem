import React, { useEffect, useState } from 'react';
import { Achievement } from '../../types';

interface AchievementToastProps {
    achievement: Achievement;
    onClose: () => void;
}

const AchievementToast: React.FC<AchievementToastProps> = ({ achievement, onClose }) => {
    const [animationClass, setAnimationClass] = useState('animate-achievement-toast-in');

    useEffect(() => {
        const closeTimer = setTimeout(() => {
            setAnimationClass('animate-achievement-toast-out');
        }, 3000);

        const removeTimer = setTimeout(() => {
            onClose();
        }, 3500);

        return () => {
            clearTimeout(closeTimer);
            clearTimeout(removeTimer);
        };
    }, [onClose]);

    return (
        <div
            className={`fixed bottom-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4 p-4 rounded-xl shadow-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 ${animationClass}`}
        >
            <div className="text-4xl">{achievement.icon}</div>
            <div>
                <p className="font-bold text-slate-800 dark:text-slate-100">Achievement Unlocked!</p>
                <p className="text-slate-600 dark:text-slate-300">{achievement.title}</p>
            </div>
        </div>
    );
};

export default AchievementToast;