import React, { useState, useEffect } from 'react';
import { Course } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';
import Modal from './Modal';

interface CourseModalProps {
    isOpen: boolean;
    onClose: () => void;
    course?: Course;
}

const CourseModal: React.FC<CourseModalProps> = ({ isOpen, onClose, course }) => {
    const { addCourse, updateCourse } = useAppContext();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');

    useEffect(() => {
        if (course) {
            setTitle(course.title);
            setDescription(course.description);
        } else {
            setTitle('');
            setDescription('');
        }
    }, [course, isOpen]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim()) return;

        if (course) {
            updateCourse(course.id, { title, description });
        } else {
            addCourse({ title, description });
        }
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={course ? 'Edit Course' : 'Create New Course'}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label htmlFor="title" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Title</label>
                    <input
                        type="text"
                        id="title"
                        value={title}
                        onChange={e => setTitle(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        placeholder="e.g., Introduction to Astrophysics"
                        required
                    />
                </div>
                <div>
                    <label htmlFor="description" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Description</label>
                    <textarea
                        id="description"
                        value={description}
                        onChange={e => setDescription(e.target.value)}
                        className="w-full p-2 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                        placeholder="A brief summary of the course"
                        rows={3}
                    />
                </div>
                <div className="flex justify-end pt-4">
                    <button type="submit" className="bg-brand-gradient text-white px-6 py-2 rounded-lg font-semibold">
                        {course ? 'Save Changes' : 'Create Course'}
                    </button>
                </div>
            </form>
        </Modal>
    );
};

export default CourseModal;