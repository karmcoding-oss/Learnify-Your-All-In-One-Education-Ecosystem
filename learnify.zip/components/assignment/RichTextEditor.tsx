import React, { useRef, useEffect } from 'react';
import BoldIcon from '../icons/BoldIcon';
import ItalicIcon from '../icons/ItalicIcon';
import UnderlineIcon from '../icons/UnderlineIcon';
import ListBulletIcon from '../icons/ListBulletIcon';
import ListOrderedIcon from '../icons/ListOrderedIcon';

interface RichTextEditorProps {
    content: string;
    onChange: (newContent: string) => void;
}

const RichTextEditor: React.FC<RichTextEditorProps> = ({ content, onChange }) => {
    const editorRef = useRef<HTMLDivElement>(null);

    // Sync editor content if prop changes externally, but not during typing.
    useEffect(() => {
        if (editorRef.current && editorRef.current.innerHTML !== content) {
            editorRef.current.innerHTML = content;
        }
    }, [content]);

    const handleInput = () => {
        if (editorRef.current) {
            onChange(editorRef.current.innerHTML);
        }
    };
    
    const execCommand = (command: string, value?: string) => {
        document.execCommand(command, false, value);
        editorRef.current?.focus();
        handleInput(); // Save content after applying format
    };

    const ToolbarButton: React.FC<{ command: string; icon: React.ReactNode, title: string }> = ({ command, icon, title }) => (
        <button
            type="button"
            onMouseDown={(e) => { e.preventDefault(); execCommand(command); }}
            className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700"
            title={title}
        >
            {icon}
        </button>
    );

    return (
        <div className="h-full flex flex-col">
            <div className="flex items-center space-x-1 p-2 border-b border-slate-200 dark:border-slate-700">
                <ToolbarButton command="bold" icon={<BoldIcon className="w-5 h-5" />} title="Bold" />
                <ToolbarButton command="italic" icon={<ItalicIcon className="w-5 h-5" />} title="Italic" />
                <ToolbarButton command="underline" icon={<UnderlineIcon className="w-5 h-5" />} title="Underline" />
                <div className="h-6 w-px bg-slate-200 dark:bg-slate-700 mx-2"></div>
                <ToolbarButton command="insertUnorderedList" icon={<ListBulletIcon className="w-5 h-5" />} title="Bulleted List" />
                <ToolbarButton command="insertOrderedList" icon={<ListOrderedIcon className="w-5 h-5" />} title="Numbered List" />
            </div>
            <div
                ref={editorRef}
                contentEditable
                onInput={handleInput}
                className="flex-grow p-4 focus:outline-none prose dark:prose-invert max-w-none"
            />
        </div>
    );
};

export default RichTextEditor;