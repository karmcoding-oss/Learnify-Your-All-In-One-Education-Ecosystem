import React, { useState, useEffect, useCallback } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import Dragon from '../gamification/Dragon';

const BreathingExercise: React.FC = () => {
    const { incrementBreathingSessions } = useAppContext();
    const [duration, setDuration] = useState(60); // in seconds
    const [timeRemaining, setTimeRemaining] = useState(duration);
    const [isActive, setIsActive] = useState(false);
    const [breathingText, setBreathingText] = useState('Get Ready');

    const startSession = () => {
        setTimeRemaining(duration);
        setIsActive(true);
        incrementBreathingSessions();
    };
    
    const stopSession = useCallback(() => {
        setIsActive(false);
        setBreathingText('Finished!');
        setTimeout(() => setBreathingText('Get Ready'), 2000);
    }, []);

    useEffect(() => {
        let timer: number | null = null;
        if (isActive && timeRemaining > 0) {
            timer = window.setTimeout(() => setTimeRemaining(prev => prev - 1), 1000);
        } else if (timeRemaining === 0 && isActive) {
            stopSession();
        }
        return () => {
            if (timer) clearTimeout(timer);
        };
    }, [isActive, timeRemaining, stopSession]);

    useEffect(() => {
        if (!isActive) return;

        const cycle = ['Breathe In...', 'Hold', 'Breathe Out...'];
        let i = -1; // Start before the first state
        
        const updateText = () => {
             i = (i + 1) % cycle.length;
             setBreathingText(cycle[i]);
        };
        updateText();
        const interval = setInterval(updateText, 4000);
        
        return () => clearInterval(interval);

    }, [isActive]);

    const formatTime = (seconds: number) => {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
    };

    if (isActive) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-center">
                <Dragon state="calm" />
                <div className="w-48 h-48 bg-brand-subtle rounded-full flex items-center justify-center animate-breathe-circle">
                    <div className="w-40 h-40 bg-brand-subtle rounded-full flex items-center justify-center">
                         <span className="text-2xl font-bold text-brand-subtle">{breathingText}</span>
                    </div>
                </div>
                <p className="mt-8 text-4xl font-bold">{formatTime(timeRemaining)}</p>
                <button onClick={stopSession} className="mt-4 bg-red-500 text-white px-6 py-2 rounded-lg font-semibold">
                    Stop Session
                </button>
            </div>
        )
    }

    return (
        <div className="flex flex-col items-center">
            <h3 className="text-2xl font-bold mb-2">Guided Breathing</h3>
            <p className="text-slate-500 dark:text-slate-400 mb-6 text-center">Take a moment to center yourself with a calming breathing exercise.</p>

            <div className="mb-6">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Choose session length:</label>
                <div className="flex space-x-2 p-1 bg-slate-100 dark:bg-slate-700 rounded-lg">
                    {[1, 3, 5].map(min => (
                        <button
                            key={min}
                            onClick={() => setDuration(min * 60)}
                            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors w-24 ${duration === min * 60 ? 'bg-brand-gradient text-white' : 'hover:bg-slate-200 dark:hover:bg-slate-600'}`}
                        >
                            {min} minute{min > 1 ? 's' : ''}
                        </button>
                    ))}
                </div>
            </div>
            
            <button onClick={startSession} className="bg-brand-gradient text-white px-8 py-3 rounded-lg font-semibold transition-colors">
                Start Session
            </button>
        </div>
    );
};

export default BreathingExercise;