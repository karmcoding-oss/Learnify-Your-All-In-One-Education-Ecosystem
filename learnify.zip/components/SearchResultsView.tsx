import React from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { SearchResult, View } from '../types';
import { HiBookOpen, HiOutlinePencilSquare, HiClipboardDocumentList, HiCalendarDays, HiChevronRight } from 'react-icons/hi2';

const ResultItem: React.FC<{ result: SearchResult, index: number }> = ({ result, index }) => {
    const { navigate } = useAppContext();
    let icon, title, description, onClick;

    switch (result.type) {
        case 'course':
            icon = <HiBookOpen className="w-6 h-6 text-brand" />;
            title = result.data.title;
            description = `Course: ${result.data.description}`;
            onClick = () => navigate(View.COURSE, result.data.id);
            break;
        case 'lesson':
            icon = <HiOutlinePencilSquare className="w-6 h-6 text-green-500" />;
            title = result.data.title;
            description = `Lesson in "${result.course.title}"`;
            onClick = () => navigate(View.LESSON, result.course.id, result.data.id);
            break;
        case 'assignment':
            icon = <HiClipboardDocumentList className="w-6 h-6 text-orange-500" />;
            title = result.data.title;
            description = `Assignment for "${result.course?.title || 'Unknown Course'}"`;
            onClick = () => navigate(View.ASSIGNMENT, null, null, result.data.id);
            break;
        case 'event':
            icon = <HiCalendarDays className="w-6 h-6 text-purple-500" />;
            title = result.data.title;
            description = `Event on ${new Date(result.data.date + 'T00:00:00').toLocaleDateString()}`;
            onClick = () => navigate(View.CALENDAR);
            break;
    }

    return (
        <li
            onClick={onClick}
            className="liquid-glass interactive-glass flex items-center justify-between p-4 rounded-lg cursor-pointer animate-slide-in-up"
            style={{ animationDelay: `${index * 50}ms` }}
        >
            <div className="flex items-center space-x-4 overflow-hidden">
                <div className="flex-shrink-0">{icon}</div>
                <div className="overflow-hidden">
                    <p className="font-bold truncate">{title}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400 truncate">{description}</p>
                </div>
            </div>
            <HiChevronRight className="w-5 h-5 text-slate-400 flex-shrink-0 ml-2" />
        </li>
    );
};

const SearchResultsView: React.FC = () => {
    const { searchQuery, searchResults } = useAppContext();

    const groupedResults = searchResults.reduce((acc, result) => {
        (acc[result.type] = acc[result.type] || []).push(result);
        return acc;
    }, {} as Record<SearchResult['type'], SearchResult[]>);

    const resultOrder: SearchResult['type'][] = ['course', 'lesson', 'assignment', 'event'];

    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                Search Results for "<span className="text-brand">{searchQuery}</span>"
            </h2>

            {searchResults.length === 0 ? (
                <div className="text-center py-16 liquid-glass rounded-2xl">
                    <h3 className="text-xl font-semibold">No Results Found</h3>
                    <p className="mt-2 text-slate-500 dark:text-slate-400">Try searching for something else.</p>
                </div>
            ) : (
                resultOrder.map(type => {
                    const results = groupedResults[type];
                    if (!results || results.length === 0) return null;

                    const titleMap = {
                        course: 'Courses',
                        lesson: 'Lessons',
                        assignment: 'Assignments',
                        event: 'Calendar Events',
                    };

                    return (
                        <section key={type}>
                            <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">{titleMap[type]}</h3>
                            <ul className="space-y-3">
                                {results.map((result, index) => (
                                    <ResultItem key={`${result.type}-${result.data.id}`} result={result} index={index} />
                                ))}
                            </ul>
                        </section>
                    );
                })
            )}
        </div>
    );
};

export default SearchResultsView;
