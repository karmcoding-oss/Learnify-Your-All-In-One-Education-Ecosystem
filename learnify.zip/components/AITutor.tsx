

import React, { useState, useEffect, useRef } from 'react';
import { Lesson } from '../types';
import { sendMessageToTutor } from '../services/geminiService';
import { HiSparkles as SparklesIcon, HiPaperAirplane as PaperAirplaneIcon, HiAdjustmentsHorizontal } from 'react-icons/hi2';
import { useAppContext } from '../hooks/useAppContext';
import { Content } from '@google/genai';

interface Message {
    sender: 'user' | 'ai';
    text: string;
    citations?: { uri: string; title: string }[];
}

const FilterSelect: React.FC<{ label: string; value: string; onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void; options: { value: string; label: string }[] }> = ({ label, value, onChange, options }) => (
    <div>
        <label className="block text-xs font-medium text-slate-500 dark:text-slate-400">{label}</label>
        <select value={value} onChange={onChange} className="w-full mt-1 p-1.5 text-sm border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand">
            {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
        </select>
    </div>
);


const AITutor: React.FC<{ lesson: Lesson }> = ({ lesson }) => {
    const [messages, setMessages] = useState<Message[]>([
        { sender: 'ai', text: `Hi! I'm your AI Tutor. Ask me anything about "${lesson.title}".` }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const { unlockAchievement } = useAppContext();

    // Filters state
    const [showFilters, setShowFilters] = useState(false);
    const [recency, setRecency] = useState('any');
    const [credibility, setCredibility] = useState('any');
    const [sourceType, setSourceType] = useState('any');


    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading) return;

        if (messages.filter(m => m.sender === 'user').length === 0) {
            unlockAchievement('curious-mind');
        }

        const userMessage: Message = { sender: 'user', text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            // Construct history for the API, excluding the initial AI welcome message.
            const apiHistory: Content[] = messages.slice(1).map(msg => ({
                role: msg.sender === 'user' ? 'user' : 'model',
                parts: [{ text: msg.text }],
            }));

            const response = await sendMessageToTutor(input, apiHistory, lesson.content, { recency, credibility, sourceType });
            
            const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
            const webCitations = groundingChunks
                .map(chunk => chunk.web)
                .filter(web => web?.uri)
                .map(web => ({ uri: web.uri as string, title: web.title as string || web.uri as string }));

            const aiMessage: Message = {
                sender: 'ai',
                text: response.text,
                citations: webCitations.length > 0 ? webCitations : undefined,
            };
            setMessages(prev => [...prev, aiMessage]);

        } catch (error: any) {
            console.error("Error sending message:", error);
            const errorMessage: Message = { sender: 'ai', text: error.message || "Sorry, I'm having trouble connecting right now. Please try again later." };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-[60vh] animate-slide-in">
            <div className="flex justify-between items-center mb-4">
                 <h3 className="text-xl font-bold flex items-center"><SparklesIcon className="w-6 h-6 mr-2 text-brand" /> AI Tutor</h3>
                 <button onClick={() => setShowFilters(!showFilters)} className="flex items-center space-x-2 text-sm font-medium text-slate-500 hover:text-brand dark:text-slate-400 dark:hover:text-brand">
                    <HiAdjustmentsHorizontal className="w-5 h-5" />
                    <span>Filters</span>
                </button>
            </div>
            
            {showFilters && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4 p-4 bg-slate-100 dark:bg-slate-900/50 rounded-lg animate-slide-in-up" style={{ animationDuration: '0.3s' }}>
                    <FilterSelect label="Recency" value={recency} onChange={e => setRecency(e.target.value)} options={[
                        { value: 'any', label: 'Any time' },
                        { value: 'past year', label: 'Past year' },
                        { value: 'past month', label: 'Past month' }
                    ]}/>
                     <FilterSelect label="Credibility" value={credibility} onChange={e => setCredibility(e.target.value)} options={[
                        { value: 'any', label: 'Any' },
                        { value: 'high', label: 'High' }
                    ]}/>
                     <FilterSelect label="Source Type" value={sourceType} onChange={e => setSourceType(e.target.value)} options={[
                        { value: 'any', label: 'Any' },
                        { value: 'article', label: 'Article' },
                        { value: 'video', label: 'Video' },
                        { value: 'paper', label: 'Paper' }
                    ]}/>
                </div>
            )}

            <div className="flex-1 overflow-y-auto pr-4 space-y-4">
                {messages.map((msg, index) => (
                    <div key={index} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-md p-3 rounded-lg ${msg.sender === 'user' ? 'bg-brand-gradient text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-100'}`}>
                            <p style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</p>
                            {msg.citations && msg.citations.length > 0 && (
                                <div className="mt-4 pt-3 border-t border-slate-300 dark:border-slate-600">
                                    <h5 className="font-bold text-sm mb-1">Sources:</h5>
                                    <ul className="list-disc pl-5 space-y-1 text-sm">
                                        {msg.citations.map((cite, i) => (
                                            <li key={i}>
                                                <a href={cite.uri} target="_blank" rel="noopener noreferrer" className="text-brand hover:underline break-all">
                                                    {cite.title}
                                                </a>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
                 {isLoading && (
                    <div className="flex justify-start">
                        <div className="max-w-md p-3 rounded-lg bg-slate-200 dark:bg-slate-700">
                            <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse"></div>
                                <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse" style={{ animationDelay: '0.1s' }}></div>
                                <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                            </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>
            <form onSubmit={handleSend} className="mt-4 flex">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask a question..."
                    className="flex-1 p-2 border rounded-l-md bg-white dark:bg-slate-900 dark:border-slate-600 focus:ring-brand focus:border-brand"
                    disabled={isLoading}
                />
                <button type="submit" disabled={isLoading} className="bg-brand-gradient text-white px-4 rounded-r-md disabled:opacity-50">
                    <PaperAirplaneIcon className="w-5 h-5" />
                </button>
            </form>
        </div>
    );
};

export default AITutor;