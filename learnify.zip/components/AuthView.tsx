import React, { useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { SiSololearn } from 'react-icons/si';

const AuthView: React.FC = () => {
    const [isLogin, setIsLogin] = useState(true);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const { login, signup } = useAppContext();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!email.trim() || !password.trim()) {
            setError('Please fill in all fields.');
            return;
        }

        let success = false;
        if (isLogin) {
            success = login(email, password);
            if(!success) setError("Invalid credentials.");
        } else {
            // Validate email format before attempting to sign up
            const emailRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (!emailRegex.test(String(email).toLowerCase())) {
                setError("Please enter a valid email address.");
                return;
            }
            success = signup(email, password);
            if(!success) setError("An account with this email already exists.");
        }
    };

    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
             <div className="text-center mb-8 flex items-center justify-center space-x-4">
                <SiSololearn className="w-12 h-12 text-blue-600 dark:text-sky-400" />
                <h1 className="text-5xl font-extrabold text-brand-gradient tracking-tight">Learnify</h1>
            </div>

            <div className="w-full max-w-md liquid-glass rounded-2xl p-8 animate-slide-in">
                <h2 className="text-2xl font-bold text-center text-slate-800 dark:text-slate-100 mb-2">{isLogin ? 'Welcome Back!' : 'Create Your Account'}</h2>
                <p className="text-center text-slate-500 dark:text-slate-400 mb-6">{isLogin ? 'Log in to continue your journey.' : 'Sign up to start learning.'}</p>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                            {isLogin ? 'Email or Username' : 'Email'}
                        </label>
                        <input
                            type="text"
                            id="email"
                            value={email}
                            onChange={e => setEmail(e.target.value)}
                            className="w-full p-3 border rounded-md bg-white/70 dark:bg-slate-900/70 border-slate-300 dark:border-slate-600 focus:ring-brand focus:border-brand"
                            placeholder={isLogin ? "you@example.com or your_username" : "you@example.com"}
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={e => setPassword(e.target.value)}
                            className="w-full p-3 border rounded-md bg-white/70 dark:bg-slate-900/70 border-slate-300 dark:border-slate-600 focus:ring-brand focus:border-brand"
                            placeholder="••••••••"
                            required
                        />
                    </div>

                    {error && <p className="text-red-500 text-sm text-center">{error}</p>}

                    <button type="submit" className="w-full bg-brand-gradient text-white py-3 rounded-lg font-semibold transition-colors">
                        {isLogin ? 'Log In' : 'Create Account'}
                    </button>
                </form>

                <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-6">
                    {isLogin ? "Don't have an account?" : 'Already have an account?'}
                    <button onClick={() => { setIsLogin(!isLogin); setError('') }} className="font-semibold text-brand hover:underline ml-1">
                        {isLogin ? 'Sign up' : 'Log in'}
                    </button>
                </p>
            </div>
        </div>
    );
};

export default AuthView;