import React from 'react';
import { Achievement } from '../../types';
import { HiLockClosed as LockClosedIcon } from 'react-icons/hi2';

interface AchievementCardProps {
    achievement: Achievement;
    isLocked: boolean;
    index: number;
}

const AchievementCard: React.FC<AchievementCardProps> = ({ achievement, isLocked, index }) => {
    return (
        <div 
            className={`liquid-glass rounded-2xl p-6 transition-all duration-300 ${isLocked ? 'filter grayscale opacity-60' : 'interactive-glass cursor-pointer'} animate-slide-in-up`}
            style={{ animationDelay: `${index * 50}ms`}}
        >
            <div className="flex items-center space-x-4">
                <div className="text-5xl bg-black/5 dark:bg-black/20 rounded-full w-20 h-20 flex items-center justify-center flex-shrink-0 relative">
                    {achievement.icon}
                    {isLocked && (
                        <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center">
                            <LockClosedIcon className="w-8 h-8 text-white" />
                        </div>
                    )}
                </div>
                <div>
                    <h4 className="text-lg font-bold text-slate-800 dark:text-slate-100">{achievement.title}</h4>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{achievement.description}</p>
                </div>
            </div>
        </div>
    );
};

export default AchievementCard;