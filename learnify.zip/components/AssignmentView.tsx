import React, { useState, useEffect, useRef } from 'react';
import { Assignment } from '../types';
import { useAppContext } from '../hooks/useAppContext';
import { HiPencil, HiTrash, HiClock, HiSparkles, HiDocumentText, HiOutlinePencilSquare } from 'react-icons/hi2';
import AssignmentModal from './modals/AssignmentModal';
import RichTextEditor from './assignment/RichTextEditor';
import AIAssistant from './assignment/AIAssistant';
import CheckCircleIcon from './icons/CheckCircleIcon';

type Tab = 'editor' | 'rough-work' | 'ai-assistant';

const AssignmentView: React.FC<{ assignment: Assignment }> = ({ assignment }) => {
    const { courses, deleteAssignment, updateAssignment, logTimeForAssignment, completeAssignment } = useAppContext();
    const [activeTab, setActiveTab] = useState<Tab>('editor');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    const [roughWork, setRoughWork] = useState(assignment.roughWork);
    const [editorContent, setEditorContent] = useState(assignment.editorContent);

    // Time Tracking
    const [isTimerActive, setIsTimerActive] = useState(false);
    const [displayTime, setDisplayTime] = useState(assignment.timeSpent);
    const sessionStartTimeRef = useRef<number | null>(null);

    const course = courses.find(c => c.id === assignment.courseId);

    // Debounced saving for text areas
    useEffect(() => {
        const handler = setTimeout(() => {
            if (roughWork !== assignment.roughWork) {
                updateAssignment(assignment.id, { roughWork });
            }
        }, 1000);
        return () => clearTimeout(handler);
    }, [roughWork, assignment.roughWork, assignment.id, updateAssignment]);

    useEffect(() => {
        const handler = setTimeout(() => {
            if (editorContent !== assignment.editorContent) {
                updateAssignment(assignment.id, { editorContent });
            }
        }, 1000);
        return () => clearTimeout(handler);
    }, [editorContent, assignment.editorContent, assignment.id, updateAssignment]);

    // Sync display time if the underlying data changes
    useEffect(() => {
        setDisplayTime(assignment.timeSpent);
    }, [assignment.timeSpent, assignment.id]);

    // Timer logic for visual updates and efficient saving
    useEffect(() => {
        let intervalId: number | undefined;

        if (isTimerActive) {
            sessionStartTimeRef.current = Date.now();
            intervalId = window.setInterval(() => {
                if (sessionStartTimeRef.current) {
                    const elapsed = Math.floor((Date.now() - sessionStartTimeRef.current) / 1000);
                    setDisplayTime(assignment.timeSpent + elapsed);
                }
            }, 1000);
        }

        // Cleanup function runs when timer is stopped OR component unmounts
        return () => {
            clearInterval(intervalId);
            if (sessionStartTimeRef.current) { // A session was active
                const elapsedSeconds = Math.floor((Date.now() - sessionStartTimeRef.current) / 1000);
                if (elapsedSeconds > 0) {
                    logTimeForAssignment(assignment.id, elapsedSeconds);
                }
                sessionStartTimeRef.current = null; // Reset session
            }
        };
    }, [isTimerActive, assignment.id, assignment.timeSpent, logTimeForAssignment]);


    const handleDelete = () => {
        if (window.confirm(`Are you sure you want to delete the assignment "${assignment.title}"?`)) {
            setIsDeleting(true);
        }
    };
    
    useEffect(() => {
        if (isDeleting) {
            const timer = setTimeout(() => deleteAssignment(assignment.id), 300);
            return () => clearTimeout(timer);
        }
    }, [isDeleting, assignment.id, deleteAssignment]);

    const formatTime = (seconds: number) => {
        const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
        const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
        const s = (seconds % 60).toString().padStart(2, '0');
        return `${h}:${m}:${s}`;
    };

    const TabButton: React.FC<{ tabId: Tab, label: string, icon: React.ReactNode }> = ({ tabId, label, icon }) => (
        <button
            onClick={() => setActiveTab(tabId)}
            className={`flex items-center justify-center sm:justify-start space-x-2 px-3 py-2 text-sm font-medium rounded-md transition-all duration-200 w-full ${
                activeTab === tabId
                    ? 'bg-brand-gradient text-white shadow-md'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
            }`}
        >
            {icon}
            <span className="hidden sm:inline">{label}</span>
        </button>
    );

    return (
        <div className={isDeleting ? 'animate-modal-out' : ''}>
            <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4 gap-4">
                <div>
                    <p className="text-sm text-brand font-semibold">{course?.title}</p>
                    <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">{assignment.title}</h2>
                    {assignment.dueDate && <p className="text-slate-500 dark:text-slate-400 mt-1">Due: {new Date(assignment.dueDate + 'T00:00:00').toLocaleDateString()}</p>}
                </div>
                <div className="flex items-center space-x-2 self-start sm:self-center">
                    {assignment.isCompleted ? (
                        <div className="flex items-center space-x-2 px-3 py-2 text-sm font-semibold text-green-700 bg-green-100 dark:text-green-200 dark:bg-green-500/20 rounded-lg">
                            <CheckCircleIcon className="w-5 h-5" />
                            <span>Completed</span>
                        </div>
                    ) : (
                        <button 
                            onClick={() => completeAssignment(assignment.id)} 
                            className="flex items-center space-x-2 px-3 py-2 text-sm font-semibold text-green-700 bg-green-100 dark:text-green-200 dark:bg-green-500/20 rounded-lg hover:bg-green-200 dark:hover:bg-green-500/30 transition-colors"
                        >
                            <CheckCircleIcon className="w-5 h-5" />
                            <span>Mark as Complete</span>
                        </button>
                    )}
                     <div className="liquid-glass rounded-lg p-2 flex items-center space-x-2">
                        <HiClock className="w-5 h-5 text-brand" />
                        <span className="font-mono font-semibold">{formatTime(displayTime)}</span>
                        <button
                            onClick={() => setIsTimerActive(!isTimerActive)}
                            disabled={assignment.isCompleted}
                            className={`px-3 py-1 text-xs font-bold rounded ${isTimerActive ? 'bg-red-500 text-white' : 'bg-green-500 text-white'} disabled:opacity-50 disabled:cursor-not-allowed`}
                        >
                            {isTimerActive ? 'STOP' : 'START'}
                        </button>
                    </div>
                    <button onClick={() => setIsModalOpen(true)} disabled={assignment.isCompleted} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed"><HiPencil className="w-5 h-5"/></button>
                    <button onClick={handleDelete} className="p-2 rounded-full text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50"><HiTrash className="w-5 h-5"/></button>
                </div>
            </div>

            <div className="flex flex-col lg:flex-row gap-6">
                <div className="lg:w-1/4">
                     <div className="sticky top-20 flex flex-row lg:flex-col gap-2 p-2 liquid-glass rounded-lg">
                        <TabButton tabId="editor" label="Text Editor" icon={<HiOutlinePencilSquare className="w-5 h-5"/>} />
                        <TabButton tabId="rough-work" label="Rough Work" icon={<HiDocumentText className="w-5 h-5"/>} />
                        <TabButton tabId="ai-assistant" label="AI Assistant" icon={<HiSparkles className="w-5 h-5"/>} />
                    </div>
                </div>
                <div className="lg:w-3/4 liquid-glass p-1 rounded-2xl min-h-[70vh]">
                    <div className="bg-white dark:bg-slate-900 rounded-xl h-full p-4">
                        {activeTab === 'editor' && <RichTextEditor content={editorContent} onChange={setEditorContent} />}
                        {activeTab === 'rough-work' && (
                            <textarea
                                value={roughWork}
                                onChange={(e) => setRoughWork(e.target.value)}
                                placeholder="Use this space for brainstorming, outlines, and quick notes. Your work is saved automatically."
                                className="w-full h-full p-2 bg-transparent focus:outline-none resize-none"
                            />
                        )}
                        {activeTab === 'ai-assistant' && <AIAssistant assignmentContext={editorContent} />}
                    </div>
                </div>
            </div>

            <AssignmentModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} assignment={assignment} />
        </div>
    );
};

export default AssignmentView;