import React from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { HiSparkles } from 'react-icons/hi2';

const xpForNextLevel = (level: number) => 50 + level * 50;

const XPBar: React.FC = () => {
    const { userData } = useAppContext();
    const { level, xp } = userData;

    const neededXp = xpForNextLevel(level);
    const progress = (xp / neededXp) * 100;

    return (
        <div className="w-24 sm:w-48">
            <div className="flex justify-between items-center text-xs mb-1">
                <span className="font-bold text-slate-700 dark:text-slate-200">Lvl {level}</span>
                <span className="hidden sm:inline font-semibold text-slate-500 dark:text-slate-400">{xp} / {neededXp} XP</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 progress-bar-container">
                <div className="bg-brand-gradient h-2.5 rounded-full flex items-center justify-end" style={{ width: `${progress}%`, transition: 'width 0.5s var(--ease-premium)' }}>
                     <HiSparkles className="w-3 h-3 text-white/80 mr-1" />
                </div>
            </div>
        </div>
    );
};

export default XPBar;