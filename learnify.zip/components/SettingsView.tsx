import React, { useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { HiCog6Tooth as Cog6ToothIcon } from 'react-icons/hi2';

const SettingsView: React.FC = () => {
    const { userData, updateUserProfile } = useAppContext();

    const [name, setName] = useState(userData.name || '');
    const [age, setAge] = useState(userData.age?.toString() || '');
    const [schoolingLevel, setSchoolingLevel] = useState(userData.schoolingLevel || '');
    const [interests, setInterests] = useState(userData.interests?.join(', ') || '');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        const ageNum = parseInt(age, 10);

        if (!name.trim() || !age.trim() || !schoolingLevel) {
            setError('Please fill out all required fields.');
            return;
        }
        if (isNaN(ageNum) || ageNum <= 5 || ageNum > 100) {
            setError('Please enter a valid age.');
            return;
        }

        updateUserProfile({ name, age: ageNum, schoolingLevel, interests });
        setSuccess('Profile updated successfully!');
        setTimeout(() => setSuccess(''), 3000);
    };

    const schoolingOptions = [
        "Middle School", "High School", "Undergraduate", "Graduate",
        "Post-graduate", "Professional", "Self-taught",
    ];

    return (
        <div className="space-y-8 animate-slide-in max-w-2xl mx-auto">
            <div>
                <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center">
                    <Cog6ToothIcon className="w-8 h-8 mr-3 text-brand" />
                    Settings
                </h2>
                <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">
                    Manage your profile and account settings.
                </p>
            </div>

            <div className="liquid-glass rounded-2xl p-8">
                 <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Name</label>
                        <input type="text" id="name" value={name} onChange={e => setName(e.target.value)}
                            className="w-full p-3 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600" required />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="age" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Age</label>
                            <input type="number" id="age" value={age} onChange={e => setAge(e.target.value)}
                                className="w-full p-3 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600" required />
                        </div>
                        <div>
                            <label htmlFor="schoolingLevel" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Schooling Level</label>
                            <select id="schoolingLevel" value={schoolingLevel} onChange={e => setSchoolingLevel(e.target.value)}
                                className="w-full p-3 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600" required>
                                <option value="" disabled>Select a level...</option>
                                {schoolingOptions.map(option => <option key={option} value={option}>{option}</option>)}
                            </select>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="interests" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Interests</label>
                        <textarea id="interests" value={interests} onChange={e => setInterests(e.target.value)}
                            className="w-full p-3 border rounded-md bg-white dark:bg-slate-900 dark:border-slate-600" rows={3} />
                        <p className="text-xs text-slate-400 mt-1">Separate interests with a comma.</p>
                    </div>

                    {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                    {success && <p className="text-green-500 text-sm text-center">{success}</p>}

                    <div className="flex justify-end">
                        <button type="submit" className="bg-brand-gradient text-white py-2 px-6 rounded-lg font-semibold">
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default SettingsView;