
import React, { useState, useMemo, useCallback, useEffect, useRef } from 'react';
// FIX: Added NotificationType to import to resolve type error.
import { AppContextType, Course, Lesson, ViewState, View, UserData, Achievement, UserAccount, FriendRequest, Notification, ChatMessage, CalendarEvent, MoodLog, JournalEntry, StudyBreakSettings, Assignment, LevelUpInfo, SearchResult, NotificationType } from './types';
import { defaultUserData, mockAchievements } from './data';
import Dashboard from './components/Dashboard';
import CourseView from './components/CourseView';
import LessonView from './components/LessonView';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import AchievementPopup from './components/gamification/AchievementPopup';
import AuthView from './components/AuthView';
import OnboardingView from './components/OnboardingView';
import CalendarView from './components/CalendarView';
import AchievementsView from './components/AchievementsView';
import MentalHealthView from './components/MentalHealthView';
import ProfileView from './components/ProfileView';
import SettingsView from './components/SettingsView';
import ResearchView from './components/ResearchView';
import CommunityView from './components/CommunityView';
import AssignmentView from './components/AssignmentView';
import LevelUpPopup from './components/gamification/LevelUpPopup';
import XPToast from './components/gamification/XPToast';
import SearchResultsView from './components/SearchResultsView';
import NotificationPanel from './components/NotificationPanel';

export const AppContext = React.createContext<AppContextType | null>(null);

// In a real app, this would be a secure backend. We use localStorage for simulation.
const APP_STORAGE_KEY = 'learnify-app-users';

const xpForNextLevel = (level: number) => 50 + level * 50;

const App: React.FC = () => {
    const [allUsersData, setAllUsersData] = useState<Record<string, UserAccount>>(() => {
        try {
            const data = window.localStorage.getItem(APP_STORAGE_KEY);
            return data ? JSON.parse(data) : {};
        } catch (error)
        {
            console.error("Failed to parse user data from localStorage", error);
            return {};
        }
    });

    const [currentUser, setCurrentUser] = useState<string | null>(null); // Store user email
    const [showOnboarding, setShowOnboarding] = useState<boolean>(false);

    const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
        if (typeof window !== 'undefined') {
            return window.matchMedia('(prefers-color-scheme: dark)').matches;
        }
        return false;
    });

    const [viewState, setViewState] = useState<ViewState>({ view: View.DASHBOARD, courseId: null, lessonId: null, assignmentId: null });
    const [achievementQueue, setAchievementQueue] = useState<Achievement[]>([]);
    const [currentAchievement, setCurrentAchievement] = useState<Achievement | null>(null);
    const [levelUpInfo, setLevelUpInfo] = useState<LevelUpInfo | null>(null);
    const [isLevelUpPopupOpen, setIsLevelUpPopupOpen] = useState(false);
    const [xpToast, setXpToast] = useState<{ amount: number, reason: string } | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [isNotificationPanelOpen, setIsNotificationPanelOpen] = useState(false);

    const completedCourseIds = useRef(new Set<string>());
    const studyTimerRef = useRef<number | null>(null);
    
    // Persist all user data to localStorage whenever it changes
    useEffect(() => {
        try {
            window.localStorage.setItem(APP_STORAGE_KEY, JSON.stringify(allUsersData));
        } catch (error) {
            console.error("Failed to save user data to localStorage", error);
        }
    }, [allUsersData]);

    useEffect(() => {
        if (isDarkMode) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    }, [isDarkMode]);

    const currentUserData = useMemo(() => {
        if (!currentUser || !allUsersData[currentUser]) {
            return { courses: [], userData: defaultUserData };
        }
        return {
            courses: allUsersData[currentUser].courses,
            userData: allUsersData[currentUser].userData,
        };
    }, [currentUser, allUsersData]);


    // Update completed courses ref when user data changes
    useEffect(() => {
        completedCourseIds.current = new Set(
            currentUserData.courses.filter(c => c.lessons.every(l => l.mastery === 100)).map(c => c.id)
        );
    }, [currentUserData.courses]);
    
    // Helper to update current user's data
    const updateCurrentUserAccount = useCallback((updater: (account: UserAccount) => UserAccount) => {
        if (!currentUser) return;
        setAllUsersData(prev => {
            const currentAccount = prev[currentUser];
            if (!currentAccount) {
                console.error("Attempted to update non-existent user account:", currentUser);
                return prev;
            }
            return {
                ...prev,
                [currentUser]: updater(currentAccount)
            };
        });
    }, [currentUser]);

    const navigate = useCallback((view: View, courseId: string | null = null, lessonId: string | null = null, assignmentId: string | null = null) => {
        setViewState({ view, courseId, lessonId, assignmentId });
         window.scrollTo(0, 0);
    }, []);

    // Close notification panel on navigation
    useEffect(() => {
        if (isNotificationPanelOpen) {
            setIsNotificationPanelOpen(false);
        }
    }, [viewState]);
    
    const toggleSidebar = useCallback(() => {
        updateCurrentUserAccount(account => ({
            ...account,
            userData: {
                ...account.userData,
                isSidebarOpen: !account.userData.isSidebarOpen,
            }
        }));
    }, [updateCurrentUserAccount]);

    // --- Study Break Notification ---
    useEffect(() => {
        const { studyBreakSettings } = currentUserData.userData;
        
        const createBreakNotification = () => {
            const newNotification: Omit<Notification, 'id' | 'isRead'> = {
                type: 'BREAK_REMINDER',
                message: "Time for a short break! Stretch, drink some water, or do a breathing exercise.",
                timestamp: Date.now(),
            };
            updateCurrentUserAccount(account => ({
                ...account,
                userData: {
                    ...account.userData,
                    notifications: [{ ...newNotification, id: `notif-break-${Date.now()}`, isRead: false }, ...account.userData.notifications]
                }
            }));
        };
        
        // Clear any existing timer when settings change or user logs out
        if (studyTimerRef.current) {
            clearTimeout(studyTimerRef.current);
            studyTimerRef.current = null;
        }

        if (viewState.view === View.LESSON && studyBreakSettings?.enabled) {
            studyTimerRef.current = window.setTimeout(createBreakNotification, studyBreakSettings.interval * 60 * 1000);
        }

        return () => {
            if (studyTimerRef.current) {
                clearTimeout(studyTimerRef.current);
            }
        };
    }, [viewState, currentUserData.userData.studyBreakSettings, updateCurrentUserAccount]);


    // --- Calendar Notification Generation ---
    useEffect(() => {
        if (!currentUser) return;

        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(today.getDate() + 1);

        const formatDate = (date: Date) => date.toISOString().split('T')[0];
        const todayStr = formatDate(today);
        const tomorrowStr = formatDate(tomorrow);

        const upcomingEvents = currentUserData.userData.events.filter(event => 
            event.date === todayStr || event.date === tomorrowStr
        );
        
        const newNotifications: Notification[] = [];
        const existingNotifIds = new Set(currentUserData.userData.notifications.map(n => n.id));

        upcomingEvents.forEach(event => {
            const notifId = `notif-cal-${event.id}-${event.date}`;
            if (!existingNotifIds.has(notifId)) {
                const isToday = event.date === todayStr;
                newNotifications.push({
                    id: notifId,
                    type: 'CALENDAR_REMINDER',
                    message: `${isToday ? 'Today' : 'Tomorrow'}: ${event.title}${event.time ? ` at ${event.time}` : ''}${event.location ? ` (${event.location})` : ''}`,
                    relatedId: event.id,
                    isRead: false,
                    timestamp: Date.now(),
                });
            }
        });

        if (newNotifications.length > 0) {
            updateCurrentUserAccount(account => ({
                ...account,
                userData: {
                    ...account.userData,
                    notifications: [...newNotifications, ...account.userData.notifications]
                }
            }));
        }

    }, [currentUser, currentUserData.userData.events, updateCurrentUserAccount]);


    // --- Auth & Onboarding Management ---
    const signup = useCallback((email: string, pass: string): boolean => {
        if (allUsersData[email]) {
            alert("An account with this email already exists.");
            return false;
        }
        const newUser: UserAccount = {
            email,
            pass,
            courses: [],
            userData: { ...defaultUserData, name: email.split('@')[0] }
        };
        setAllUsersData(prev => ({ ...prev, [email]: newUser }));
        setCurrentUser(email);
        setShowOnboarding(true);
        setViewState({ view: View.DASHBOARD, courseId: null, lessonId: null });
        return true;
    }, [allUsersData]);

    const login = useCallback((identifier: string, pass: string): boolean => {
        const identifierLower = identifier.toLowerCase();
        // Fix: Cast Object.values result to UserAccount[] to ensure type safety.
        const userAccount = (Object.values(allUsersData) as UserAccount[]).find(
            (acc) => acc.email.toLowerCase() === identifierLower || acc.userData.username?.toLowerCase() === identifierLower
        );

        if (userAccount && userAccount.pass === pass) {
            setCurrentUser(userAccount.email);
            setViewState({ view: View.DASHBOARD, courseId: null, lessonId: null });
            if (!userAccount.userData.age || !userAccount.userData.username) { // Check if onboarding was completed
                setShowOnboarding(true);
            } else {
                setShowOnboarding(false);
            }
            return true;
        }
        alert("Invalid credentials.");
        return false;
    }, [allUsersData]);

    const logout = useCallback(() => {
        setCurrentUser(null);
        setShowOnboarding(false);
    }, []);
    
    const completeOnboarding = useCallback(async (details: { name: string; age: number; schoolingLevel: string; interests: string; username: string; }): Promise<boolean> => {
        if (!currentUser) return false;

        // Validate username uniqueness
        // Fix: Cast Object.values result to UserAccount[] to ensure type safety.
        const usernameTaken = (Object.values(allUsersData) as UserAccount[]).some(
            (acc) => acc.userData.username?.toLowerCase() === details.username.toLowerCase()
        );

        if (usernameTaken) {
            return false;
        }

        updateCurrentUserAccount(account => {
            const interestsArray = details.interests.split(',').map(i => i.trim()).filter(Boolean);
            const updatedUserData: UserData = {
                ...account.userData,
                name: details.name,
                age: details.age,
                schoolingLevel: details.schoolingLevel,
                interests: interestsArray,
                username: details.username,
            };
            return { ...account, userData: updatedUserData };
        });

        setShowOnboarding(false);
        return true;
    }, [currentUser, updateCurrentUserAccount, allUsersData]);
    
    const updateUserProfile = useCallback((details: { name: string; age: number; schoolingLevel: string; interests: string }) => {
        if (!currentUser) return;
        updateCurrentUserAccount(account => {
            const interestsArray = details.interests.split(',').map(i => i.trim()).filter(Boolean);
            const updatedUserData: UserData = {
                ...account.userData,
                name: details.name,
                age: details.age,
                schoolingLevel: details.schoolingLevel,
                interests: interestsArray,
            };
            return { ...account, userData: updatedUserData };
        });
    }, [currentUser, updateCurrentUserAccount]);

    // --- XP & Gamification System ---
    const addXp = useCallback((amount: number, reason: string) => {
        if (!currentUser || amount <= 0) return;
        setXpToast({ amount, reason });
        
        updateCurrentUserAccount(account => {
            let currentXp = account.userData.xp + amount;
            let currentLevel = account.userData.level;
            let xpNeeded = xpForNextLevel(currentLevel);
            let hasLeveledUp = false;
            let newNotifications = [...account.userData.notifications];

            while (currentXp >= xpNeeded) {
                currentXp -= xpNeeded;
                currentLevel += 1;
                xpNeeded = xpForNextLevel(currentLevel);
                hasLeveledUp = true;
            }

            if (hasLeveledUp) {
                setLevelUpInfo({ oldLevel: account.userData.level, newLevel: currentLevel });
                setIsLevelUpPopupOpen(true);
                newNotifications.unshift({
                    id: `notif-levelup-${Date.now()}`,
                    type: 'LEVEL_UP',
                    message: `Congratulations! You've reached Level ${currentLevel}!`,
                    isRead: false,
                    timestamp: Date.now(),
                });
            }

            return {
                ...account,
                userData: { ...account.userData, xp: currentXp, level: currentLevel, notifications: newNotifications }
            };
        });
    }, [currentUser, updateCurrentUserAccount]);

    const unlockAchievement = useCallback((achievementId: string) => {
        if (!currentUser) return;
        
        updateCurrentUserAccount(account => {
            if (account.userData.unlockedAchievements.includes(achievementId)) {
                return account;
            }
            const achievement = mockAchievements.find(a => a.id === achievementId);
            if (achievement) {
                setAchievementQueue(q => [...q, achievement]);
                addXp(15, 'Achievement Unlocked!');

                const newNotification: Notification = {
                    id: `notif-achieve-${achievementId}`,
                    type: 'ACHIEVEMENT_UNLOCKED',
                    message: `Achievement Unlocked: ${achievement.title}`,
                    isRead: false,
                    timestamp: Date.now(),
                };

                return {
                    ...account,
                    userData: {
                        ...account.userData,
                        unlockedAchievements: [...account.userData.unlockedAchievements, achievementId],
                        notifications: [newNotification, ...account.userData.notifications]
                    }
                };
            }
            return account;
        });
    }, [currentUser, updateCurrentUserAccount, addXp]);

    useEffect(() => {
        if (achievementQueue.length > 0 && !currentAchievement) {
            const [first, ...rest] = achievementQueue;
            setCurrentAchievement(first);
            setAchievementQueue(rest);
        }
    }, [achievementQueue, currentAchievement]);

    const handlePopupClosed = () => {
        setCurrentAchievement(null);
    };

    const updateLessonMastery = useCallback((courseId: string, lessonId: string, newMastery: number) => {
        updateCurrentUserAccount(account => {
            const newCourses = account.courses.map(course => {
                if (course.id === courseId) {
                    const newLessons = course.lessons.map(lesson => {
                        if (lesson.id === lessonId && newMastery > lesson.mastery) {
                            return { ...lesson, mastery: Math.min(100, newMastery) };
                        }
                        return lesson;
                    });
                    return { ...course, lessons: newLessons };
                }
                return course;
            });
            return { ...account, courses: newCourses };
        });
    }, [updateCurrentUserAccount]);

    const updateLessonResources = useCallback((courseId: string, lessonId: string, resources: { content?: string; notes?: string; files?: { name: string; type: string; }[] }) => {
        updateCurrentUserAccount(account => {
            let userData = account.userData;
            const newAchievements: Achievement[] = [];

            const newCourses = account.courses.map(course => {
                if (course.id === courseId) {
                    const newLessons = course.lessons.map(lesson => {
                        if (lesson.id === lessonId) {
                            
                            // Note Taker achievement
                            if (resources.notes && resources.notes.trim().length > 0 && (!lesson.userNotes || lesson.userNotes.trim().length === 0) && !userData.unlockedAchievements.includes('note-taker')) {
                                const ach = mockAchievements.find(a => a.id === 'note-taker');
                                if (ach) {
                                    newAchievements.push(ach);
                                    userData = { ...userData, unlockedAchievements: [...userData.unlockedAchievements, 'note-taker'] };
                                }
                            }
                            // Digital Organizer achievement
                            if (resources.files && resources.files.length > 0 && (!lesson.uploadedFiles || lesson.uploadedFiles.length === 0) && !userData.unlockedAchievements.includes('digital-organizer')) {
                                const ach = mockAchievements.find(a => a.id === 'digital-organizer');
                                if (ach) {
                                    newAchievements.push(ach);
                                    userData = { ...userData, unlockedAchievements: [...userData.unlockedAchievements, 'digital-organizer'] };
                                }
                            }

                            return {
                                ...lesson,
                                content: resources.content !== undefined ? resources.content : lesson.content,
                                userNotes: resources.notes !== undefined ? resources.notes : lesson.userNotes,
                                uploadedFiles: resources.files !== undefined ? resources.files : lesson.uploadedFiles,
                            };
                        }
                        return lesson;
                    });
                    return { ...course, lessons: newLessons };
                }
                return course;
            });

            if (newAchievements.length > 0) {
                setAchievementQueue(q => [...q, ...newAchievements]);
            }

            return { ...account, courses: newCourses, userData };
        });
    }, [updateCurrentUserAccount]);

    const completeLesson = useCallback((courseId: string, lessonId: string) => {
        let lessonCompletedToday = false;
        
        updateCurrentUserAccount(account => {
            let newNotifications = [...account.userData.notifications];

            const newCourses = account.courses.map(course => {
                if(course.id === courseId) {
                    const targetLesson = course.lessons.find(l => l.id === lessonId);
                    if (targetLesson && targetLesson.mastery < 100) {
                        lessonCompletedToday = true;
                        unlockAchievement('master-lesson');
                        if (account.userData.unlockedAchievements.length < 2) {
                             unlockAchievement('first-lesson');
                        }
                    }
                    return {
                        ...course,
                        lessons: course.lessons.map(lesson => lesson.id === lessonId ? {...lesson, mastery: 100} : lesson),
                    };
                }
                return course;
            });

            const updatedCourse = newCourses.find(c => c.id === courseId);
            if (updatedCourse) {
                const isNowComplete = updatedCourse.lessons.every(l => l.mastery === 100);
                const wasAlreadyComplete = completedCourseIds.current.has(courseId);
                if (isNowComplete && !wasAlreadyComplete) {
                    unlockAchievement('master-course');
                    addXp(50, 'Course Completed!');
                    completedCourseIds.current.add(courseId);
                     newNotifications.unshift({
                        id: `notif-course-complete-${courseId}`,
                        type: 'COURSE_COMPLETE',
                        message: `You've mastered the "${updatedCourse.title}" course!`,
                        isRead: false,
                        timestamp: Date.now(),
                    });
                }
            }

            let newUserData = account.userData;
            if (lessonCompletedToday) {
                 const today = new Date().toDateString();
                 let newStreak = account.userData.streak;
                 if(account.userData.lastLessonCompletedDate !== today) {
                    newStreak = account.userData.streak + 1;
                    if (newStreak === 3) unlockAchievement('streak-3');
                    if (newStreak === 7) unlockAchievement('streak-7');

                    if ([3, 7, 14, 30].includes(newStreak)) {
                        newNotifications.unshift({
                            id: `notif-streak-${newStreak}-${Date.now()}`,
                            type: 'STREAK_MILESTONE',
                            message: `You're on a ${newStreak}-day streak! Keep it up!`,
                            isRead: false,
                            timestamp: Date.now(),
                        });
                    }
                 }
                 newUserData = {
                    ...account.userData,
                    streak: newStreak,
                    lastLessonCompletedDate: today,
                }
            }

            return { ...account, courses: newCourses, userData: { ...newUserData, notifications: newNotifications } };
        });
    }, [unlockAchievement, updateCurrentUserAccount, addXp]);

    // --- Course Management ---
    const addCourse = useCallback((course: { title: string; description: string }) => {
        const newCourse: Course = {
            id: `course-${Date.now()}`,
            title: course.title,
            description: course.description,
            lessons: [],
        };
        updateCurrentUserAccount(account => {
            const courses = [...account.courses, newCourse];
            let userData = account.userData;
            const newAchievements: Achievement[] = [];

            if (courses.length === 1 && !userData.unlockedAchievements.includes('avid-learner')) {
                const ach = mockAchievements.find(a => a.id === 'avid-learner');
                if (ach) {
                    newAchievements.push(ach);
                    userData = { ...userData, unlockedAchievements: [...userData.unlockedAchievements, 'avid-learner'] };
                }
            }
            if (courses.length === 3 && !userData.unlockedAchievements.includes('curriculum-developer')) {
                const ach = mockAchievements.find(a => a.id === 'curriculum-developer');
                if (ach) {
                    newAchievements.push(ach);
                    userData = { ...userData, unlockedAchievements: [...userData.unlockedAchievements, 'curriculum-developer'] };
                }
            }

            if (newAchievements.length > 0) {
                setAchievementQueue(q => [...q, ...newAchievements]);
            }

            return { ...account, courses, userData };
        });
    }, [updateCurrentUserAccount]);

    const updateCourse = useCallback((courseId: string, course: { title: string; description: string }) => {
        updateCurrentUserAccount(account => ({
            ...account,
            courses: account.courses.map(c => c.id === courseId ? { ...c, ...course } : c)
        }));
    }, [updateCurrentUserAccount]);

    const deleteCourse = useCallback((courseId: string) => {
        if (!currentUser) return;
        setAllUsersData(prev => {
            const account = prev[currentUser];
            if (!account) return prev;
            const updatedAccount = {
                ...account,
                courses: account.courses.filter(c => c.id !== courseId),
                userData: {
                    ...account.userData,
                    events: account.userData.events.filter(e => e.courseId !== courseId),
                    assignments: account.userData.assignments.filter(a => a.courseId !== courseId),
                }
            };
            return { ...prev, [currentUser]: updatedAccount };
        });
        navigate(View.DASHBOARD);
    }, [currentUser, navigate]);

    // --- Lesson Management ---
    const addLesson = useCallback((courseId: string, lesson: { title: string }) => {
        const newLesson: Lesson = {
            id: `lesson-${Date.now()}`,
            title: lesson.title,
            content: 'Add your lesson content here. You can paste notes, write summaries, or upload files.',
            mastery: 0,
            userNotes: '',
            uploadedFiles: [],
        };
        updateCurrentUserAccount(account => ({
            ...account,
            courses: account.courses.map(c => c.id === courseId ? { ...c, lessons: [...c.lessons, newLesson] } : c)
        }));
    }, [updateCurrentUserAccount]);

    const updateLesson = useCallback((courseId: string, lessonId: string, lesson: { title: string }) => {
        updateCurrentUserAccount(account => ({
            ...account,
            courses: account.courses.map(c => c.id === courseId ? { ...c, lessons: c.lessons.map(l => l.id === lessonId ? { ...l, ...lesson } : l) } : c)
        }));
    }, [updateCurrentUserAccount]);

    const deleteLesson = useCallback((courseId: string, lessonId: string) => {
        if (!currentUser) return;
        setAllUsersData(prev => {
            const account = prev[currentUser];
            if (!account) return prev;
            const updatedAccount = {
                ...account,
                courses: account.courses.map(c =>
                    c.id === courseId
                        ? { ...c, lessons: c.lessons.filter(l => l.id !== lessonId) }
                        : c
                )
            };
            return { ...prev, [currentUser]: updatedAccount };
        });

        if (viewState.view === View.LESSON && viewState.lessonId === lessonId) {
            navigate(View.COURSE, courseId);
        }
    }, [currentUser, navigate, viewState.view, viewState.lessonId]);

    // Fix: Moved Calendar Management functions before Assignment Management to fix hoisting issues.
    // --- Calendar Management ---
    const addEvent = useCallback((event: Omit<CalendarEvent, 'id'>): CalendarEvent => {
        const newEvent: CalendarEvent = {
            id: `event-${Date.now()}`,
            ...event,
        };
        updateCurrentUserAccount(account => ({
            ...account,
            userData: {
                ...account.userData,
                events: [...account.userData.events, newEvent].sort((a, b) => a.date.localeCompare(b.date) || (a.time || '').localeCompare(b.time || ''))
            }
        }));
        return newEvent;
    }, [updateCurrentUserAccount]);

    const updateEvent = useCallback((eventId: string, event: Omit<CalendarEvent, 'id' | 'assignmentId'>) => {
        updateCurrentUserAccount(account => ({
            ...account,
            userData: {
                ...account.userData,
                events: account.userData.events.map(e => e.id === eventId ? { ...e, ...event, id: eventId } : e)
                    .sort((a, b) => a.date.localeCompare(b.date) || (a.time || '').localeCompare(b.time || ''))
            }
        }));
    }, [updateCurrentUserAccount]);

    const deleteEvent = useCallback((eventId: string) => {
        if (!currentUser) return;
        setAllUsersData(prev => {
            const account = prev[currentUser];
            if (!account) return prev;
            
            // Also need to remove calendarEventId from any associated assignment
            const assignments = account.userData.assignments.map(a => {
                if (a.calendarEventId === eventId) {
                    return { ...a, calendarEventId: undefined, dueDate: null };
                }
                return a;
            });
            
            const updatedAccount = {
                ...account,
                userData: {
                    ...account.userData,
                    assignments,
                    events: account.userData.events.filter(e => e.id !== eventId)
                }
            };
            return { ...prev, [currentUser]: updatedAccount };
        });
    }, [currentUser]);

    // --- Assignment Management ---
    const addAssignment = useCallback((assignment: Omit<Assignment, 'id' | 'timeSpent' | 'roughWork' | 'editorContent' | 'calendarEventId' | 'isCompleted'>) => {
        updateCurrentUserAccount(account => {
            const newAssignment: Assignment = {
                id: `assign-${Date.now()}`,
                ...assignment,
                timeSpent: 0,
                roughWork: '',
                editorContent: '',
                isCompleted: false,
            };
            
            let newEvents = account.userData.events;
            if (newAssignment.dueDate) {
                // Fix: Use `account.courses` which is in scope of the updater function.
                const event = addEvent({
                    title: `Due: ${newAssignment.title}`,
                    description: `Assignment for ${account.courses.find(c => c.id === newAssignment.courseId)?.title || 'course'}`,
                    date: newAssignment.dueDate,
                    courseId: newAssignment.courseId,
                    assignmentId: newAssignment.id
                });
                newAssignment.calendarEventId = event.id;
                newEvents = [...newEvents, event];
            }
            
            return {
                ...account,
                userData: {
                    ...account.userData,
                    assignments: [...account.userData.assignments, newAssignment],
                    events: newEvents,
                }
            };
        });
    // Fix: Remove `courses` from dependency array as it's not in scope; `account.courses` is used instead.
    }, [updateCurrentUserAccount, addEvent]);

    const updateAssignment = useCallback((assignmentId: string, updates: Partial<Omit<Assignment, 'id' | 'timeSpent'>>) => {
        updateCurrentUserAccount(account => {
            const assignments = [...account.userData.assignments];
            const assignmentIndex = assignments.findIndex(a => a.id === assignmentId);
            if (assignmentIndex === -1) return account;

            const oldAssignment = assignments[assignmentIndex];
            const updatedAssignment = { ...oldAssignment, ...updates };
            assignments[assignmentIndex] = updatedAssignment;
            let events = [...account.userData.events];

            // Calendar Sync Logic
            // Fix: Use `account.courses` which is in scope of the updater function.
            const courseTitle = account.courses.find(c => c.id === updatedAssignment.courseId)?.title || 'course';
            const eventPayload = {
                title: `Due: ${updatedAssignment.title}`,
                description: `Assignment for ${courseTitle}`,
                date: updatedAssignment.dueDate!,
                courseId: updatedAssignment.courseId,
            };

            if (updates.dueDate !== oldAssignment.dueDate) {
                // If there was an old event, remove or update it
                if (oldAssignment.calendarEventId) {
                    if (updatedAssignment.dueDate) { // Due date changed
                        updateEvent(oldAssignment.calendarEventId, eventPayload);
                    } else { // Due date removed
                        deleteEvent(oldAssignment.calendarEventId);
                        updatedAssignment.calendarEventId = undefined;
                        events = events.filter(e => e.id !== oldAssignment.calendarEventId);
                    }
                } else if (updatedAssignment.dueDate) { // Due date added
                    const newEvent = addEvent({ ...eventPayload, assignmentId: updatedAssignment.id });
                    updatedAssignment.calendarEventId = newEvent.id;
                    events.push(newEvent);
                }
            } else if (updates.title || updates.courseId) {
                 // If title/course changes, update existing event
                if (updatedAssignment.calendarEventId && updatedAssignment.dueDate) {
                    updateEvent(updatedAssignment.calendarEventId, eventPayload);
                }
            }

            return { ...account, userData: { ...account.userData, assignments, events }};
        });
    // Fix: Remove `courses` from dependency array as it's not in scope; `account.courses` is used instead.
    }, [updateCurrentUserAccount, addEvent, updateEvent, deleteEvent]);


    const deleteAssignment = useCallback((assignmentId: string) => {
        if (!currentUser) return;
        setAllUsersData(prev => {
            const account = prev[currentUser];
            if (!account) return prev;
            
            const assignmentToDelete = account.userData.assignments.find(a => a.id === assignmentId);
            let updatedEvents = account.userData.events;
            if (assignmentToDelete?.calendarEventId) {
                updatedEvents = updatedEvents.filter(e => e.id !== assignmentToDelete.calendarEventId);
            }

            const updatedAccount = {
                ...account,
                userData: {
                    ...account.userData,
                    assignments: account.userData.assignments.filter(a => a.id !== assignmentId),
                    events: updatedEvents,
                }
            };
            return { ...prev, [currentUser]: updatedAccount };
        });
         if (viewState.view === View.ASSIGNMENT && viewState.assignmentId === assignmentId) {
            navigate(View.DASHBOARD);
        }
    }, [currentUser, viewState, navigate]);

    const logTimeForAssignment = useCallback((assignmentId: string, seconds: number) => {
        updateCurrentUserAccount(account => {
            const assignments = account.userData.assignments.map(a => 
                a.id === assignmentId ? { ...a, timeSpent: a.timeSpent + seconds } : a
            );
            return { ...account, userData: { ...account.userData, assignments } };
        });
    }, [updateCurrentUserAccount]);

    const completeAssignment = useCallback((assignmentId: string) => {
        updateCurrentUserAccount(account => {
            const assignments = account.userData.assignments.map(a => 
                a.id === assignmentId ? { ...a, isCompleted: true } : a
            );
            addXp(30, 'Assignment Completed');
            return { ...account, userData: { ...account.userData, assignments } };
        });
    }, [updateCurrentUserAccount, addXp]);

    // --- Social Features ---
    const getPeerSuggestions = useCallback(() => {
        if (!currentUser) return [];
        const me = allUsersData[currentUser];
        // Fix: Cast Object.values result to UserAccount[] to ensure type safety.
        return (Object.values(allUsersData) as UserAccount[]).filter((user) => {
            if (user.email === currentUser) return false;
            if (me.userData.friends.includes(user.email)) return false;
            // Check if a request is already pending between them
            const pendingRequest = me.userData.friendRequests.find(req => (req.from === user.email || req.to === user.email) && req.status === 'pending');
            if (pendingRequest) return false;

            // Simple suggestion logic: shared interests or courses
            const sharedInterests = user.userData.interests?.some(i => me.userData.interests?.includes(i));
            const userCourseTitles = new Set(user.courses.map(c => c.title));
            const sharedCourses = me.courses.some(c => userCourseTitles.has(c.title));

            return sharedInterests || sharedCourses;
        });
    }, [currentUser, allUsersData]);

    const sendFriendRequest = useCallback((recipientEmail: string) => {
        if (!currentUser) return;
        const sender = allUsersData[currentUser];

        const requestId = `req-${Date.now()}`;
        const newRequest: FriendRequest = { id: requestId, from: currentUser, to: recipientEmail, status: 'pending' };
        const newNotification: Notification = {
            id: `notif-${Date.now()}`,
            type: 'FRIEND_REQUEST',
            message: `${sender.userData.name} (@${sender.userData.username}) sent you a friend request.`,
            from: currentUser,
            relatedId: requestId,
            isRead: false,
            timestamp: Date.now()
        };

        setAllUsersData(prev => {
            const recipientAccount = prev[recipientEmail];
            if (!recipientAccount) return prev;

            const updatedRecipient = {
                ...recipientAccount,
                userData: {
                    ...recipientAccount.userData,
                    friendRequests: [...recipientAccount.userData.friendRequests, newRequest],
                    notifications: [newNotification, ...recipientAccount.userData.notifications]
                }
            };

            return { ...prev, [recipientEmail]: updatedRecipient };
        });
    }, [currentUser, allUsersData]);

    const handleFriendRequest = useCallback((request: FriendRequest, accepted: boolean) => {
        if (!currentUser) return;

        setAllUsersData(prev => {
            const newState = { ...prev };
            const currentUserAccount = { ...newState[currentUser] };
            const senderAccount = { ...newState[request.from] };

            // 1. Update/remove request from current user (recipient)
            currentUserAccount.userData = {
                ...currentUserAccount.userData,
                friendRequests: currentUserAccount.userData.friendRequests.filter(r => r.id !== request.id)
            };
            
            const newAchievementsForCurrentUser: Achievement[] = [];
            let notificationMessage = '';
            let notificationType: NotificationType = 'FRIEND_ACCEPT';


            if (accepted) {
                // 2. Add each other to friends list
                currentUserAccount.userData.friends = [...currentUserAccount.userData.friends, request.from];
                senderAccount.userData.friends = [...senderAccount.userData.friends, request.to];
                notificationMessage = `${currentUserAccount.userData.name} (@${currentUserAccount.userData.username}) accepted your friend request.`;

                // Social Butterfly Achievement
                if (currentUserAccount.userData.friends.length === 1 && !currentUserAccount.userData.unlockedAchievements.includes('social-butterfly')) {
                    const ach = mockAchievements.find(a => a.id === 'social-butterfly');
                    if (ach) {
                        newAchievementsForCurrentUser.push(ach);
                        currentUserAccount.userData.unlockedAchievements.push('social-butterfly');
                    }
                }
                if (senderAccount.userData.friends.length === 1 && !senderAccount.userData.unlockedAchievements.includes('social-butterfly')) {
                    senderAccount.userData.unlockedAchievements.push('social-butterfly');
                }
                
                // Community Builder Achievement
                if (currentUserAccount.userData.friends.length === 5 && !currentUserAccount.userData.unlockedAchievements.includes('community-builder')) {
                     const ach = mockAchievements.find(a => a.id === 'community-builder');
                     if (ach) {
                        newAchievementsForCurrentUser.push(ach);
                        currentUserAccount.userData.unlockedAchievements.push('community-builder');
                     }
                }
                if (senderAccount.userData.friends.length === 5 && !senderAccount.userData.unlockedAchievements.includes('community-builder')) {
                    senderAccount.userData.unlockedAchievements.push('community-builder');
                }
            } else {
                notificationType = 'FRIEND_REQUEST'; // Using same type for decline for simplicity
                notificationMessage = `${currentUserAccount.userData.name} (@${currentUserAccount.userData.username}) declined your friend request.`;
            }
            
            // 3. Send notification to sender
            const responseNotification: Notification = {
                id: `notif-${Date.now()}`,
                type: notificationType,
                message: notificationMessage,
                from: currentUser,
                isRead: false,
                timestamp: Date.now()
            };
            senderAccount.userData.notifications = [responseNotification, ...senderAccount.userData.notifications];

            if (newAchievementsForCurrentUser.length > 0) {
                setAchievementQueue(q => [...q, ...newAchievementsForCurrentUser]);
            }
            
            newState[currentUser] = currentUserAccount;
            newState[request.from] = senderAccount;
            return newState;
        });
    }, [currentUser]);
    
    const sendMessage = useCallback((recipientEmail: string, text: string) => {
        if (!currentUser) return;
        
        const chatKey = [currentUser, recipientEmail].sort().join('--');
        const message: ChatMessage = {
            id: `msg-${Date.now()}`,
            sender: currentUser,
            text,
            timestamp: Date.now()
        };

        setAllUsersData(prev => {
            const newState = { ...prev };
            const senderAccount = { ...newState[currentUser] };
            const recipientAccount = { ...newState[recipientEmail] };

            // Update sender's chat history
            const senderChatHistory = senderAccount.userData.chats[chatKey] || [];
            senderAccount.userData.chats = { ...senderAccount.userData.chats, [chatKey]: [...senderChatHistory, message] };
            newState[currentUser] = senderAccount;

            // Update recipient's chat history & add notification
            const recipientChatHistory = recipientAccount.userData.chats[chatKey] || [];
            recipientAccount.userData.chats = { ...recipientAccount.userData.chats, [chatKey]: [...recipientChatHistory, message] };
            
            const newMessageNotification: Notification = {
                id: `notif-msg-${Date.now()}`,
                type: 'NEW_MESSAGE',
                message: `New message from ${senderAccount.userData.name}.`,
                from: currentUser,
                isRead: false,
                timestamp: Date.now()
            };
            recipientAccount.userData.notifications = [newMessageNotification, ...recipientAccount.userData.notifications];

            newState[recipientEmail] = recipientAccount;

            return newState;
        });
    }, [currentUser]);
    
    const clearNotification = useCallback((notificationId: string) => {
        updateCurrentUserAccount(account => ({
            ...account,
            userData: {
                ...account.userData,
                notifications: account.userData.notifications.filter(n => n.id !== notificationId)
            }
        }));
    }, [updateCurrentUserAccount]);

    const markNotificationAsRead = useCallback((notificationId: string) => {
        updateCurrentUserAccount(account => ({
            ...account,
            userData: {
                ...account.userData,
                notifications: account.userData.notifications.map(n => 
                    n.id === notificationId ? { ...n, isRead: true } : n
                )
            }
        }));
    }, [updateCurrentUserAccount]);
    
    const markAllNotificationsAsRead = useCallback(() => {
         updateCurrentUserAccount(account => ({
            ...account,
            userData: {
                ...account.userData,
                notifications: account.userData.notifications.map(n => ({ ...n, isRead: true }))
            }
        }));
    }, [updateCurrentUserAccount]);
    
    const clearAllReadNotifications = useCallback(() => {
        updateCurrentUserAccount(account => ({
            ...account,
            userData: {
                ...account.userData,
                notifications: account.userData.notifications.filter(n => !n.isRead)
            }
        }));
    }, [updateCurrentUserAccount]);
    
    const toggleNotificationPanel = useCallback(() => {
        setIsNotificationPanelOpen(prev => !prev);
    }, []);

    // --- Mental Health Features ---
    const addMoodLog = useCallback((log: Omit<MoodLog, 'date'>) => {
        updateCurrentUserAccount(account => {
            const today = new Date().toISOString().split('T')[0];
            const newLog: MoodLog = { ...log, date: today };

            const todaysLogExists = account.userData.moodLog.some(l => l.date === today);

            // Replace today's log if it exists, otherwise add it
            const otherLogs = account.userData.moodLog.filter(l => l.date !== today);
            
            if (account.userData.moodLog.length === 0) {
                unlockAchievement('mood-tracker');
            }

            if (!todaysLogExists) {
                addXp(5, 'Daily Mood Log');
            }

            return {
                ...account,
                userData: {
                    ...account.userData,
                    moodLog: [...otherLogs, newLog]
                }
            }
        });
    }, [updateCurrentUserAccount, unlockAchievement, addXp]);

    const addJournalEntry = useCallback((entry: Omit<JournalEntry, 'id' | 'date'>) => {
         updateCurrentUserAccount(account => {
            const today = new Date().toISOString().split('T')[0];
            const alreadyJournaledToday = account.userData.journalEntries.some(j => j.date === today);

            const newEntry: JournalEntry = {
                ...entry,
                id: `journal-${Date.now()}`,
                date: today,
            };

            if (!alreadyJournaledToday) {
                addXp(10, 'Daily Reflection');
            }

            return {
                ...account,
                userData: {
                    ...account.userData,
                    journalEntries: [newEntry, ...account.userData.journalEntries]
                }
            }
        });
    }, [updateCurrentUserAccount, addXp]);

    const updateStudyBreakSettings = useCallback((settings: StudyBreakSettings) => {
        updateCurrentUserAccount(account => ({
            ...account,
            userData: {
                ...account.userData,
                studyBreakSettings: settings
            }
        }));
    }, [updateCurrentUserAccount]);

    const incrementBreathingSessions = useCallback(() => {
        updateCurrentUserAccount(account => ({
            ...account,
            userData: {
                ...account.userData,
                breathingSessionsCompleted: (account.userData.breathingSessionsCompleted || 0) + 1
            }
        }));
    }, [updateCurrentUserAccount]);


    const selectedCourse = useMemo(() => {
        return currentUserData.courses.find(c => c.id === viewState.courseId) || null;
    }, [currentUserData.courses, viewState.courseId]);

    const selectedLesson = useMemo(() => {
        return selectedCourse?.lessons.find(l => l.id === viewState.lessonId) || null;
    }, [selectedCourse, viewState.lessonId]);

    const selectedAssignment = useMemo(() => {
        return currentUserData.userData.assignments.find(a => a.id === viewState.assignmentId) || null;
    }, [currentUserData.userData.assignments, viewState.assignmentId]);

    const searchResults = useMemo(() => {
        if (!searchQuery.trim() || !currentUser) return [];

        const query = searchQuery.toLowerCase();
        const account = allUsersData[currentUser];
        if (!account) return [];

        const results: SearchResult[] = [];

        // Search Courses & Lessons
        account.courses.forEach(course => {
            if (course.title.toLowerCase().includes(query) || course.description.toLowerCase().includes(query)) {
                results.push({ type: 'course', data: course });
            }
            course.lessons.forEach(lesson => {
                if (lesson.title.toLowerCase().includes(query) || (lesson.content && lesson.content.toLowerCase().includes(query))) {
                    results.push({ type: 'lesson', data: lesson, course });
                }
            });
        });

        // Search Assignments
        account.userData.assignments.forEach(assignment => {
            if (assignment.title.toLowerCase().includes(query) || assignment.description.toLowerCase().includes(query)) {
                const course = account.courses.find(c => c.id === assignment.courseId);
                results.push({ type: 'assignment', data: assignment, course });
            }
        });

        // Search Events
        account.userData.events.forEach(event => {
            if (event.title.toLowerCase().includes(query) || event.description.toLowerCase().includes(query) || (event.location && event.location.toLowerCase().includes(query))) {
                const course = event.courseId ? account.courses.find(c => c.id === event.courseId) : undefined;
                results.push({ type: 'event', data: event, course });
            }
        });
        
        return results;
    }, [searchQuery, currentUser, allUsersData]);

    const appContextValue: AppContextType = {
        // App State
        courses: currentUserData.courses,
        userData: currentUserData.userData,
        viewState: viewState,
        isDarkMode,
        isNotificationPanelOpen,

        // State Updaters
        updateLessonMastery,
        updateLessonResources,
        completeLesson,
        navigate,
        setIsDarkMode,
        unlockAchievement,
        toggleSidebar,
        updateUserProfile,
        addXp,
        completeAssignment,
        toggleNotificationPanel,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        clearAllReadNotifications,

        // Search
        searchQuery,
        setSearchQuery,
        searchResults,

        // Course Management
        addCourse,
        updateCourse,
        deleteCourse,
        
        // Lesson Management
        addLesson,
        updateLesson,
        deleteLesson,

        // Assignment Management
        addAssignment,
        updateAssignment,
        deleteAssignment,
        logTimeForAssignment,

        // Auth & Onboarding
        currentUser,
        login,
        signup,
        logout,
        completeOnboarding,

        // Social Features
        allUsersData,
        getPeerSuggestions,
        sendFriendRequest,
        handleFriendRequest,
        sendMessage,
        clearNotification,

        // Calendar Management
        addEvent,
        updateEvent,
        deleteEvent,

        // Mental Health
        addMoodLog,
        addJournalEntry,
        updateStudyBreakSettings,
        incrementBreathingSessions,
    };

    const renderContent = () => {
        switch (viewState.view) {
            case View.COURSE:
                return selectedCourse && <CourseView course={selectedCourse} />;
            case View.LESSON:
                return selectedCourse && selectedLesson && <LessonView course={selectedCourse} lesson={selectedLesson} />;
            case View.ASSIGNMENT:
                return selectedAssignment && <AssignmentView assignment={selectedAssignment} />;
            case View.CALENDAR:
                return <CalendarView />;
            case View.ACHIEVEMENTS:
                return <AchievementsView />;
            case View.MENTAL_HEALTH:
                return <MentalHealthView />;
            case View.PROFILE:
                return <ProfileView />;
            case View.SETTINGS:
                return <SettingsView />;
            case View.RESEARCH:
                return <ResearchView />;
            case View.COMMUNITY:
                return <CommunityView />;
            case View.SEARCH_RESULTS:
                return <SearchResultsView />;
            case View.DASHBOARD:
            default:
                return <Dashboard />;
        }
    };

    const isSidebarOpen = currentUserData.userData.isSidebarOpen;

    return (
        <AppContext.Provider value={appContextValue}>
             <div className="min-h-screen font-sans text-slate-800 dark:text-slate-200 transition-colors duration-300">
                {!currentUser ? (
                    <AuthView />
                ) : (
                    <>
                        {showOnboarding ? (
                            <OnboardingView />
                        ) : (
                             <div className="relative min-h-screen">
                                {/* Backdrop for mobile sidebar */}
                                {isSidebarOpen && (
                                    <div 
                                        onClick={toggleSidebar} 
                                        className="fixed inset-0 bg-black/60 z-40 lg:hidden backdrop-blur-sm"
                                        aria-hidden="true"
                                    ></div>
                                )}
                                <Sidebar />
                                <div className={`flex-1 flex flex-col transition-[margin-left] duration-500 ease-in-out ${isSidebarOpen ? 'lg:ml-64' : 'lg:ml-20'}`}>
                                    <Header />
                                    <NotificationPanel />
                                    <main className="p-4 sm:p-6 lg:p-8 flex-1">
                                        <div key={`${viewState.view}-${viewState.courseId}-${viewState.lessonId}-${viewState.assignmentId}`} className="animate-page-enter">
                                            {renderContent()}
                                        </div>
                                    </main>
                                </div>
                                {currentAchievement && <AchievementPopup achievement={currentAchievement} onClose={handlePopupClosed} />}
                                {levelUpInfo && <LevelUpPopup isOpen={isLevelUpPopupOpen} onClose={() => setIsLevelUpPopupOpen(false)} levelUpInfo={levelUpInfo} />}
                                {xpToast && <XPToast amount={xpToast.amount} reason={xpToast.reason} onDone={() => setXpToast(null)} />}
                            </div>
                        )}
                    </>
                )}
            </div>
        </AppContext.Provider>
    );
};

export default App;
